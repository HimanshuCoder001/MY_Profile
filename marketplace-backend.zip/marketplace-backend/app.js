require('module-alias/register');
const express = require('express');
const path = require('path');
const config = require('config');
const { logger } = require('@spice-money/common-logger');

// Import routes and middleware
const { AppMiddleware, ErrorMiddleware } = require('@middlewares');
const routes = require('@routes');

// Set global app root
global.appRoot = path.resolve(__dirname);

class App {
  constructor() {
    logger.info('Initializing App 🚀');
    this.app = express();
    this.initializeMiddleware();
    this.initializeRoutes();
    this.initializeErrorHandling();
  }

  /**
   * Initialize all middleware
   */
  initializeMiddleware() {
    // Apply all middleware through the middleware loader
    AppMiddleware.getInstance().applyMiddleware(this.app);
  }

  /**
   * Initialize application routes
   */
  initializeRoutes() {
    // Health check endpoint
    logger.info('Initializing health check endpoint ⛑️');
    this.app.get('/health', (req, res) => {
      res.status(200).json({ status: 'ok' });
    });

    // API routes
    logger.info('Initializing API routes 🚏');
    this.app.use(config.get('contextPath'), routes);
  }

  /**
   * Initialize error handling
   */
  initializeErrorHandling() {
    // Apply error middleware after routes
    ErrorMiddleware.getInstance().applyErrorMiddleware(this.app);
  }

  /**
   * Get Express application instance
   * @returns {express.Application} Express application
   */
  getApp() {
    return this.app;
  }
}

// Create and export a singleton instance
const app = new App().getApp();
module.exports = app;
