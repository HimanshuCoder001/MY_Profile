#!/bin/bash

# Ensure script is always executed with bash
if [ -z "$BASH_VERSION" ]; then
  exec /bin/bash "$0" "$@"
fi

# Define the API endpoint
URL="http://localhost:5080/marketplace/shop-insurance/cron/update-all-status-logs"

# Define the API key
API_KEY="ZzrJnqXGqBi2z8yI4sJcpTk7fJQhwIYSR49uQRkqD1qIeFUZc5VdUdtm0MZnTWUw"

# Execute the curl request
curl -X GET "$URL" \
     -H "xapikey: $API_KEY" \
     -H "Content-Type: application/json"

# Optional: Print a new line after the curl output
echo
