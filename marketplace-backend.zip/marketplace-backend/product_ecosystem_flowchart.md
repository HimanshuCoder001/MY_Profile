# Product Ecosystem Flowchart - Clean Version

## **Database Structure Diagram**

```mermaid
graph TD
    %% Core Product Entity
    Products[📦 PRODUCTS<br/>Table: t_products<br/>Primary Key: product_id]
    
    %% Direct Relationships
    Products --> ProductDetails
    Products --> ProductForms
    Products --> ProductBanners
    
    %% Product Details
    ProductDetails[📋 PRODUCT DETAILS<br/>Table: t_product_details<br/>Primary Key: detail_id<br/>FK: product_id]
    
    %% Product Forms
    ProductForms[📝 PRODUCT FORMS<br/>Table: t_product_forms<br/>Primary Key: form_id<br/>FK: product_id]
    
    %% Product Banners with Types
    ProductBanners[🖼️ PRODUCT BANNERS<br/>Table: t_product_banners<br/>Primary Key: banner_id<br/>FK: product_id<br/>Key Field: banner_type]
    
    %% Banner Types - Multiple Arrays per Product
    ProductBanners --> HeroBanners
    ProductBanners --> CategoryBanners
    ProductBanners --> PromotionalBanners
    ProductBanners --> FeaturedBanners
    ProductBanners --> MobileBanners
    
    HeroBanners[🏆 HERO BANNERS<br/>banner_type: 'hero'<br/>Multiple banners per product]
    CategoryBanners[📂 CATEGORY BANNERS<br/>banner_type: 'category'<br/>Multiple banners per product]
    PromotionalBanners[🎯 PROMOTIONAL BANNERS<br/>banner_type: 'promotional'<br/>Multiple banners per product]
    FeaturedBanners[⭐ FEATURED BANNERS<br/>banner_type: 'featured'<br/>Multiple banners per product]
    MobileBanners[📱 MOBILE BANNERS<br/>banner_type: 'mobile'<br/>Multiple banners per product]
    
    %% Product Hierarchy
    ParentProducts[🏢 PARENT PRODUCTS<br/>parent_id = NULL]
    ChildProducts[🏪 CHILD PRODUCTS<br/>parent_id = product_id]
    ParentProducts --> ChildProducts
    
    %% Business Tables
    Leads[👥 LEADS<br/>Table: t_leads<br/>Primary Key: lead_id]
    Transactions[💰 TRANSACTIONS<br/>Table: t_transactions<br/>Primary Key: request_id]
    ServiceableClients[✅ SERVICEABLE CLIENTS<br/>Table: t_serviceable_clients<br/>Composite Key: client_id + redirection_type]
    
    %% Business Relationships
    Leads -.-> Products
    Transactions -.-> Products
    ServiceableClients -.-> Products
```

## **Business Process Flow Diagram**

```mermaid
graph TD
    %% Process Flow
    Start[🚀 START PROCESS]
    ProductCreation[➕ STEP 1: CREATE PRODUCT<br/>Initialize product record<br/>Set basic information]
    
    %% Parallel Steps
    ProductCreation --> BannerAssignment
    ProductCreation --> FormVersioning
    ProductCreation --> DetailEnrichment
    
    BannerAssignment[🖼️ STEP 2: ASSIGN BANNERS BY TYPE<br/>Create multiple banner arrays<br/>Assign different banner types]
    FormVersioning[📝 STEP 3: CREATE FORM VERSIONS<br/>Design dynamic forms<br/>Version control management]
    DetailEnrichment[📋 STEP 4: ADD PRODUCT DETAILS<br/>Enrich with categories<br/>Add competition data]
    
    %% Sequential Steps
    ProductCreation --> LeadGeneration
    LeadGeneration[👥 STEP 5: GENERATE LEADS<br/>Product-specific leads<br/>Lead tracking and status]
    
    LeadGeneration --> TransactionProcessing
    TransactionProcessing[💰 STEP 6: PROCESS TRANSACTIONS<br/>Financial activities<br/>Status tracking]
    
    TransactionProcessing --> ClientServiceability
    ClientServiceability[✅ STEP 7: CHECK CLIENT SERVICEABILITY<br/>Eligibility validation<br/>Client targeting]
    
    ClientServiceability --> Success
    Success[🎉 SUCCESS: Process Complete]
    
    %% Decision Points
    IsProductActive{✅ Is Product Active?}
    IsClientEligible{👤 Is Client Eligible?}
    IsTransactionValid{💰 Is Transaction Valid?}
    
    IsProductActive -->|Yes| LeadGeneration
    IsProductActive -->|No| End1[🛑 Product Inactive]
    
    IsClientEligible -->|Yes| Success
    IsClientEligible -->|No| End2[❌ Client Not Eligible]
    
    IsTransactionValid -->|Yes| TransactionProcessing
    IsTransactionValid -->|No| End3[❌ Transaction Failed]
```

## **Key Features of the Product Ecosystem:**

### **1. Core Product Structure**
- **Products** table serves as the central entity
- Supports hierarchical structure (parent-child relationships)
- Contains basic product information (name, type, active status)

### **2. Product Details Management**
- **ProductDetails** stores comprehensive product information
- Includes categories, subcategories, product types
- Contains FAQ data and competition benchmarking
- Partner availability and opportunity type tracking

### **3. Dynamic Form System**
- **ProductForms** manages multiple form versions per product
- JSON-based form definitions for flexibility
- Version control and status management
- Meta information storage

### **4. Multi-Type Banner System** ⭐
**This is the core feature you mentioned - multiple arrays of objects against one single product divided by ProductBanners type column:**

- **ProductBanners** supports multiple banner types per product
- **Each product can have multiple banners of each type:**
  - 🏆 **Hero Banners** (`banner_type: 'hero'`) - Primary display banners
  - 📂 **Category Banners** (`banner_type: 'category'`) - Category-specific displays
  - 🎯 **Promotional Banners** (`banner_type: 'promotional'`) - Campaign-specific banners
  - ⭐ **Featured Banners** (`banner_type: 'featured'`) - Highlight banners
  - 📱 **Mobile Banners** (`banner_type: 'mobile'`) - Mobile-optimized banners
- Client-specific banner targeting with `client_id` field
- Order management with `display_order` for proper sequencing
- Rich media support (images, mobile images, icons, target URLs)

### **5. Business Process Integration**
- **Leads** table tracks product-specific lead generation
- **Transactions** records product-related financial activities
- **ServiceableClients** manages client eligibility per product type

### **6. Data Flow Process**
1. **Product Creation** - Initialize product with basic information
2. **Banner Assignment** - Create multiple banner arrays by type
3. **Form Versioning** - Design and version dynamic forms
4. **Detail Enrichment** - Add comprehensive product details
5. **Lead Generation** - Track product-specific leads
6. **Transaction Processing** - Handle financial activities
7. **Client Serviceability** - Validate client eligibility

This architecture allows for flexible product management with multiple banner types, dynamic forms, and comprehensive business process tracking.
