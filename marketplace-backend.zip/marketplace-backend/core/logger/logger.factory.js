const { Logger } = require('@spice-money/common-logger');
const { LoggerAdapter } = require('./logger.adapter');

class LoggerFactory {

    /**
     * Get a logger instance
     * @param {string} scope - The scope of the logger
     * @returns {LoggerAdapter} The logger instance
     */
    static getLogger(scope) {
        const loggerInstance = Logger.getInstance();
        const loggerAdapter = new LoggerAdapter(loggerInstance);
        if (scope) {
            loggerAdapter.setScope(scope);
        }
        return loggerAdapter;
    }
}

module.exports = { LoggerFactory };
