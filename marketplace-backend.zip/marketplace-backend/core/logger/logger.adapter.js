'use strict';
const { logScopesStore, LogLevel } = require('@spice-money/common-logger');

class LoggerAdapter {
  #scope = '';

  constructor(logger) {
    this.loggerInstance = logger;
  }

  /**
   * Print a log message
   * @param {string} level - The level of the log
   * @param {string} message - The message to log
   * @private
   */
  _printLog(level, message) {
    if (this.#scope) {
      const parentScopes = logScopesStore.getStore() || [];
      logScopesStore.run([...parentScopes, this.#scope], () => {
        this.loggerInstance[level](message);
      });
      return;
    }
    this.loggerInstance[level](message);
  }

  /**
   * Update the metadata of the logger
   * @param {Object} meta - The metadata to update
   */
  updateMetaData(meta) {
    this.loggerInstance.updateWinstonDefaultMeta(meta);
  }

  /**
   * Set the scope of the logger
   * @param {string} scope - The scope of the logger
   * @private
   */
  setScope(scope) {
    this.#scope = scope;
  }

  /**
   * Log an info message
   * @param {string} message - The message to log
   */
  info(message) {
    this._printLog(LogLevel.INFO, message);
  }

  /**
   * Log an error message
   * @param {string} message - The message to log
   */
  error(message) {
    if (message?.error instanceof Error) {
      message.error = { message: message.error.message, stackTrace: message.error.stack };
    }
    this._printLog(LogLevel.ERROR, message);
  }

  /**
   * Log a warning message
   * @param {string} message - The message to log
   */
  warn(message) {
    this._printLog(LogLevel.WARN, message);
  }

  /**
   * Log a debug message
   * @param {string} message - The message to log
   */
  debug(message) {
    this._printLog(LogLevel.DEBUG, message);
  }
}

module.exports = { LoggerAdapter };
