module.exports = {
  ...require('./logger.factory'),
};
