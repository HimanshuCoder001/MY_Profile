'use strict';
const FAQ_DATA = require('@static/faq.json');
const AXIS_GRAHAK_SERVICES = require('@static/axis-grahak-services.json');

// Encryption constants
const ENCRYPT = {
    ENCRYPTION_KEY: 'Spice@12345',
    ENCRYPTION_ALGORITHM: 'aes-256-cbc',
}

// Camel to snake pattern
const CAMEL_TO_SNAKE_PATTERN = /([a-z])([A-Z])/g;
const HYPHEN_PATTERN = /-./g;

// Encrypted URLs
const ENCRYPTED_URLS = {
    "/marketplace/csmdetails/getdata": true,
    "/marketplace/grahak-loan/history": true,
    "/marketplace/grahak-loan/dashboard": false
};

const EARNINGS_FILTER = {
    THIS_MONTH: "This month",
    LAST_MONTH: "Last month",
    LAST_SIX_MONTH: "Last six months",
};

const ALLOWED_PRODUCT_IDS = [
    170,
    237,
    60,
    273,
    309
];

const RESTRICTED_PRODUCT_IDS = [
    70,
    72,
    77,
    148,
    160,
    98,
    163,
    166,
    189,
    218,
    236,
    62,
    64,
    133,
    105
];

const LENDER_LOGOS = {
    AXIS: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    MUTHOOT_GOLD_LOAN: "https://ik.imagekit.io/kcjnzhyhlu/icons/muthoot.png?updatedAt=1708401005433",
    IIFL_GOLD_LOAN: "https://ik.imagekit.io/kcjnzhyhlu/lender/IIFL-Logo.webp?updatedAt=1704858680744",
    ADITYA_BIRLA_LAP: "https://ik.imagekit.io/kjjiuppdz/icons/marketplace/ABFL.png?updatedAt=1744610762603",
    HERO_HOUSING_FINANCE_LAP: "https://ik.imagekit.io/kjjiuppdz/icons/marketplace/1000124038.png?updatedAt=1743675162332",
    MUTHOOT_FINCORP_LAP: "https://ik.imagekit.io/kjjiuppdz/icons/MFL%20LOGO%20with%20tagline.jpg?updatedAt=1720003974679",
    MUTHOOT_FINCORP_GOLD_LOAN: "https://ik.imagekit.io/kjjiuppdz/icons/MFL%20LOGO%20with%20tagline.jpg?updatedAt=1720003974679",
    HERO_HOUSING_FINANCE_LOAN: "https://ik.imagekit.io/kjjiuppdz/icons/marketplace/1000124038.png?updatedAt=1743675162332",
    DEFAULT_LOGO: "https://ik.imagekit.io/smimgkit/Marketplace/WhatsApp%20Image%202025-09-16%20at%2017.25.47.jpeg?updatedAt=1758023915240",
    TWO_WHEELER: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    AUTO_LOAN: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    TRACTOR_LOAN: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    ASHA_HOME_LOAN: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    CONSTRUCTION_EQUIPMENT: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    MICROFINANCE: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    MSME: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    PERSONAL_LOAN: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    COMMERCIAL_VEHICLE: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    INDIVIDUAL_AGRI_CROP_LOAN: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    B2B_RETAIL: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    FUND_BASED_FACILITY_SBB: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907",
    UNSECURED_BL_SBB: "https://ik.imagekit.io/kcjnzhyhlu/icons/Axis%20Bank.png?updatedAt=1708400964907"
};

const CACHE_KEYS = {
    LOAN_CENTER_DASHBOARD: 'LOAN-CENTER-DASHBOARD',
    AXIS_LOAN_CENTER: 'AXIS-LOAN-CENTER'
};

// Reverse mapping for cache keys
const CACHE_KEYS_REVERSE = {
    'LOAN-CENTER-DASHBOARD': 'LOAN_CENTER_DASHBOARD',
    'AXIS-LOAN-CENTER': 'AXIS_LOAN_CENTER'
};

const INSURANCE_SERVICES = {
    "name": "Insurance Services from Spice Money",
    "details": [
        {
            "name": "Why Buy Insurance from Spice Money",
            "details": [
                "Customized products catering to requirements of Adhikaris and Customers",
                "Preferred premium rates",
                "Available with Adhikaris outlet in customer locality",
                "Easy claim initiation process",
                "Fully digital paperless process"
            ]
        },
        {
            "name": "Why Adhikari and Customers need Insurance",
            "details": [
                "Financial protection from uncertainty",
                "Cost Effective & Affordable coverage of high cost events",
                "Protects Individuals and Family Members"
            ]
        }
    ]
}

const API_KEY_SOURCE = {
    CREDIT: "credit"
}

module.exports = {
    ENCRYPT,
    HYPHEN_PATTERN,
    CAMEL_TO_SNAKE_PATTERN,
    ENCRYPTED_URLS,
    EARNINGS_FILTER,
    ALLOWED_PRODUCT_IDS,
    RESTRICTED_PRODUCT_IDS,
    LENDER_LOGOS,
    FAQ_DATA,
    AXIS_GRAHAK_SERVICES,
    CACHE_KEYS,
    CACHE_KEYS_REVERSE,
    INSURANCE_SERVICES,
    API_KEY_SOURCE
}