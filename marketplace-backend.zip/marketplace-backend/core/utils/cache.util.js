'use strict';

const NodeCache = require('node-cache');
const { CACHE_KEYS, CACHE_KEYS_REVERSE } = require('./constants');
const { LoggerFactory } = require('@logger');

// Initialize cache with optimized configuration
const cache = new NodeCache({
    stdTTL: 600, // 10 minutes default TTL
    checkperiod: 120, // Check for expired keys every 2 minutes
    useClones: false, // Better performance
    deleteOnExpire: true
});

const logger = LoggerFactory.getLogger('CacheUtil');

// Set up cache event listeners for monitoring
cache.on('expired', (key, value) => {
    logger.debug(`Cache key expired: ${key}`);
});

cache.on('flush', () => {
    logger.info('Cache flushed');
});

cache.on('del', (key, value) => {
    logger.debug(`Cache key deleted: ${key}`);
});

/**
 * Get item from cache
 * @param {string} key - Cache key identifier
 * @returns {Promise<any>} - Cached value or null if not found
 */
async function getItem(key) {
    try {
        if (!key || typeof key !== 'string') {
            throw new Error('Invalid key: Key must be a non-empty string');
        }

        const cacheKey = CACHE_KEYS_REVERSE[key];
        if (!cacheKey) {
            logger.error({ ref: 'get item', message: `Invalid cache key identifier`, key });
            throw new Error(`Invalid cache key identifier: ${key}`);
        }

        const value = cache.get(cacheKey);
        
        logger.debug(`Cache get operation`, {
            key: cacheKey,
            found: value !== undefined,
            keyIdentifier: key
        });

        return value;
    } catch (error) {
        logger.error('Error getting item from cache', {
            key,
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

/**
 * Set item in cache
 * @param {string} key - Cache key identifier
 * @param {any} value - Value to cache
 * @param {number} ttl - Time to live in seconds (optional)
 * @returns {Promise<boolean>} - Success status
 */
async function setItem(key, value, ttl = null) {
    try {
        if (!key || typeof key !== 'string') {
            throw new Error('Invalid key: Key must be a non-empty string');
        }

        if (value === null || value === undefined) {
            throw new Error('Invalid value: Value cannot be null or undefined');
        }

        const cacheKey = CACHE_KEYS_REVERSE[key];
        if (!cacheKey) {
            throw new Error(`Invalid cache key identifier: ${key}`);
        }

        // Convert value to string if it's not already
        const stringValue = typeof value === 'string' ? value : JSON.stringify(value);
        
        const success = cache.set(cacheKey, stringValue, ttl);
        
        logger.debug(`Cache set operation`, {
            key: cacheKey,
            keyIdentifier: key,
            ttl: ttl || 'default',
            success
        });

        return success;
    } catch (error) {
        logger.error('Error setting item in cache', {
            key,
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

/**
 * Remove item from cache
 * @param {string} key - Cache key identifier
 * @returns {Promise<number>} - Number of keys deleted
 */
async function removeCache(key) {
    try {
        if (!key || typeof key !== 'string') {
            throw new Error('Invalid key: Key must be a non-empty string');
        }

        const cacheKey = CACHE_KEYS[key];
        if (!cacheKey) {
            throw new Error(`Invalid cache key identifier: ${key}`);
        }

        const deletedCount = cache.del(cacheKey);
        
        logger.debug(`Cache delete operation`, {
            key: cacheKey,
            keyIdentifier: key,
            deletedCount
        });

        return deletedCount;
    } catch (error) {
        logger.error('Error removing item from cache', {
            key,
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

/**
 * Get cache statistics
 * @returns {Object} - Cache statistics
 */
function getStats() {
    return cache.getStats();
}

/**
 * Flush all cache entries
 * @returns {Promise<void>}
 */
async function flush() {
    try {
        cache.flushAll();
        logger.info('Cache flushed successfully');
    } catch (error) {
        logger.error('Error flushing cache', {
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

/**
 * Check if cache has a key
 * @param {string} key - Cache key identifier
 * @returns {Promise<boolean>} - Whether key exists
 */
async function hasKey(key) {
    try {
        if (!key || typeof key !== 'string') {
            return false;
        }

        const cacheKey = CACHE_KEYS[key];
        if (!cacheKey) {
            return false;
        }

        return cache.has(cacheKey);
    } catch (error) {
        logger.error('Error checking cache key existence', {
            key,
            error: error.message
        });
        return false;
    }
}

/**
 * Get all cache keys
 * @returns {Array<string>} - Array of cache keys
 */
function getKeys() {
    return cache.keys();
}

module.exports = {
    getItem,
    setItem,
    removeCache,
    getStats,
    flush,
    hasKey,
    getKeys
};
