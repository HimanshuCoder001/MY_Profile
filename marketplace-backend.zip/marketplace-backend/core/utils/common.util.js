const Ajv = require('ajv');
const crypto = require('crypto');
const config = require("config");
const addFormats = require('ajv-formats');
const { logger } = require('@spice-money/common-logger');
const { ENCRYPT, HYPHEN_PATTERN, CAMEL_TO_SNAKE_PATTERN, ENCRYPTED_URLS } = require('./constants');
const { createErrorResponse, isMarketplaceException } = require('@exceptions');
const util = require('util');

/**
 * Encrypts the given data using AES encryption
 * @param {Object} toEncrypt - The data to encrypt
 * @returns {Object} An object containing the encrypted data
 * @throws {Error} If an error occurs during encryption
 */
function encryptData(toEncrypt) {
    try {
        // Generate a key from the password using PBKDF2
        const salt = crypto.randomBytes(16);
        const key = crypto.pbkdf2Sync(ENCRYPT.ENCRYPTION_KEY, salt, 100000, 32, 'sha256');
        
        // Generate a random IV
        const iv = crypto.randomBytes(16);
        
        // Create cipher
        const cipher = crypto.createCipheriv(ENCRYPT.ENCRYPTION_ALGORITHM, key, iv);
        
        // Encrypt the data
        const dataToEncrypt = JSON.stringify(toEncrypt);
        let encrypted = cipher.update(dataToEncrypt, 'utf8', 'base64');
        encrypted += cipher.final('base64');
        
        return {
            enbody1: key.toString('base64'),
            enbody2: iv.toString('base64'),
            data: encrypted,
        };
    } catch (error) {
        throw new Error(error);
    }
}

/**
 * Converts a camelCase string to a snake_case string
 * @param {string} camelCaseStr - The camelCase string to convert
 * @returns {string} The snake_case string
 */
function camelToSnake(camelCaseStr) {
    if (!camelCaseStr || typeof camelCaseStr !== 'string') return '';

    return camelCaseStr
        .replace(HYPHEN_PATTERN, (match) => match.charAt(1).toUpperCase())
        .replace(CAMEL_TO_SNAKE_PATTERN, '$1_$2')
        .toLowerCase();

}

/**
 * Converts a kebab-case string to SCREAMING_SNAKE_CASE
 * @param {string} kebabCaseStr - The kebab-case string to convert
 * @returns {string} The SCREAMING_SNAKE_CASE string
 */
function kebabToScreamingSnake(kebabCaseStr) {
    if (!kebabCaseStr || typeof kebabCaseStr !== 'string') return '';

    return kebabCaseStr
        .toUpperCase()
        .replace(/-/g, '_');
}

/**
 * Creates a MongoDB connection string
 * @param {Object} options - The options for the connection
 * @returns {string} The MongoDB connection string
 */
function createMongoConnectionString(options) {
    const { host, port, database, user, pass, authSource } = options;
    const encodedUsername = encodeURIComponent(user);
    const encodedPassword = encodeURIComponent(pass);
    const encodedAuthSource = encodeURIComponent(authSource);

    let connectionURI = `mongodb://${host}:${port}/${database}`;
    if (user && pass) {
        connectionURI = `mongodb://${encodedUsername}:${encodedPassword}@${host}:${port}/${database}?authSource=${encodedAuthSource}`;
    }
    return connectionURI;
}

/**
 * Get error message from error object
 * @param {Error|string} err - Error object or string
 * @returns {string} Error message
 */
function getErrorMessage(err) {
    if (typeof err === 'string') return err;
    return (typeof err === "object" ? err.message || err.toString() : "Request processed with error");
}

/**
 * Check if the given URL is encrypted
 * @param {string} url - The URL to check
 * @returns {boolean} True if the URL is encrypted, false otherwise
 */
function checkEncryptedUrl(url) {
    return Object.entries(ENCRYPTED_URLS)
        .filter(([_, value]) => value === true)
        .map(([pattern]) => ({
            pattern,
            regex: new RegExp(`^${pattern.replace(/:[^/]+/g, '[^/]+')}$`)
        }))
        .some(({ regex }) => regex.test(url));
}

/**
 * Send wrapped response with standard format
 * @param {Error|null} err - Error object or null
 * @param {any} data - Response data
 * @param {string} message - Success message
 */
function sendWrapped(err, data, message = "Request processed successfully") {
    const req = this.req;
    
    // Handle marketplace exceptions
    if (err && isMarketplaceException(err)) {
        const errorResponse = createErrorResponse(err);
        this.status(err.statusCode);
        return this.send(errorResponse);
    }
    
    let finalResponse = {
        status: !err,
        message: err ? getErrorMessage(err) : message,
        resp: { data }
    };
    
    if (this.statusCode === 200 && checkEncryptedUrl(req.originalUrl)) {
        finalResponse = encryptData(finalResponse);
    }
    
    return this.send(finalResponse);
}

/**
 * Safely serialize object to remove circular references
 * @param {Object} obj - Object to serialize
 * @returns {Object} Serialized object without circular references
 */
function safeSerialize(obj) {
    const seen = new WeakSet();
    
    const serialize = (value) => {
        if (value === null || value === undefined) {
            return value;
        }
        
        if (typeof value !== 'object') {
            return value;
        }
        
        if (seen.has(value)) {
            return '[Circular Reference]';
        }
        
        seen.add(value);
        
        if (Array.isArray(value)) {
            return value.map(serialize);
        }
        
        if (value instanceof Date) {
            return value;
        }
        
        if (value instanceof Buffer) {
            return value.toString('base64');
        }
        
        const result = {};
        for (const key in value) {
            if (value.hasOwnProperty(key)) {
                try {
                    result[key] = serialize(value[key]);
                } catch (error) {
                    result[key] = '[Serialization Error]';
                }
            }
        }
        
        return result;
    };
    
    return serialize(obj);
}


/**
 * Generate a secure API key
 * @param {number} length - Length of the API key (default: 32)
 * @returns {string} Generated API key
 */
function generateApiKey(length = 32) {
    return crypto.randomBytes(length).toString('hex');
}

/**
 * Get API key configuration by source
 * @param {string} source - The source identifier
 * @returns {Object|null} API key configuration or null if not found
 */
function getApiKeyBySource(source) {
    const apiKeys = config.get("api-key");
    
    // Find API key configuration by source
    for (const [apiKey, config] of Object.entries(apiKeys)) {
        if (config.source === source && config.enabled === true) {
            return {
                apiKey,
                ...config
            };
        }
    }
    
    return null;
}

/**
 * Calculate string similarity for name matching
 * @param {string} str1 - First string
 * @param {string} str2 - Second string
 * @returns {number} Similarity score between 0 and 1 (1 = exact match)
 */
function calculateStringSimilarity(str1, str2) {
    if (!str1 || !str2) return 0;
    
    // Convert to lowercase and trim
    const s1 = str1.toLowerCase().trim();
    const s2 = str2.toLowerCase().trim();
    
    // Exact match
    if (s1 === s2) return 1;
    
    // If either string is empty, return 0
    if (s1.length === 0 || s2.length === 0) return 0;
    
    // Split into words and clean them (remove special characters)
    const words1 = s1.split(/\s+/).filter(word => word.length > 0).map(word => word.replace(/[^\w]/g, ''));
    const words2 = s2.split(/\s+/).filter(word => word.length > 0).map(word => word.replace(/[^\w]/g, ''));
    
    // If one has words and the other doesn't, very low similarity
    if ((words1.length === 0 && words2.length > 0) || (words1.length > 0 && words2.length === 0)) {
        return 0.1;
    }
    
    // For name validation, we want to be reasonable but accurate
    let exactMatches = 0;
    let partialMatches = 0;
    
    for (const word1 of words1) {
        for (const word2 of words2) {
            // Exact word match
            if (word1 === word2) {
                exactMatches++;
                break;
            }
            
            // Check for partial matches (one word contains the other)
            const minLength = Math.min(word1.length, word2.length);
            const maxLength = Math.max(word1.length, word2.length);
            
            // If one word is a prefix of the other (e.g., "yada" in "yadav")
            if (word1.startsWith(word2) || word2.startsWith(word1)) {
                // Calculate similarity based on how much they overlap
                const overlapRatio = minLength / maxLength;
                if (overlapRatio >= 0.7) { // 70% or more overlap
                    partialMatches += overlapRatio;
                }
                break;
            }
            
            // Check for high character similarity (for typos)
            let charMatches = 0;
            const minWordLength = Math.min(word1.length, word2.length);
            
            for (let i = 0; i < minWordLength; i++) {
                if (word1[i] === word2[i]) {
                    charMatches++;
                }
            }
            
            const charSimilarity = charMatches / maxLength;
            if (charSimilarity >= 0.8) { // 80% or more character similarity
                partialMatches += charSimilarity * 0.8;
                break;
            }
        }
    }
    
    // Calculate similarity based on exact and partial matches
    const maxWords = Math.max(words1.length, words2.length);
    const exactSimilarity = exactMatches / maxWords;
    const partialSimilarity = Math.min(partialMatches, maxWords - exactMatches) / maxWords;
    
    return exactSimilarity + (partialSimilarity * 0.8);
}


/**
 * Safely stringify an object to JSON, handling circular references
 * @param {Object} obj - Object to stringify
 * @param {number} [space=2] - Indentation spaces for formatting
 * @returns {string} JSON string or placeholder for circular structures
 */
function safeStringify(obj, space = 2) {
    const seen = new WeakSet();
    return JSON.stringify(obj, function (key, value) {
      if (typeof value === 'object' && value !== null) {
        if (seen.has(value)) {
          return '[Circular]';
        }
        seen.add(value);
      }
      return value;
    }, space);
}
  

/**
 * Safely inspect any object, including non-serializable structures
 * @param {any} obj - Object to inspect
 * @param {number} [depth=null] - Recursion depth for inspection
 * @returns {string} Human-readable string of the object
 */
function safeInspect(obj, depth = null) {
    return util.inspect(obj, { depth });
}


/**
 * Calculate simple name match score
 * @param {string} name1
 * @param {string} name2
 * @returns {boolean} true if names match closely, false otherwise
 */
function nameMatchScore(name1, name2) {
    if (!name1 || !name2) return 0;

    const normalize = str =>
        str
            .toLowerCase()
            .trim()
            .replace(/[^\w\s]/g, '')
            .split(/\s+/);

    const [first1, last1] = normalize(name1);
    const [first2, last2] = normalize(name2);

    if (!first1 || !first2) return 0;

    const levenshtein = (a, b) => {
        const dp = Array.from({ length: a.length + 1 }, (_, i) =>
            Array(b.length + 1).fill(0)
        );
        for (let i = 0; i <= a.length; i++) dp[i][0] = i;
        for (let j = 0; j <= b.length; j++) dp[0][j] = j;

        for (let i = 1; i <= a.length; i++) {
            for (let j = 1; j <= b.length; j++) {
                if (a[i - 1] === b[j - 1]) {
                    dp[i][j] = dp[i - 1][j - 1];
                } else {
                    dp[i][j] = 1 + Math.min(
                        dp[i - 1][j],
                        dp[i][j - 1],
                        dp[i - 1][j - 1]
                    );
                }
            }
        }
        return dp[a.length][b.length];
    };

    const similarity = (a, b) => {
        const dist = levenshtein(a, b);
        return 1 - dist / Math.max(a.length, b.length);
    };

    const firstSimilarity = similarity(first1, first2);
    const lastSimilarity = last1 && last2 ? similarity(last1, last2) : 1;

    // Average both similarities
    return (firstSimilarity + lastSimilarity) / 2;
}

module.exports = {
    encryptData,
    camelToSnake,
    kebabToScreamingSnake,
    createMongoConnectionString,
    getErrorMessage,
    sendWrapped,
    safeSerialize,
    generateApiKey,
    getApiKeyBySource,
    calculateStringSimilarity,
    safeStringify,
    safeInspect,
    nameMatchScore
};