const FORM_TYPES = {
    SHOP_INSURANCE_LEAD_FORM: 'SHOP_INSURANCE_LEAD_FORM',

    TWO_WHEELER_INSURANCE_NEW_BIKE_FORM: 'TWO_WHEELER_INSURANCE_NEW_BIKE_FORM',
    TWO_WHEELER_INSURANCE_OLD_BIKE_FORM: 'TWO_WHEELER_INSURANCE_OLD_BIKE_FORM',
    TWO_WHEELER_INSURANCE_LEAD_FORM: 'TWO_WHEELER_INSURANCE_LEAD_FORM',
}

const FORM_TYPE_CATEGORIES = {
    SHOP_INSURANCE: [
        FORM_TYPES.SHOP_INSURANCE_LEAD_FORM,
    ],
    TWO_WHEELER_INSURANCE: [
        FORM_TYPES.TWO_WHEELER_INSURANCE_NEW_BIKE_FORM,
        FORM_TYPES.TWO_WHEELER_INSURANCE_OLD_BIKE_FORM,
        FORM_TYPES.TWO_WHEELER_INSURANCE_LEAD_FORM,
    ],
}


/**
 * Get form types by category
 * @param {string} category - The category name
 * @returns {string[]} Array of form types for the category
 */
const getFormTypesByCategory = (category) => {
    return FORM_TYPE_CATEGORIES[category] || [];
};

/**
 * Get all form types
 * @returns {string[]} Array of all form types
 */
const getAllFormTypes = () => {
    return Object.values(FORM_TYPES);
};

/**
 * Check if form type is valid
 * @param {string} formType - The form type to validate
 * @returns {boolean} True if valid, false otherwise
 */
const isValidFormType = (formType) => {
    return Object.values(FORM_TYPES).includes(formType);
};

module.exports = {
    FORM_TYPES,
    FORM_TYPE_CATEGORIES,
    getFormTypesByCategory,
    getAllFormTypes,
    isValidFormType,
}