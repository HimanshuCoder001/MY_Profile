'use strict';

const Ajv = require('ajv');
const addFormats = require('ajv-formats');
const { logger } = require('@spice-money/common-logger');
const { ValidationException } = require('@exceptions');

/**
 * Centralized validation utility for all modules
 */
class ValidationUtil {
  /**
   * Create a schema validator using Ajv
   * @param {Object} jsonSchema - JSON schema to validate against
   * @returns {Function} Compiled validator function
   * @throws {Error} If schema validation fails
   */
  static schemaValidator(jsonSchema) {
    try {
      if (!jsonSchema || typeof jsonSchema !== 'object') {
        return new Error('Invalid schema provided');
      }
      const ajv = new Ajv({ allErrors: true, verbose: true });
      addFormats(ajv);
      require('ajv-errors')(ajv, { singleError: true });
      return ajv.compile(jsonSchema);
    } catch (error) {
      logger.error({ log: 'schemaValidator', ref: 'Schema validation exception', error: error });
      throw new Error(`Schema validation failed: ${error.message}`);
    }
  }
  /**
   * Common validation function for schema validation
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   * @param {Function} next - Next middleware function
   * @param {Object} schema - JSON schema for validation
   * @param {Object} options - Validation options
   * @returns {void}
   */
  static validateSchema(req, res, next, schema, options = {}) {
    const { 
      errorFormat = 'structured', // 'structured', 'simple', 'custom'
      customErrorHandler = null,
      logScope = 'ValidationUtil'
    } = options;

    const { query, body } = req;
    const requestData = { ...query, ...body };

    try {
      const validate = ValidationUtil.schemaValidator(schema);
      const valid = validate(requestData);
      
      if (!!valid === false) {
        // Use custom error handler if provided
        if (customErrorHandler && typeof customErrorHandler === 'function') {
          return customErrorHandler(validate.errors, requestData, req, res);
        }

        // Use different error formats based on option
        switch (errorFormat) {
          case 'structured':
            return ValidationUtil._handleStructuredErrors(validate.errors, requestData, req, res, logScope);
          
          case 'simple':
            return ValidationUtil._handleSimpleErrors(validate.errors, req, res, logScope);
          
          case 'custom':
            return ValidationUtil._handleCustomErrors(validate.errors, requestData, req, res, logScope);
          
          default:
            return ValidationUtil._handleStructuredErrors(validate.errors, requestData, req, res, logScope);
        }
      }
      
      next();
    } catch (error) {
      logger.error({ scope: logScope, ref: 'Validation Exception', error: error });
      return res.sendWrapped(error);
    }
  }

  /**
   * Handle structured errors (default format)
   * @private
   */
  static _handleStructuredErrors(errors, requestData, req, res, logScope) {
    const formattedErrors = errors.map((error) => {
      let field = error.instancePath.replace('/', '');
      let value = error.data;
      
      // Handle required field errors
      if (error.schemaPath === '#/required') {
        const match = error.message.match(/must have required property '([^']+)'/);
        if (match) {
          field = match[1];
          value = undefined;
        }
      } else {
        // For other errors, get the specific field value
        const fieldPath = error.instancePath.replace('/', '').split('/');
        if (fieldPath.length > 0 && fieldPath[0]) {
          value = requestData[fieldPath[0]];
        }
      }
      
      return {
        field: field || 'unknown',
        message: error.message,
        value: value,
        schema: error.schemaPath
      };
    });

    logger.error({ 
      scope: logScope, 
      ref: 'Validation Failed', 
      errors: formattedErrors,
      requestData 
    });

    throw new ValidationException('Request validation failed', 'VALIDATION_FAILED', formattedErrors);
  }

  /**
   * Handle simple errors (basic format)
   * @private
   */
  static _handleSimpleErrors(errors, req, res, logScope) {
    const formattedErrors = errors.map((error) => ({
      instancePath: error.instancePath,
      message: error.message,
    }));

    logger.error({ 
      scope: logScope, 
      ref: 'Validation Failed', 
      errors: formattedErrors 
    });

    return res.status(400).sendWrapped('Validation failed', formattedErrors);
  }

  /**
   * Handle custom errors (wallet format)
   * @private
   */
  static _handleCustomErrors(errors, requestData, req, res, logScope) {
    const missingFields = errors
      .filter(error => error.keyword === 'required' || error.keyword === 'missing')
      .map(error => {
        if (error.keyword === 'required') {
          return error.params.missingProperty;
        }
        return error.instancePath.replace('/', '').replace(/\//g, '.');
      });

    const errorResponse = {
      missing_fields: missingFields,
      transaction_id: requestData.transaction_id || ''
    };

    logger.error({ 
      scope: logScope, 
      ref: 'Validation Failed', 
      errorResponse 
    });

    return res.status(400).sendWrapped('Validation failed', errorResponse);
  }

  /**
   * Create validation middleware for a specific schema
   * @param {Object} schema - JSON schema
   * @param {Object} options - Validation options
   * @returns {Function} Express middleware function
   */
  static createValidationMiddleware(schema, options = {}) {
    return (req, res, next) => {
      return ValidationUtil.validateSchema(req, res, next, schema, options);
    };
  }

  /**
   * Validate request data without middleware (for use in services)
   * @param {Object} data - Data to validate
   * @param {Object} schema - JSON schema
   * @returns {Object} Validation result
   */
  static validateData(data, schema) {
    try {
      const validate = ValidationUtil.schemaValidator(schema);
      const valid = validate(data);
      
      if (!!valid === false) {
        const formattedErrors = validate.errors.map((error) => {
          let field = error.instancePath.replace('/', '');
          let value = error.data;
          
          if (error.schemaPath === '#/required') {
            const match = error.message.match(/must have required property '([^']+)'/);
            if (match) {
              field = match[1];
              value = undefined;
            }
          } else {
            const fieldPath = error.instancePath.replace('/', '').split('/');
            if (fieldPath.length > 0 && fieldPath[0]) {
              value = data[fieldPath[0]];
            }
          }
          
          return {
            field: field || 'unknown',
            message: error.message,
            value: value,
            schema: error.schemaPath
          };
        });

        return {
          isValid: false,
          errors: formattedErrors,
          errorCount: formattedErrors.length
        };
      }
      
      return {
        isValid: true,
        errors: [],
        errorCount: 0
      };
    } catch (error) {
      return {
        isValid: false,
        errors: [{ field: 'unknown', message: 'Validation error', value: null, schema: 'unknown' }],
        errorCount: 1
      };
    }
  }
}

module.exports = { ValidationUtil };
