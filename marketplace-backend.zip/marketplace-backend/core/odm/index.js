'use strict';

const config = require('config');
const mongoose = require('mongoose');
const { logger } = require('@spice-money/common-logger');
const AMS = require('@vishant.harshadbha/application-monitoring-system');
const { createMongoConnectionString } = require('@utils');

const {
  mongodb: { marketplace: marketPlaceMongodbConfig, ams: amsConfig }
} = config;

/**
 * Create MongoDB connection options
 * @param {Object} cfg - Database configuration
 * @returns {Object} Connection options
 */
const createMongoOptions = (cfg) => ({
  host: cfg.host,
  port: cfg.port,
  database: cfg.database,
  ...(cfg.user && { user: cfg.user }),
  ...(cfg.pass && { pass: cfg.pass }),
  ...(cfg.authSource && { authSource: cfg.authSource })
});

/**
 * Create MongoDB connection
 * @param {Object} cfg - Database configuration
 * @returns {mongoose.Connection} MongoDB connection
 */
const createMongoConnection = (cfg) => {
  const options = createMongoOptions(cfg);
  const connectionString = createMongoConnectionString(options);

  return mongoose.createConnection(connectionString, {
    user: cfg.user || '',
    pass: cfg.pass || ''
  });
};

// Initialize MongoDB connections
const marketplace = createMongoConnection(marketPlaceMongodbConfig);
const ams = createMongoConnection(amsConfig);

// Initialize AMS logging
const AMSLog = new AMS(
  { ...createMongoOptions(amsConfig), username: amsConfig.user, password: amsConfig.pass },
  'info'
);

AMSLog.connect().catch(err => {
  logger.error({ ref: 'Failed to connect AMS logging', error: err });
});

module.exports = { marketplace, ams, AMSLog };


