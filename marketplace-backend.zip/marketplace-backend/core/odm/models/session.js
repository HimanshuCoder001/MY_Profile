const mongoose = require('mongoose');
const { marketplace } = require('../index');

const sessionSchema = new mongoose.Schema({
  sessionId: {
    type: String,
    required: true,
    unique: true
  },
  clientId: {
    type: String,
    required: true
  },
  aggId: {
    type: String,
    required: true
  },
  udf1: {
    type: String,
    default: null
  },
  lang: {
    type: String,
    default: 'en'
  },
  token: {
    type: String,
    required: true
  },
  validationResponse: {
    responseStatus: String,
    responseCode: String,
    responseDescription: String,
    sessionID: String,
    bcAgentID: String,
    messageDesc: String
  },
  expiresAt: {
    type: Date,
    default: function() {
      return new Date(Date.now() + 30 * 24 * 60 * 60 * 1000);
    }
  }
}, {
  timestamps: true // Automatically adds createdAt and updatedAt fields
});

// Create index for expiration
sessionSchema.index({ expiresAt: 1 }, { expireAfterSeconds: 0 });

module.exports = marketplace.model('Session', sessionSchema);
