const { Types } = require('mongoose');
const BaseSchema = require('./baseSchema');
const { marketplace } = require('..');

const LeadSchema = new BaseSchema({
    leadId: {
        type: Types.UUID,
        required: true,
        unique: true,
        index: true
    },
    applicationId: {
        type: String,
        index: true,
        required: true,
    },
    clientId: {
        type: String,
        index: true,
        required: true,
    },
    productId: {
        type: Types.UUID,
        index: true,
        required: true,
    },
    leadType: {
        type: String,
        enum: ['SHOP_INSURANCE', 'TWO_WHEELER_INSURANCE'],
        required: true,
        index: true
    },
    leadCategory: {
        type: String,
        enum: ['INSURANCE'],
        default: 'INSURANCE',
        index: true
    },
    transactionStatus: {
        type: String,
        enum: ['PENDING', 'TRANSACTION_INITIATED', 'TRANSACTION_COMPLETED', 'FAILED', 'CANCELLED', 'REJECTED'],
        default: 'PENDING',
        index: true
    },
    leadStatus: {
        type: String,
        enum: ['PENDING', 'IN_PROGRESS', 'TRANSACTION_INITIATED', 'TRANSACTION_COMPLETED', 'FAILED', 'CANCELLED', 'REJECTED', 'APPROVED', 'UNDER_REVIEW'],
        default: 'PENDING',
        index: true
    },
    flowType: {
        type: String,
        enum: ['SINGLE_FORM', 'MULTI_FORM', 'REDIRECTION'],
        required: true,
        index: true
    },
    redirectionUrl: {
        type: String,
        description: 'URL to redirect user to external portal for completing the process'
    },
    isRedirection: {
        type: Boolean,
        default: false,
        description: 'Flag to indicate if redirection is required for this lead'
    },
    partnerId: {
        type: String,
        description: 'Partner/Provider ID for the lead',
        index: true
    },
    partnerLeadId: {
        type: String,
        description: 'Lead ID from partner system',
        index: true
    },
    customerDetails: {
        fullName: String,
        mobile: String,
        email: String,
        gender: String,
        dateOfBirth: Date,
        pan: String,
        aadhar: String,
        address: {
            street: String,
            city: String,
            state: String,
            pincode: String
        }
    },
    meta: {
        type: Object,
        default: {}
    }
}, {
    timestamps: true,
});

// Indexes for better query performance
LeadSchema.index({ leadType: 1, leadStatus: 1, createdAt: -1 });
LeadSchema.index({ clientId: 1, leadType: 1, createdAt: -1 });
LeadSchema.index({ productId: 1, leadStatus: 1, createdAt: -1 });
LeadSchema.index({ partnerId: 1, partnerLeadId: 1 });
LeadSchema.index({ 'customerDetails.mobile': 1, leadType: 1 });



const LeadModel = marketplace.model('Lead', LeadSchema);
module.exports = LeadModel;