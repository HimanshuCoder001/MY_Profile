const mongoose = require('mongoose');
const { marketplace } = require('..');

const creditScoreStaticDetailsSchema = new mongoose.Schema({
  adhikariJourney: {
    checkCreditScoreHomeScreen: {
      title: String,
      logo: String, 
      banners: [String],
      additionalLogo: String,
      sliders: [String],
      creditHealthCheckupGrahak: [{ 
        steps: Number, 
        message: String 
      }],
      youtubeLink: [],
      creditHealthCheckupAdhikari: [{ 
        steps: Number, 
        message: String 
      }],
      grahakCreditHealthStrip: { 
        logo: String, 
        message: String,
      },
      adhikariCreditHealthStrip: { 
        logo: String, 
        message: String,
      },
      faqs: [{ 
        steps: Number, 
        questions: String, 
        Answer: String }],
    },
    adhikariCheckCreditHealthScreen: {
      title: String, 
      logo: String, 
      message: String, 
      additionalStrip: String,
    },
    creditScoreScreen: {},
    moneyRefundedScreen: {
      title: String,
      logo: String,
      message: String,
    },
    GrahakCheckCreditHealthScreen: {
      title: String, 
      logo: String, 
      message: String, 
      additionalStrip: String,
    },
    insufficientBalanceScreen: {
      title: String, 
      logo: String, 
      message: String, 
      additionalStrip: String,
    },
    confirmationDetailsScreenForAdhikari: { 
      title: String, 
      logo: String, 
    },
    commissionEarnedScreen: {
      title: String, 
      logo: String, 
      message: String, 
      additionalStrip: String,
    },
    awaitingSubmission: {
      title: String, 
      logo: String, 
      info: [{ 
        steps: Number, 
        message: String 
      }], 
      additionalStrip: String,
    },
    congratulationsScreen: {
      title: String, 
      logo: String, 
      message: String, 
      additionalStrip: String,
    },
    refundScreen: {
      title: String, 
      logo: String, 
      message: String, 
      additionalStrip: String,
    },
    insufficientCreditHealthScreen: {
      title: String, 
      logo: String, 
      message: String, 
      additionalStrip: String,
    },
  },
  grahakjourney: {
    confirmationDetailsScreenForGrahak: { 
      title: String, 
      logo: String, 
    },
    creditScoreScreen: {},
    Survey: {},
    errorScreen: {
      title: String, 
      logo: String, 
      message: String, 
      additionalStrip: String,
    },
  },
  form_config: {},
  experian_consent: String,
  terms_and_conditions: String,
  appStatic: {},
}, {
  timestamps: true,
});

// Compile model from schema
const creditScoreStaticDataModel = marketplace.model('credit_score_static_details', creditScoreStaticDetailsSchema);
module.exports = creditScoreStaticDataModel;


