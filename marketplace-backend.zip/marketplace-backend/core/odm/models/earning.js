const mongoose = require('mongoose');
const { marketplace } = require('..');

const earningSchema = new mongoose.Schema({
    clientId: String,
    timestamp: Date
});

// Compile model from schema
const EarningModel = marketplace.model('earning', earningSchema);
module.exports = EarningModel;


