const mongoose = require("mongoose");
const { marketplace } = require('..');

const bankSathiSchema = new mongoose.Schema(
  {
    productId: Number,
    categoryId: Number,
    productName: String,
    logo: String,
    description: [],
    lender_description: [{ 
      index: Number,
      key: String,
      value: String,
    }],
    lender_additional_details: [],
  },
  {
    timestamps: true,
  }
);

const BankSathiModel = marketplace.model("bank_sathi", bankSathiSchema);
module.exports = BankSathiModel;


