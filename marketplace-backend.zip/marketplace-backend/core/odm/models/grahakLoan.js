const mongoose = require("mongoose");
const { marketplace } = require('..');

const grahakLoanSchema = new mongoose.Schema({
    title: String,
    grahakServices: [{ 
        title: String, 
        logo: String, 
        index: Number,
    }],
    banners: [{ 
        index: Number, 
        data: String, 
        type: String,
    }],
    webBanners: [{ 
        index: Number, 
        data: String, 
        type: String,
    }],
    commissionDetails: [{ 
        index: Number, 
        column1: String, 
        column2: String,
    }],
    grahakLoanSteps: {
        title: String,
        steps: [
            { 
                index: Number, 
                title: String, 
                description: String, 
                logo: String, 
                isActive: { 
                    type: Boolean, 
                    default: true 
                },
            },
        ],
    },
    creditHealthCheck: {
        logo: String,
        first_strip: String,
        second_strip: String,
    },
    youtubeLink: String,
    faqs: [
        {
            index: Number,
            title: String,
            description: String,
        },
    ],
    timestamp: Date,
});

// Compile model from schema
const GrahakLoanStaticDataModel = marketplace.model("grahak_loan", grahakLoanSchema);
module.exports = GrahakLoanStaticDataModel;


