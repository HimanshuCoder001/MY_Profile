'use strict';

const mongoose = require('mongoose');
const { marketplace } = require('..');

const historySchema = new mongoose.Schema({
    clientId: String,
    lendorLoanRecord: String,
    loanId: String,
    customerid: String,
    customerName: String,
    lender: String,
    transactionStatus: String,
    mobileNumber: String,
    PAN: String,
    status: String,
    commissionEarned: Number,
    messageText: String,
    interestRate: Number,
    loanTenure: Number,
    transactionId: String,
    PAN: String,
    loanAmount: String,
    DisbursedAmt : String,
    adhikariEarning: String,
    applicationCreatedDate: String,
    payoutDate: String,
    fileInfo: String,
}, {
    timestamps: true,
});

const HistoryModel = marketplace.model('history_details', historySchema);
module.exports = HistoryModel;


