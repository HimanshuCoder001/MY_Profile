const mongoose = require('mongoose');

const amsLogsSchema = new mongoose.Schema({
    clientId: String,
    timestamp: Date
});

const AmsLogsModel = mongoose.model('ams_logs', amsLogsSchema );
module.exports = AmsLogsModel;


