const BaseSchema = require('./baseSchema');
const { Types, Schema } = require('mongoose');
const { marketplace } = require('..');

const FormSubmissionSchema = new BaseSchema(
  {
    formSubmissionId: { type: Types.UUID, required: true, index: true },
    applicationId: { type: String, required: true, index: true },
    clientId: { type: String, required: true, index: true },
    leadId: { type: Types.UUID, required: true, index: true },
    productId: { type: Types.UUID, required: true, index: true },
    formId: { type: Types.UUID, required: true, index: true },
    formType: { type: String, required: true, index: true },
    formKey: { type: String, required: true, index: true },
    formVersion: { type: Number, required: true, index: true },
    formLocale: { type: String, required: true, index: true },    
    data: { type: Schema.Types.Mixed, required: true },
    metadata: { type: Schema.Types.Mixed }
  },
  { timestamps: true }
);

FormSubmissionSchema.index({ productId: 1, applicationId: 1, createdAt: -1 });
FormSubmissionSchema.index({ formId: 1, createdAt: -1 });

const FormSubmission = marketplace.model('FormSubmission', FormSubmissionSchema);
module.exports = FormSubmission;
