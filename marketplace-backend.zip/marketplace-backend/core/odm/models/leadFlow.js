const BaseSchema = require('./baseSchema');
const { Types, Schema } = require('mongoose');
const { marketplace } = require('..');

const LeadFlowSchema = new BaseSchema({
    flowId: {
        type: Types.UUID,
        required: true,
        unique: true,
        index: true
    },
    leadId: {
        type: Types.UUID,
        required: true,
        index: true
    },
    applicationId: {
        type: String,
        index: true,
        required: true
    },
    clientId: {
        type: String,
        index: true,
        required: true
    },
    productId: {
        type: Types.UUID,
        index: true,
        required: true
    },
    flowType: {
        type: String,
        enum: ['SINGLE_FORM', 'MULTI_FORM', 'REDIRECTION'],
        required: true,
        index: true
    },
    flowName: {
        type: String,
        required: true
    },
    flowVersion: {
        type: Number,
        default: 1
    },
    flowSteps: [{
        stepId: String,
        stepName: String,
        stepType: {
            type: String,
            enum: ['FORM', 'KYC', 'PAYMENT', 'REDIRECTION', 'VERIFICATION', 'DEBIT', 'STATUS']
        },
        stepOrder: Number,
        isRequired: Boolean,
        isCompleted: {
            type: Boolean,
            default: false
        },
        completedAt: Date,
        formSubmissionId: String, // Reference to FormSubmission
        stepData: Schema.Types.Mixed
    }],
    currentStep: {
        type: String,
        default: null
    },
    completedSteps: [{
        stepId: String,
        stepName: String,
        completedAt: Date,
        stepData: Schema.Types.Mixed
    }],
    flowStatus: {
        type: String,
        enum: ['PENDING', 'IN_PROGRESS', 'COMPLETED', 'FAILED', 'CANCELLED'],
        default: 'PENDING',
        index: true
    },
    flowMetadata: {
        totalSteps: {
            type: Number,
            default: 0
        },
        completedStepsCount: {
            type: Number,
            default: 0
        },
        progressPercentage: {
            type: Number,
            default: 0
        },
        estimatedCompletionTime: Date,
        actualCompletionTime: Date
    },
    configuration: {
        type: Schema.Types.Mixed,
        default: {}
    }
}, {
    timestamps: true,
});

// Indexes for better query performance
LeadFlowSchema.index({ leadId: 1, flowType: 1, createdAt: -1 });
LeadFlowSchema.index({ clientId: 1, flowType: 1, createdAt: -1 });
LeadFlowSchema.index({ flowStatus: 1, currentStep: 1 });
LeadFlowSchema.index({ 'flowSteps.stepId': 1 });



const LeadFlow = marketplace.model('LeadFlow', LeadFlowSchema);
module.exports = LeadFlow;
