const { Schema } = require('mongoose');

/**
 * Base schema with UUID transformation
 * Provides common functionality for all models that use UUID fields
 */
class BaseSchema extends Schema {
    constructor(definition, options = {}) {
        super(definition, options);
        
        // Add UUID transformation to toJSON
        this.set('toJSON', {
            transform: function(doc, ret) {
                // Convert Buffer UUIDs to strings
                const uuidFields = ['leadId', 'leadDetailId', 'flowId', 'productId', 'applicationId'];
                
                uuidFields.forEach(field => {
                    if (ret[field]) {
                        if (Buffer.isBuffer(ret[field])) {
                            ret[field] = ret[field].toString('hex').replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5');
                        } else if (ret[field] && typeof ret[field] === 'object' && ret[field].type === 'Buffer' && Array.isArray(ret[field].data)) {
                            const buffer = Buffer.from(ret[field].data);
                            ret[field] = buffer.toString('hex').replace(/(.{8})(.{4})(.{4})(.{4})(.{12})/, '$1-$2-$3-$4-$5');
                        }
                    }
                });
                
                return ret;
            }
        });
    }
}

module.exports = BaseSchema;
