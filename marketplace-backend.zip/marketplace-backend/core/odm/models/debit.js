const mongoose = require('mongoose');
const { marketplace } = require('..');

const debitSchema = new mongoose.Schema({
    clientId: { type: String, required: true },
    sessionId: { type: String},
    requestType: { type: String }, // e.g. 'INSURANCE'
    requestPayload: { type: mongoose.Schema.Types.Mixed },
    debitResponse: { type: mongoose.Schema.Types.Mixed },
    updateResponse: { type: mongoose.Schema.Types.Mixed },
    requestId: { type: String },
    walletRequestId: { type: String },
    status: { type: String },
  }, { timestamps: true });

// Compile model from schema
const debitModel = marketplace.model('debit', debitSchema);
module.exports = debitModel;
