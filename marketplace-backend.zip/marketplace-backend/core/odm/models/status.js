const mongoose = require('mongoose');
const { marketplace } = require('..');

const statusSchema = new mongoose.Schema({
    clientId: { type: String, required: true },
    statusResponse: { type: mongoose.Schema.Types.Mixed },
    status: { type: String },
  }, { timestamps: true });

// Compile model from schema
const statustModel = marketplace.model('status', statusSchema);
module.exports = statustModel;
