const BaseSchema = require('./baseSchema');
const { Types, Schema } = require('mongoose');
const { marketplace } = require('..');

const LeadDetailsSchema = new BaseSchema({
    leadDetailId: {
        type: Types.UUID,   
        required: true,
        unique: true,
        index: true
    },
    leadId: {
        type: Types.UUID,
        required: true,
        index: true
    },
    applicationId: {
        type: String,
        index: true,
        required: true
    },
    clientId: {
        type: String,
        index: true,
        required: true
    },
    productId: {
        type: Types.UUID,
        index: true,
        required: true
    },
    leadType: {
        type: String,
        enum: ['SHOP_INSURANCE', 'TWO_WHEELER_INSURANCE'],
        required: true,
        index: true
    },
    // Reference to latest form submission (for quick access)
    latestFormSubmissionId: {
        type: String,
        index: true
    },
    insuranceDetails: {
        policyType: String,
        coverageAmount: Number,
        premiumAmount: Number,
        policyTerm: String,
        vehicleDetails: {
            vehicleType: String,
            make: String,
            model: String,
            year: Number,
            registrationNumber: String,
            engineNumber: String,
            chassisNumber: String
        },
        nomineeDetails: {
            name: String,
            relationship: String,
            mobile: String,
            dateOfBirth: Date
        }
    },
    documents: [{
        documentType: String,
        documentNumber: String,
        documentUrl: String,
        uploadDate: Date,
        verificationStatus: {
            type: String,
            enum: ['PENDING', 'VERIFIED', 'REJECTED'],
            default: 'PENDING'
        }
    }],
    kycDetails: {
        aadharVerified: Boolean,
        panVerified: Boolean,
        bankAccountVerified: Boolean,
        verificationDate: Date,
        verificationMethod: String
    },
    partnerDetails: {
        partnerId: String,
        partnerLeadId: String,
        partnerResponse: Schema.Types.Mixed,
        integrationStatus: String
    },
    currentStep: {
        type: String,
        default: 'FORM_SUBMISSION'
    },
    metadata: {
        type: Schema.Types.Mixed,
        default: {}
    }
}, {
    timestamps: true,
});

// Indexes for better query performance
LeadDetailsSchema.index({ leadId: 1, leadType: 1, createdAt: -1 });
LeadDetailsSchema.index({ clientId: 1, leadType: 1, createdAt: -1 });
LeadDetailsSchema.index({ latestFormSubmissionId: 1 });



const LeadDetails = marketplace.model('LeadDetails', LeadDetailsSchema);
module.exports = LeadDetails;
