'use strict';

const { LoggerFactory } = require('@logger');
const HistoryModel = require('@odm/models/history');

class HistoryService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(HistoryService.name);
    this.model = HistoryModel;
  }

  static getInstance() {
    if (!HistoryService.instance) {
      HistoryService.instance = new HistoryService();
    }
    return HistoryService.instance;
  }

  async find(filter = {}, projection = null, options = {}) {
    return await this.model.find(filter, projection, options);
  }

  async findOne(filter = {}, projection = null, options = {}) {
    return await this.model.findOne(filter, projection, options);
  }

  async create(data) {
    return await this.model.create(data);
  }

  async update(filter, update, options = {}) {
    return await this.model.updateOne(filter, update, options);
  }

  async aggregate(pipeline = []) {
    return await this.model.aggregate(pipeline);
  }
}

module.exports = { HistoryService };


