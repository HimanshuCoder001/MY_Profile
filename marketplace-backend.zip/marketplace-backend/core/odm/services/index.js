'use strict';

module.exports = {
  ...require('./history.service'),
  ...require('./grahakLoan.service'),
  ...require('./creditScoreStatic.service'),
  ...require('./earning.service'),
  ...require('./bankSathi.service'),
  ...require('./amsLogs.service'),
  ...require('./lead.service'),
  ...require('./formSubmission.service'),
};


