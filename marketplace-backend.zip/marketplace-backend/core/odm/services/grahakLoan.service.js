'use strict';

const { LoggerFactory } = require('@logger');
const GrahakLoanModel = require('@odm/models/grahakLoan');

class GrahakLoanOdmService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(GrahakLoanOdmService.name);
    this.model = GrahakLoanModel;
  }

  static getInstance() {
    if (!GrahakLoanOdmService.instance) {
      GrahakLoanOdmService.instance = new GrahakLoanOdmService();
    }
    return GrahakLoanOdmService.instance;
  }

  async getOne() {
    return await this.model.findOne().lean();
  }

  async create(data) {
    return await this.model.create(data);
  }

  async upsertOne(values) {
    const isExist = await this.model.findOne().lean();
    if (!isExist) return await this.create(values);
    return await this.model.findByIdAndUpdate(isExist._id, { ...isExist, ...values }, { new: true });
  }

  async aggregate(pipeline = []) {
    return await this.model.aggregate(pipeline);
  }
}

module.exports = { GrahakLoanOdmService };


