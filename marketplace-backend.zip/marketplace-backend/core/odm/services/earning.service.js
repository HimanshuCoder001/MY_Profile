'use strict';

const { LoggerFactory } = require('@logger');
const EarningModel = require('@odm/models/earning');

class EarningService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(EarningService.name);
    this.model = EarningModel;
  }

  static getInstance() {
    if (!EarningService.instance) {
      EarningService.instance = new EarningService();
    }
    return EarningService.instance;
  }

  async find(filter = {}, projection = null, options = {}) {
    return await this.model.find(filter, projection, options);
  }
}

module.exports = { EarningService };


