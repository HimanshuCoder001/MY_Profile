'use strict';

const { LoggerFactory } = require('@logger');
const AmsLogsModel = require('@odm/models/amsLogs');

class AmsLogsService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(AmsLogsService.name);
    this.model = AmsLogsModel;
  }

  static getInstance() {
    if (!AmsLogsService.instance) {
      AmsLogsService.instance = new AmsLogsService();
    }
    return AmsLogsService.instance;
  }

  async list(filter = {}, projection = null, options = {}) {
    return await this.model.find(filter, projection, options);
  }
}

module.exports = { AmsLogsService };


