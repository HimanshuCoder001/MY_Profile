'use strict';

const { LoggerFactory } = require('@logger');
const BankSathiModel = require('@odm/models/bankSathi');

class BankSathiService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(BankSathiService.name);
    this.model = BankSathiModel;
  }

  static getInstance() {
    if (!BankSathiService.instance) {
      BankSathiService.instance = new BankSathiService();
    }
    return BankSathiService.instance;
  }

  async list(filter = {}, projection = null, options = {}) {
    return await this.model.find(filter, projection, options);
  }

  async upsertOne(filter, values) {
    return await this.model.findOneAndUpdate(filter, values, { upsert: true, new: true });
  }
}

module.exports = { BankSathiService };


