'use strict';

const { LoggerFactory } = require('@logger');
const { v4: uuidv4 } = require('uuid');
const LeadModel = require('@odm/models/lead');
const LeadDetailsModel = require('@odm/models/leadDetails');
const LeadFlowModel = require('@odm/models/leadFlow');
const FormSubmissionModel = require('@odm/models/formSubmission');
const { UUID } = require('bson');

class LeadService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(LeadService.name);
  }

  /**
   * Get instance of LeadService
   * @returns {LeadService} - Instance of LeadService
   */
  static getInstance() {
    if (!LeadService.instance) {
      LeadService.instance = new LeadService();
    }
    return LeadService.instance;
  }

  /**
   * Create a new lead with all related data
   * @param {Object} leadData - Lead data
   * @param {Object} flowConfig - Flow configuration
   * @returns {Promise<Object>} - Created lead with details
   */
  async createLeadWithDetails(leadData, flowConfig = null) {
    try {
      // Generate UUIDs for internal IDs
      const leadId = uuidv4();
      const leadDetailId = uuidv4();
      const flowId = uuidv4();
      
      // Create lead
      const lead = await LeadModel.create({
        leadId,
        applicationId: leadData.applicationId,
        clientId: leadData.clientId,
        productId: leadData.productId,
        leadType: leadData.leadType,
        leadCategory: leadData.leadCategory,
        flowType: leadData.flowType,
        redirectionUrl: leadData.redirectionUrl,
        isRedirection: leadData.isRedirection,
        partnerId: leadData.partnerId,
        partnerLeadId: leadData.partnerLeadId,
        customerDetails: leadData.customerDetails,
        meta: leadData.meta || {}
      });

      // Create lead details
      const leadDetails = await LeadDetailsModel.create({
        leadDetailId,
        leadId,
        applicationId: leadData.applicationId,
        clientId: leadData.clientId,
        productId: leadData.productId,
        leadType: leadData.leadType,
        insuranceDetails: leadData.insuranceDetails,
        documents: leadData.documents || [],
        kycDetails: leadData.kycDetails || {},
        partnerDetails: leadData.partnerDetails || {},
        metadata: leadData.metadata || {}
      });

      // Create lead flow if flow config provided
      let leadFlow = null;
      if (flowConfig) {
        leadFlow = await LeadFlowModel.create({
          flowId,
          leadId,
          applicationId: leadData.applicationId,
          clientId: leadData.clientId,
          productId: leadData.productId,
          flowType: flowConfig.flowType,
          flowName: flowConfig.flowName,
          flowVersion: flowConfig.flowVersion || 1,
          flowSteps: flowConfig.flowSteps || [],
          currentStep: flowConfig.currentStep || null,
          flowMetadata: {
            totalSteps: flowConfig.flowSteps?.length || 0,
            completedStepsCount: 0,
            progressPercentage: 0
          },
          configuration: flowConfig.configuration || {}
        });
      }

      return { lead, leadDetails, leadFlow };
    } catch (error) {
      this.logger.error({ ref: 'createLeadWithDetails error', error });
      throw error;
    }
  }

  /**
   * Create lead details from form submission
   * @param {Object} formSubmission - Form submission data
   * @param {Object} leadData - Additional lead data
   * @returns {Promise<Object>} - Created lead details
   */
  async createLeadDetailsFromFormSubmission(formSubmission, leadData) {
    try {
      const leadDetailId = uuidv4();
      
      const leadDetails = await LeadDetailsModel.create({
        leadDetailId,
        leadId: formSubmission.leadId,
        applicationId: formSubmission.applicationId,
        clientId: formSubmission.clientId,
        productId: formSubmission.productId,
        latestFormSubmissionId: formSubmission.formSubmissionId,
        leadType: leadData.leadType,
        insuranceDetails: leadData.insuranceDetails,
        documents: leadData.documents || [],
        kycDetails: leadData.kycDetails || {},
        partnerDetails: leadData.partnerDetails || {},
        currentStep: 'FORM_SUBMISSION',
        metadata: leadData.metadata || {}
      });

      return leadDetails;
    } catch (error) {
      this.logger.error({ ref: 'createLeadDetailsFromFormSubmission error', error });
      throw error;
    }
  }

  /**
   * Update lead status and flow
   * @param {string} leadId - Lead ID
   * @param {string} status - New status
   * @param {Object} flowData - Flow update data
   * @returns {Promise<Object>} - Updated lead
   */
  async updateLeadStatusAndFlow(leadId, status, flowData = null) {
    try {
      const updateData = { leadStatus: status };
      
      if (status === 'TRANSACTION_INITIATED' || status === 'TRANSACTION_COMPLETED') {
        updateData.transactionStatus = status;
      }

      const lead = await LeadModel.findOneAndUpdate(
        { leadId },
        updateData,
        { new: true }
      );

      if (flowData) {
        await LeadFlowModel.findOneAndUpdate(
          { leadId },
          {
            $set: {
              currentStep: flowData.currentStep,
              flowStatus: flowData.flowStatus || 'IN_PROGRESS'
            },
            $push: {
              completedSteps: flowData.completedStep
            }
          },
          { new: true }
        );
      }

      return lead;
    } catch (error) {
      this.logger.error({ ref: 'updateLeadStatusAndFlow error', error });
      throw error;
    }
  }

  /**
   * Get lead with all details and flow information
   * @param {string} leadId - Lead ID
   * @returns {Promise<Object>} - Lead with details
   */
  async getLeadWithDetails(leadId) {
    try {
      const result = await LeadModel.aggregate([
        {
          $match: { leadId: new UUID(leadId) }
        },
        {
          $lookup: {
            from: 'leaddetails',
            localField: 'leadId',
            foreignField: 'leadId',
            as: 'leadDetails'
          }
        },
        {
          $lookup: {
            from: 'leadflows',
            localField: 'leadId',
            foreignField: 'leadId',
            as: 'leadFlow'
          }
        },
        {
          $addFields: {
            leadDetails: { $arrayElemAt: ['$leadDetails', 0] },
            leadFlow: { $arrayElemAt: ['$leadFlow', 0] }
          }
        },
        {
          $project: {
            _id: 1,
            leadId: 1,
            applicationId: 1,
            clientId: 1,
            productId: 1,
            leadType: 1,
            leadCategory: 1,
            transactionStatus: 1,
            leadStatus: 1,
            flowType: 1,
            redirectionUrl: 1,
            isRedirection: 1,
            customerDetails: 1,
            meta: 1,
            createdAt: 1,
            updatedAt: 1,
            __v: 1,
            leadDetails: 1,
            leadFlow: 1
          }
        }
      ]);

      if (!result || result.length === 0) return null;

      return result[0];
    } catch (error) {
      this.logger.error({ ref: 'getLeadWithDetails error', error });
      throw error;
    }
  }

  /**
   * Get lead with all details and form submissions
   * @param {string} leadId - Lead ID
   * @returns {Promise<Object>} - Lead with details and form submissions
   */
  async getLeadWithDetailsAndFormSubmissions(leadId) {
    try {
      const lead = await LeadModel.findOne({ leadId });
      if (!lead) return null;

      const [leadDetails, leadFlow, formSubmissions] = await Promise.all([
        LeadDetailsModel.findOne({ leadId }),
        LeadFlowModel.findOne({ leadId }),
        FormSubmissionModel.find({ leadId }).sort({ createdAt: -1 })
      ]);

      return {
        lead,
        leadDetails,
        leadFlow,
        formSubmissions
      };
    } catch (error) {
      this.logger.error({ ref: 'getLeadWithDetailsAndFormSubmissions error', error });
      throw error;
    }
  }

  /**
   * Find lead by ID
   * @param {string} leadId - Lead ID
   * @returns {Promise<Object>} - Lead document
   */
  async findLeadById(leadId) {
    try {
      return await LeadModel.findOne({ leadId });
    } catch (error) {
      this.logger.error({ ref: 'findLeadById error', error });
      throw error;
    }
  }

  /**
   * Find lead details by lead ID
   * @param {string} leadId - Lead ID
   * @returns {Promise<Object>} - Lead details document
   */
  async findLeadDetailsByLeadId(leadId) {
    try {
      return await LeadDetailsModel.findOne({ leadId });
    } catch (error) {
      this.logger.error({ ref: 'findLeadDetailsByLeadId error', error });
      throw error;
    }
  }

  /**
   * Find lead flow by lead ID
   * @param {string} leadId - Lead ID
   * @returns {Promise<Object>} - Lead flow document
   */
  async findLeadFlowByLeadId(leadId) {
    try {
      return await LeadFlowModel.findOne({ leadId });
    } catch (error) {
      this.logger.error({ ref: 'findLeadFlowByLeadId error', error });
      throw error;
    }
  }

  /**
   * Update lead document
   * @param {string} leadId - Lead ID
   * @param {Object} updateData - Data to update
   * @returns {Promise<Object>} - Updated lead document
   */
  async updateLead(leadId, updateData) {
    try {
      return await LeadModel.findOneAndUpdate(
        { leadId },
        updateData,
        { new: true }
      );
    } catch (error) {
      this.logger.error({ ref: 'updateLead error', error });
      throw error;
    }
  }

  /**
   * Update lead details document
   * @param {string} leadId - Lead ID
   * @param {Object} updateData - Data to update
   * @returns {Promise<Object>} - Updated lead details document
   */
  async updateLeadDetails(leadId, updateData) {
    try {
      return await LeadDetailsModel.findOneAndUpdate(
        { leadId },
        updateData,
        { new: true }
      );
    } catch (error) {
      this.logger.error({ ref: 'updateLeadDetails error', error });
      throw error;
    }
  }

  /**
   * Update lead flow document
   * @param {string} leadId - Lead ID
   * @param {Object} updateData - Data to update
   * @returns {Promise<Object>} - Updated lead flow document
   */
  async updateLeadFlow(leadId, updateData) {
    try {
      return await LeadFlowModel.findOneAndUpdate(
        { leadId },
        updateData,
        { new: true }
      );
    } catch (error) {
      this.logger.error({ ref: 'updateLeadFlow error', error });
      throw error;
    }
  }

  /**
   * Delete lead and related data
   * @param {string} leadId - Lead ID
   * @returns {Promise<boolean>} - Success status
   */
  async deleteLead(leadId) {
    try {
      await Promise.all([
        LeadModel.deleteOne({ leadId }),
        LeadDetailsModel.deleteOne({ leadId }),
        LeadFlowModel.deleteOne({ leadId })
      ]);
      
      return true;
    } catch (error) {
      this.logger.error({ ref: 'deleteLead error', error });
      throw error;
    }
  }
}

module.exports = { LeadService };
