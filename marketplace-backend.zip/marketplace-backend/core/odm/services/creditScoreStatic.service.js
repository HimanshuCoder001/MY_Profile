'use strict';

const { LoggerFactory } = require('@logger');
const CreditScoreStaticModel = require('@odm/models/creditScoreStatic');

class CreditScoreStaticService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(CreditScoreStaticService.name);
    this.model = CreditScoreStaticModel;
  }

  static getInstance() {
    if (!CreditScoreStaticService.instance) {
      CreditScoreStaticService.instance = new CreditScoreStaticService();
    }
    return CreditScoreStaticService.instance;
  }

  async getOne() {
    return await this.model.findOne().lean();
  }

  async create(data) {
    return await this.model.create(data);
  }

  async updateById(id, values) {
    return await this.model.findByIdAndUpdate(id, values, { new: true });
  }
}

module.exports = { CreditScoreStaticService };


