'use strict';

const { LoggerFactory } = require('@logger');
const { v4: uuidv4 } = require('uuid');
const FormSubmissionModel = require('@odm/models/formSubmission');
const LeadDetailsModel = require('@odm/models/leadDetails');
const LeadFlowModel = require('@odm/models/leadFlow');

class FormSubmissionService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(FormSubmissionService.name);
  }

  /**
   * Get instance of FormSubmissionService
   * @returns {FormSubmissionService} - Instance of FormSubmissionService
   */
  static getInstance() {
    if (!FormSubmissionService.instance) {
      FormSubmissionService.instance = new FormSubmissionService();
    }
    return FormSubmissionService.instance;
  }

  /**
   * Create a new form submission and update lead flow
   * @param {Object} formData - Form submission data
   * @param {string} stepId - Current step ID
   * @returns {Promise<Object>} - Created form submission and updated flow
   */
  async createFormSubmission(formData, stepId) {
    try {
      const formSubmissionId = uuidv4();
      
      // Create form submission
      const formSubmission = await FormSubmissionModel.create({
        formSubmissionId,
        applicationId: formData.applicationId,
        clientId: formData.clientId,
        leadId: formData.leadId,
        productId: formData.productId,
        formId: formData.formId,
        formType: formData.formType,
        formKey: formData.formKey,
        formVersion: formData.formVersion,
        formLocale: formData.formLocale,
        data: formData.data,
        metadata: formData.metadata || {}
      });

      // Update lead flow to mark step as completed
      await LeadFlowModel.findOneAndUpdate(
        { leadId: formData.leadId },
        {
          $set: {
            currentStep: 'redirection', // Move to next step
            'flowSteps.$[step].isCompleted': true,
            'flowSteps.$[step].completedAt': new Date(),
            'flowSteps.$[step].formSubmissionId': formSubmissionId,
            'flowSteps.$[step].stepData': formData.data
          },
          $inc: {
            'flowMetadata.completedStepsCount': 1
          }
        },
        {
          arrayFilters: [{ 'step.stepId': 'basic_details' }], // Match the actual step ID
          new: true
        }
      );

      // Also mark redirection step as completed since URL is generated
      await LeadFlowModel.findOneAndUpdate(
        { leadId: formData.leadId },
        {
          $set: {
            'flowSteps.$[step].isCompleted': true,
            'flowSteps.$[step].completedAt': new Date(),
            'flowSteps.$[step].stepData': { redirectionUrl: formData.redirectionUrl }
          }
        },
        {
          arrayFilters: [{ 'step.stepId': 'redirection' }],
          new: true
        }
      );

      // Recalculate flow metadata and progress
      await this.recalculateFlowMetadata(formData.leadId);

      // Update lead details with latest submission reference
      await this.updateLeadDetailsWithLatestSubmission(formData.leadId, formSubmissionId, formData.formType);

      return formSubmission;
    } catch (error) {
      this.logger.error({ ref: 'createFormSubmission error', error });
      throw error;
    }
  }

  /**
   * Update lead details with latest form submission reference
   * @param {string} leadId - Lead ID
   * @param {string} formSubmissionId - Latest form submission ID
   * @param {string} formType - Form type
   */
  async updateLeadDetailsWithLatestSubmission(leadId, formSubmissionId, formType) {
    try {
      await LeadDetailsModel.findOneAndUpdate(
        { leadId },
        {
          $set: {
            latestFormSubmissionId: formSubmissionId,
            currentStep: formType
          }
        }
      );
    } catch (error) {
      this.logger.error({ ref: 'updateLeadDetailsWithLatestSubmission error', error });
      throw error;
    }
  }

  /**
   * Get all form submissions for a lead
   * @param {string} leadId - Lead ID
   * @returns {Promise<Array>} - Form submissions
   */
  async getFormSubmissionsByLeadId(leadId) {
    try {
      return await FormSubmissionModel.find({ leadId }).sort({ createdAt: -1 });
    } catch (error) {
      this.logger.error({ ref: 'getFormSubmissionsByLeadId error', error });
      throw error;
    }
  }

  /**
   * Get form submission by ID
   * @param {string} formSubmissionId - Form submission ID
   * @returns {Promise<Object>} - Form submission
   */
  async getFormSubmissionById(formSubmissionId) {
    try {
      return await FormSubmissionModel.findOne({ formSubmissionId });
    } catch (error) {
      this.logger.error({ ref: 'getFormSubmissionById error', error });
      throw error;
    }
  }

  /**
   * Get form submissions by step type
   * @param {string} leadId - Lead ID
   * @param {string} formType - Form type
   * @returns {Promise<Array>} - Form submissions
   */
  async getFormSubmissionsByType(leadId, formType) {
    try {
      return await FormSubmissionModel.find({ 
        leadId, 
        formType 
      }).sort({ createdAt: -1 });
    } catch (error) {
      this.logger.error({ ref: 'getFormSubmissionsByType error', error });
      throw error;
    }
  }

  /**
   * Get processed form data by type (extracts specific fields from form submissions)
   * @param {string} leadId - Lead ID
   * @param {string} formType - Form type
   * @returns {Promise<Object>} - Processed form data
   */
  async getProcessedFormDataByType(leadId, formType) {
    try {
      const submissions = await FormSubmissionModel.find({ 
        leadId, 
        formType 
      }).sort({ createdAt: -1 });

      if (submissions.length === 0) return null;

      // Get the latest submission
      const latestSubmission = submissions[0];
      
      // Extract and process specific fields based on form type
      const processedData = this.processFormDataByType(latestSubmission.data, formType);
      
      return {
        formSubmissionId: latestSubmission.formSubmissionId,
        formType: latestSubmission.formType,
        submittedAt: latestSubmission.createdAt,
        data: processedData,
        allSubmissions: submissions // Include all submissions for history
      };
    } catch (error) {
      this.logger.error({ ref: 'getProcessedFormDataByType error', error });
      throw error;
    }
  }

  /**
   * Process form data based on form type
   * @param {Object} formData - Raw form data
   * @param {string} formType - Form type
   * @returns {Object} - Processed form data
   */
  processFormDataByType(formData, formType) {
    switch (formType) {
      case 'BASIC_DETAILS':
        return {
          customerName: formData.fullName || formData.name,
          email: formData.email,
          mobile: formData.mobile || formData.phone,
          dateOfBirth: formData.dateOfBirth,
          gender: formData.gender
        };
      
      case 'VEHICLE_DETAILS':
        return {
          vehicleType: formData.vehicleType,
          make: formData.make,
          model: formData.model,
          year: formData.year,
          registrationNumber: formData.registrationNumber,
          engineNumber: formData.engineNumber,
          chassisNumber: formData.chassisNumber
        };
      
      case 'KYC_DETAILS':
        return {
          panNumber: formData.pan,
          aadharNumber: formData.aadhar,
          address: formData.address,
          bankDetails: formData.bankDetails
        };
      
      default:
        return formData; // Return raw data for unknown types
    }
  }

  /**
   * Recalculate flow metadata and update progress
   * @param {string} leadId - Lead ID
   */
  async recalculateFlowMetadata(leadId) {
    try {
      const leadFlow = await LeadFlowModel.findOne({ leadId });
      if (!leadFlow) return;

      const totalSteps = leadFlow.flowSteps.length;
      const completedSteps = leadFlow.flowSteps.filter(step => step.isCompleted).length;
      const progressPercentage = totalSteps > 0 ? Math.round((completedSteps / totalSteps) * 100) : 0;

      // Determine flow status based on completion
      let flowStatus = 'PENDING';
      if (completedSteps === totalSteps && totalSteps > 0) {
        flowStatus = 'COMPLETED';
      } else if (completedSteps > 0) {
        flowStatus = 'IN_PROGRESS';
      }

      await LeadFlowModel.findOneAndUpdate(
        { leadId },
        {
          $set: {
            'flowMetadata.totalSteps': totalSteps,
            'flowMetadata.completedStepsCount': completedSteps,
            'flowMetadata.progressPercentage': progressPercentage,
            flowStatus: flowStatus
          }
        }
      );
    } catch (error) {
      this.logger.error({ ref: 'recalculateFlowMetadata error', error });
      throw error;
    }
  }
}

module.exports = { FormSubmissionService };
