'use strict';

const { LoggerFactory } = require('@logger');
const { marketPlaceSqModels } = require('@orm');
const { BaseService } = require('./base.service');

class ServiceableClientsService extends BaseService {
  static instance = null;

  constructor() {
    super(marketPlaceSqModels.ServiceableClients);
    this.logger = LoggerFactory.getLogger(ServiceableClientsService.name);
  }

  /**
   * Get instance of ServiceableClientsService
   * @returns {ServiceableClientsService} - Instance of ServiceableClientsService
   */
  static getInstance() {
    if (!ServiceableClientsService.instance) {
      ServiceableClientsService.instance = new ServiceableClientsService();
    }
    return ServiceableClientsService.instance;
  }
}

module.exports = { ServiceableClientsService };


