'use strict';

const { LoggerFactory } = require('@logger');
const { marketPlaceSqModels } = require('@orm');
const { BaseService } = require('./base.service');

class ProductBannerService extends BaseService {
  static instance = null;

  constructor() {
    super(marketPlaceSqModels.ProductBanners);
    this.logger = LoggerFactory.getLogger(ProductBannerService.name);

    this.productBannerFields = this.model.AttributeFields;
  }

  /**
   * Get instance of ProductBannerService
   * @returns {ProductBannerService} - Instance of ProductBannerService
   */
  static getInstance() {
    if (!ProductBannerService.instance) {
      ProductBannerService.instance = new ProductBannerService();
    }
    return ProductBannerService.instance;
  }

  /**
   * Get product banners by product ID
   * @param {string} productId - Product ID
   * @returns {Promise<Array>} - List of product banners
   */
  async getProductBanners(productId) {
    return await this.list({ [this.productBannerFields.PRODUCT_ID]: productId, [this.productBannerFields.IS_ACTIVE]: true }, {
      attributes: [
        this.productBannerFields.BANNER_ID,
        this.productBannerFields.TITLE,
        this.productBannerFields.SUBTITLE,
        this.productBannerFields.TYPE,
        this.productBannerFields.KEY,
        this.productBannerFields.BANNER_ICON,
        this.productBannerFields.DESCRIPTION,
        this.productBannerFields.IMAGE_URL,
        this.productBannerFields.MOBILE_IMAGE_URL,
        this.productBannerFields.ICON_URL,
        this.productBannerFields.TARGET_URL,
        this.productBannerFields.ORDER,
        this.productBannerFields.IS_ACTIVE,
        this.productBannerFields.META,
        this.productBannerFields.CREATED_AT,
        this.productBannerFields.UPDATED_AT
      ],
      order: [[this.productBannerFields.ORDER, 'ASC']]
    });
  }
}

module.exports = { ProductBannerService };


