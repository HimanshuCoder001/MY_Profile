'use strict';

const { LoggerFactory } = require('@logger');
const { marketPlaceSqModels } = require('@orm');
const { BaseService } = require('./base.service');

class ProductsService extends BaseService {
  static instance = null;

  constructor() {
    super(marketPlaceSqModels.Products);
    this.logger = LoggerFactory.getLogger(ProductsService.name);
    this.productDetailsModel = marketPlaceSqModels.ProductDetails;
    
    this.productFields = this.model.AttributeFields;
    this.productDetailFields = this.productDetailsModel.AttributeFields;
  }

  /**
   * Get instance of ProductsService
   * @returns {ProductsService} - Instance of ProductsService
   */
  static getInstance() {
    if (!ProductsService.instance) {
      ProductsService.instance = new ProductsService();
    }
    return ProductsService.instance;
  }

  /**
   * Get common include options for products with details and banners
   * @param {Object} options - Additional options
   * @returns {Object} - Include options
   */
  getCommonIncludeOptions(options = {}) {
    const defaultIncludes = [
      {
        model: this.model,
        as: 'subTiles',
        where: { [this.productFields.IS_ACTIVE]: true },
        required: false,
        ...this.getAttributes(),
      }
    ];

    return {
      include: options.include ? [...defaultIncludes, ...options.include] : defaultIncludes,
      ...options
    };
  }

  getAttributes() {
    return {
      attributes: [this.productFields.PRODUCT_ID, this.productFields.NAME, this.productFields.TYPE, this.productFields.ICON, this.productFields.META],
    };
  }

  /**
   * Get extended include options with parent and children
   * @param {Object} options - Additional options
   * @returns {Object} - Extended include options
   */
  getExtendedIncludeOptions(options = {}) {
    const extendedIncludes = [
      {
        model: this.productDetailsModel,
        as: 'details',
        where: { [this.productDetailFields.IS_ACTIVE]: true },
        attributes: [
          this.productDetailFields.DETAIL_ID,
          this.productDetailFields.CATEGORY,
          this.productDetailFields.SUB_CATEGORY,
          this.productDetailFields.PARTNER_AVAILABILITY,
          this.productDetailFields.COMPETITION_BENCHMARKING,
          this.productDetailFields.OPPORTUNITY_TYPE,
          this.productDetailFields.FAQ,
          this.productDetailFields.META
        ],
        required: false
      }
    ];

    return {
      include: options.include ? [...extendedIncludes, ...options.include] : extendedIncludes,
      ...options
    };
  }

  /**
   * Get products with common include options
   * @param {Object} where - Where clause
   * @param {Object} options - Query options
   * @returns {Promise<Array>} - List of products with includes
   */
  async listWithIncludes(where = {}, options = {}) {
    const includeOptions = this.getCommonIncludeOptions({
      ...options, attributes: [
        this.productFields.PRODUCT_ID,
        this.productFields.NAME,
        this.productFields.TYPE,
        this.productFields.META,
        this.productFields.ICON
      ],
      order: [[this.productFields.CREATED_AT, 'DESC']]
    });
    return await this.list({ ...where, [this.productFields.PARENT_ID]: null, [this.productFields.IS_ACTIVE]: true }, includeOptions);
  }

  /**
   * Get product by ID with extended includes
   * @param {string} productId - Product ID
   * @param {Object} options - Query options
   * @returns {Promise<Object>} - Product with extended includes
   */
  async getByIdWithExtendedIncludes(productId, options = {}) {
    const extendedOptions = this.getExtendedIncludeOptions({ ...options, ...this.getAttributes() });
    return await this.getById(productId, extendedOptions);
  }
}

module.exports = { ProductsService };


