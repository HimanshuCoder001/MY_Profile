'use strict';

const { LoggerFactory } = require('@logger');
const { marketPlaceSqModels } = require('@orm');
const { BaseService } = require('./base.service');

class ProductFormService extends BaseService {
  static instance = null;

  constructor() {
    super(marketPlaceSqModels.ProductForms);
    this.logger = LoggerFactory.getLogger(ProductFormService.name);

    this.productFormFields = this.model.AttributeFields;
  }

  /**
   * Get instance of ProductFormService
   * @returns {ProductFormService} - Instance of ProductFormService
   */
  static getInstance() {
    if (!ProductFormService.instance) {
      ProductFormService.instance = new ProductFormService();
    }
    return ProductFormService.instance;
  }

  /**
   * Get form by product id
   * @param {string} productId - Product ID
   * @param {string} type - Form type
   * @param {Object} options - Options
   * @param {string} options.locale - Locale
   * @returns {Promise<Object>} - Form object
   */
  async getFormByProductId(productId, type, options = {}) {
    try {
      const { locale } = options;
      const where = {
        [this.productFormFields.PRODUCT_ID]: productId,
        [this.productFormFields.IS_ACTIVE]: true,
        [this.productFormFields.FORM_TYPE]: type,
        ...(locale && { [this.productFormFields.LOCALE]: locale }),
      };

      return await this.model.findOne({
        where: where,
        attributes: [
          this.productFormFields.FORM_ID,
          this.productFormFields.NAME,
          this.productFormFields.DESCRIPTION,
          this.productFormFields.IS_ACTIVE,
          this.productFormFields.FORM_JSON,
          this.productFormFields.META,
          this.productFormFields.LOCALE,
          this.productFormFields.VERSION
        ],
        order: [[this.productFormFields.CREATED_AT, 'DESC']]
      });
    } catch (error) {
      this.logger.error({ ref: 'get form by product id error', error });
      throw error;
    }
  }
}

module.exports = { ProductFormService };


