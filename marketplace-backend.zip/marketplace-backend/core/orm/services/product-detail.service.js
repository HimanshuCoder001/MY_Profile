'use strict';

const { LoggerFactory } = require('@logger');
const { marketPlaceSqModels } = require('@orm');
const { BaseService } = require('./base.service');

class ProductDetailService extends BaseService {
  static instance = null;

  constructor() {
    super(marketPlaceSqModels.ProductDetails);
    this.logger = LoggerFactory.getLogger(ProductDetailService.name);
  }

  /**
   * Get instance of ProductDetailService
   * @returns {ProductDetailService} - Instance of ProductDetailService
   */
  static getInstance() {
    if (!ProductDetailService.instance) {
      ProductDetailService.instance = new ProductDetailService();
    }
    return ProductDetailService.instance;
  }
}

module.exports = { ProductDetailService };


