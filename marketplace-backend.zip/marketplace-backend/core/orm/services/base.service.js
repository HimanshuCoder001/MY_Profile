const { LoggerFactory } = require('@logger');

class BaseService {

  /**
   * Constructor for BaseService
   * @param {import('sequelize').ModelCtor<import('sequelize').Model>} model - The model to use for the service
   */
  constructor(model) {
    this.logger = LoggerFactory.getLogger(BaseService.name);
    this.model = model;
  }

  /**
   * Get a single record by its ID
   * @param {string} id - The ID of the record to retrieve
   * @param {Object} options - The options for the query
   * @returns {Promise<Object>} - The retrieved record
   */
  async getById(id, options = {}) {
    return await this.model.findByPk(id, options);
  }

  /**
   * Get a list of records
   * @param {Object} where - The where clause for filtering records
   * @param {Object} options - The options for the query
   * @returns {Promise<Array>} - The list of records
   */
  async list(where = {}, options = {}) {
    return await this.model.findAll({ where, ...options });
  }

  /**
   * Create a new record
   * @param {Object} data - The data for the new record
   * @returns {Promise<Object>} - The created record
   */
  async create(data) {
    return await this.model.create(data);
  }

  /**
   * Update an existing record
   * @param {string} id - The ID of the record to update
   * @param {Object} values - The values to update
   * @returns {Promise<Object>} - The updated record
   */
  async update(id, values) {
    await this.model.update(values, { where: { id } });
    return this.getById(id);
  }

  /**
   * Remove a record
   * @param {string} id - The ID of the record to remove
   * @returns {Promise<number>} - The number of records removed
   */
  async remove(id) {
    return await this.model.destroy({ where: { id } });
  }
}

module.exports = { BaseService };