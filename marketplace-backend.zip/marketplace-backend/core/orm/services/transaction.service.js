'use strict';

const { LoggerFactory } = require('@logger');
const { marketPlaceSqModels } = require('@orm');

class TransactionService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(TransactionService.name);
    this.model = marketPlaceSqModels.Transactions;
  }

  static getInstance() {
    if (!TransactionService.instance) {
      TransactionService.instance = new TransactionService();
    }
    return TransactionService.instance;
  }

  async checkIfExists(requestId) {
    return await this.model.checkIfExists(requestId);
  }

  async createTransaction(data) {
    return await this.model.createTransaction(data);
  }

  async updateTransactionStatus(requestId, status) {
    return await this.model.updateTransactionStatus(requestId, status);
  }

  async getTransactionByRequestId(requestId) {
    return await this.model.getTransactionByRequestId(requestId);
  }

  async getTransactionsByClientId(clientId) {
    return await this.model.getTransactionsByClientId(clientId);
  }
}

module.exports = { TransactionService };


