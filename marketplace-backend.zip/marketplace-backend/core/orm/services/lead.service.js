'use strict';

const { LoggerFactory } = require('@logger');
const { marketPlaceSqModels } = require('@orm');

class LeadService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(LeadService.name);
    this.model = marketPlaceSqModels.Leads;
  }

  static getInstance() {
    if (!LeadService.instance) {
      LeadService.instance = new LeadService();
    }
    return LeadService.instance;
  }

  async checkIfExists(leadId) {
    return await this.model.checkIfExists(leadId);
  }

  async createLead(data) {
    return await this.model.createLead(data);
  }

  async updateLeadStatus(leadId, status) {
    return await this.model.updateLeadStatus(leadId, status);
  }

  async listByClientId(clientId) {
    return await this.model.findAll({ where: { sma_id: clientId }, order: [["created_at", "DESC"]] });
  }
}

module.exports = { LeadService };


