'use strict';

module.exports = {
  ...require('./product.service'),
  ...require('./product-detail.service'),
  ...require('./product-banner.service'),
  ...require('./product-form.service'),
  ...require('./lead.service'),
  ...require('./serviceable-client.service'),
  ...require('./transaction.service'),
};


