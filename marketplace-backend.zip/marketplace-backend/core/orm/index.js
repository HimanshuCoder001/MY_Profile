'use strict';

const fs = require('fs');
const path = require('path');
const config = require('config');
const { Sequelize } = require('sequelize');
const { logger } = require('@spice-money/common-logger');
const { camelToSnake } = require('@utils');

const {
  db: marketPlaceDbConfig,
  sync: syncConfig = { enabled: false }
} = config;

/**
 * Initialize Marketplace Sequelize instance
 * @type {Sequelize}
 */
const marketPlaceSequelize = new Sequelize(
  marketPlaceDbConfig.database,
  marketPlaceDbConfig.username,
  marketPlaceDbConfig.password,
  {
    ...marketPlaceDbConfig,
    logging: (msg) => {
      logger.info({ ref: 'Marketplace DB Sequelize', query: msg });
    }
  }
);

// Test DB connection
marketPlaceSequelize
  .authenticate()
  .then(() => logger.info('Marketplace Database connection established successfully ✅'))
  .catch((error) => {
    logger.error('Error connecting to Marketplace:', error);
    throw error;
  });

// Entities
const marketPlaceEntity = {};

// Load and initialize Marketplace models
const basename = path.basename(__filename);

fs.readdirSync(path.join(__dirname, 'models'))
  .filter((file) => file.indexOf('.') !== 0 && file !== basename && file.endsWith('.js'))
  .forEach((file) => {
    const modelName = file.substring(0, file.lastIndexOf('.js'));
    const model = require(path.join(__dirname, 'models', file))(
      marketPlaceSequelize,
      `t_${camelToSnake(modelName)}`
    );
    marketPlaceEntity[model.name] = model;
  });

// Register model associations
Object.values(marketPlaceEntity).forEach((model) => {
  if (model.associate) {
    model.associate(marketPlaceEntity);
  }
});

/**
 * Models for Marketplace Sequelize
 * @type {Object<string, import('sequelize').ModelCtor<import('sequelize').Model>>}
 */
const marketPlaceSqModels = marketPlaceSequelize.models;

// Sync database models with proper order
const syncModels = async () => {
  if (!syncConfig.enabled) {
    logger.info('Model synchronization is disabled');
    return;
  }

  try {
    // Sync Products table
    await marketPlaceEntity.Products.sync({ alter: false });
    logger.info('Products table synchronized successfully');

    // Sync all tables
    await marketPlaceSequelize.sync({ alter: false });
    logger.info('All Marketplace tables synchronized successfully');
    
  } catch (error) {
    logger.error({ ref: 'Error synchronizing database models:', error: { message: error.message, stack: error.stack } });
    throw error;
  }
};

// Sync models
syncModels();

module.exports = { marketPlaceEntity, marketPlaceSqModels, sequelize: marketPlaceSequelize };


