const { DataTypes, Model } = require('sequelize');

const ProductFormFields = {
  FORM_ID: 'formId',
  PRODUCT_ID: 'productId',
  IS_ACTIVE: 'isActive',
  FORM_JSON: 'formJson',
  NAME: 'name',
  DESCRIPTION: 'description',
  FORM_TYPE: 'formType',
  VERSION: 'version',
  LOCALE: 'locale',
  META: 'meta',
  CREATED_AT: 'createdAt',
  UPDATED_AT: 'updatedAt'
};

class ProductForms extends Model {
  /**
   * Define associations
   */
  static associate(models) {
    // ProductForms belongs to Products
    ProductForms.belongsTo(models.Products, {
      foreignKey: ProductFormFields.PRODUCT_ID,
      targetKey: ProductFormFields.PRODUCT_ID,
      as: 'product'
    });
  }
}

/**
 * Initializes the ProductForms model.
 * @param {import('sequelize').Sequelize} sequelize - Sequelize instance
 * @param {string} TableName - The table name
 */
module.exports = (sequelize, TableName) => {
  ProductForms.AttributeFields = ProductFormFields;
  ProductForms.init(
    {
      formId: {
        type: DataTypes.UUID,
        field: 'form_id',
        primaryKey: true,
        allowNull: false
      },
      productId: {
        type: DataTypes.UUID,
        field: 'product_id',
        allowNull: false,
        references: {
          model: 't_products',
          key: 'product_id'
        }
      },
      name: {
        type: DataTypes.STRING(255),
        field: 'name',
        allowNull: false
      },
      description: {
        type: DataTypes.TEXT,
        field: 'description',
        allowNull: true
      },
      formType: {
        type: DataTypes.STRING(255),
        field: 'form_type',
        allowNull: false
      },
      isActive: {
        type: DataTypes.BOOLEAN,
        defaultValue: true,
        field: 'is_active'
      },
      formJson: {
        type: DataTypes.JSONB,
        field: 'form_json',
        allowNull: false
      },
      version: {
        type: DataTypes.INTEGER,
        field: 'version',
        allowNull: false,
        defaultValue: 1
      },
      locale: {
        type: DataTypes.STRING(32),
        field: 'locale',
        allowNull: false,
        defaultValue: 'en-IN'
      },
      meta: {
        type: DataTypes.JSONB,
        field: 'meta'
      }
    },
    {
      sequelize,
      tableName: TableName,
      timestamps: true,
      indexes: [
        { fields: ['product_id'] },
        { fields: ['is_active'] },
        { fields: ['locale'] },
        { fields: ['form_type'] },
        { unique: true, fields: ['product_id', 'form_type', 'version', 'locale'] }
      ]
    }
  );

  return ProductForms;
};



