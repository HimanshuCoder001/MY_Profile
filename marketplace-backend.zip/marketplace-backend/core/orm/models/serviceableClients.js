const { DataTypes, Model } = require('sequelize');

class ServiceableClient extends Model {
  /**
   * Check if a serviceable client exists for given criteria.
   */
  static async checkIfExists(clientId, redirectionType) {
    return await this.findOne({
      where: { client_id: clientId, redirection_type: redirectionType },
      attributes: ['client_id', 'redirection_type']
    });
  }

  /**
   * Create a new serviceable client record
   */
  static async createServiceableClient(clientData) {
    return await this.create(clientData);
  }

  /**
   * Get all serviceable clients by redirection type
   */
  static async getByRedirectionType(redirectionType) {
    return await this.findAll({
      where: { redirection_type: redirectionType },
      attributes: ['client_id', 'redirection_type']
    });
  }
}

/**
 * Initializes the ServiceableClient model.
 * @param {Sequelize} sequelize - Sequelize instance
 * @param {string} TableName - The table name
 */
module.exports = (sequelize, TableName) => {
  ServiceableClient.init(
    {
      client_id: {
        type: DataTypes.STRING(255),
        field: 'client_id',
        allowNull: false
      },
      redirection_type: {
        type: DataTypes.STRING(255),
        field: 'redirection_type',
        allowNull: false
      }
    },
    {
      sequelize,
      tableName: TableName,
      timestamps: true,
      indexes: [
        {
          fields: ['client_id']
        },
        {
          fields: ['redirection_type']
        }
      ]
    }
  );

  return ServiceableClient;
};


