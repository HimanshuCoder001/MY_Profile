const { DataTypes, Model } = require('sequelize');

class Transactions extends Model {
  static async checkIfExists(requestId) {
    return await this.findOne({
      where: { request_id: requestId },
      attributes: ['request_id', 'client_id', 'transaction_status']
    });
  }

  static async createTransaction(transactionData) {
    return await this.create(transactionData);
  }

  static async updateTransactionStatus(requestId, status, updateData = {}) {
    return await this.update(
      { transaction_status: status, ...updateData },
      { where: { request_id: requestId } }
    );
  }

  static async getTransactionByRequestId(requestId) {
    return await this.findOne({
      where: { request_id: requestId }
    });
  }

  static async getTransactionsByClientId(clientId) {
    return await this.findAll({
      where: { client_id: clientId },
      order: [['created_at', 'DESC']]
    });
  }
}

module.exports = (sequelize, TableName) => {
  Transactions.init(
    {
      request_id: {
        type: DataTypes.STRING(255),
        primaryKey: true,
        allowNull: false
      },
      client_id: {
        type: DataTypes.STRING(255),
        allowNull: false
      },
      session_id: {
        type: DataTypes.STRING(255)
      },
      source: {
        type: DataTypes.STRING(255),
        allowNull: false
      },
      req_type: {
        type: DataTypes.STRING(50),
        defaultValue: 'INSURANCE'
      },
      service_id: {
        type: DataTypes.STRING(50),
        allowNull: true
      },
      transInitId: {
        type: DataTypes.STRING(255),
        field: 'transInitId' 
      },
      transInitRefNo: {
        type: DataTypes.STRING(255),
        field: 'transInitRefNo'
      },
      transaction_status: {
        type: DataTypes.STRING(100)
      },
      is_refund: {
        type: DataTypes.BOOLEAN,
        defaultValue: false
      },
      refund_reason: {
        type: DataTypes.STRING(255),
        defaultValue: ''
      },
      refund_amount: {
        type: DataTypes.STRING(50),
        defaultValue: '0'
      },
      debit_amount: {
        type: DataTypes.STRING(50)
      },
      wallet_balance: {
        type: DataTypes.STRING(50)
      },
      balance_ts: {
        type: DataTypes.DATE
      },
      debit_ts: {
        type: DataTypes.DATE
      },
      update_ts: {
        type: DataTypes.DATE
      },
      client_details: {
        type: DataTypes.JSONB
      },
      transaction_details: {
        type: DataTypes.JSONB
      },
      created_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      },
      updated_at: {
        type: DataTypes.DATE,
        defaultValue: DataTypes.NOW
      }
    },
    {
      sequelize,
      tableName: TableName,
      timestamps: true,
      indexes: [
        { unique: true, fields: ['request_id'] },
        { fields: ['client_id'] },
        { fields: ['transaction_status'] },
        { fields: ['created_at'] }
      ]
    }
  );

  return Transactions;
};
