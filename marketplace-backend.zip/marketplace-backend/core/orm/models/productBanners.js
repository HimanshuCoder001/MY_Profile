const { DataTypes, Model } = require('sequelize');

const ProductBannerFields = {
  BANNER_ID: 'bannerId',
  PRODUCT_ID: 'productId',
  TYPE: 'type',
  KEY: 'key',
  BANNER_ICON: 'bannerIcon',
  TITLE: 'title',
  SUBTITLE: 'subtitle',
  DESCRIPTION: 'description',
  IMAGE_URL: 'imageUrl',
  MOBILE_IMAGE_URL: 'mobileImageUrl',
  ICON_URL: 'iconUrl',
  TARGET_URL: 'targetUrl',
  ORDER: 'order',
  IS_ACTIVE: 'isActive',
  META: 'meta',
  CREATED_AT: 'createdAt',
  UPDATED_AT: 'updatedAt'
};

class ProductBanners extends Model {
  /**
   * Define associations
   */
  static associate(models) {
    // ProductBanners belongs to Products
    ProductBanners.belongsTo(models.Products, {
      foreignKey: ProductBannerFields.PRODUCT_ID,
      targetKey: ProductBannerFields.PRODUCT_ID,
      as: 'product'
    });
  }
}

/**
 * Initializes the ProductBanners model.
 * @param {import('sequelize').Sequelize} sequelize - Sequelize instance
 * @param {string} TableName - The table name
 */
module.exports = (sequelize, TableName) => {
  ProductBanners.AttributeFields = ProductBannerFields;
  ProductBanners.init(
    {
      bannerId: {
        type: DataTypes.UUID,
        field: 'banner_id',
        primaryKey: true,
        allowNull: false
      },
      productId: {
        type: DataTypes.UUID,
        field: 'product_id',
        allowNull: false,
        references: {
          model: 't_products',
          key: 'product_id'
        }
      },
      type: {
        type: DataTypes.STRING(100),
        field: 'banner_type'
      },
      key: {
        type: DataTypes.STRING(100),
        field: 'banner_key'
      },
      bannerIcon: {
        type: DataTypes.STRING(1024),
        field: 'banner_icon'
      },
      title: {
        type: DataTypes.STRING(255),
        field: 'title'
      },
      subtitle: {
        type: DataTypes.STRING(255),
        field: 'subtitle'
      },
      description: {
        type: DataTypes.TEXT,
        field: 'description'
      },
      imageUrl: {
        type: DataTypes.STRING(1024),
        field: 'image_url'
      },
      mobileImageUrl: {
        type: DataTypes.STRING(1024),
        field: 'mobile_image_url'
      },
      iconUrl: {
        type: DataTypes.STRING(1024),
        field: 'icon_url'
      },
      targetUrl: {
        type: DataTypes.STRING(1024),
        field: 'target_url'
      },
      order: {
        type: DataTypes.INTEGER,
        field: 'display_order',
        defaultValue: 0
      },
      isActive: {
        type: DataTypes.BOOLEAN,
        field: 'is_active',
        allowNull: false,
        defaultValue: true
      },
      meta: {
        type: DataTypes.JSONB,
        field: 'meta'
      }
    },
    {
      sequelize,
      tableName: TableName,
      timestamps: true,
      indexes: [
        { fields: ['product_id'] },
        { fields: ['banner_type'] },
        { fields: ['is_active'] },
        { fields: ['display_order'] }
      ]
    }
  );

  return ProductBanners;
};



