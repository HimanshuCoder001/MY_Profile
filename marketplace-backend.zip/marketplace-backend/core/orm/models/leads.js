const { DataTypes, Model } = require('sequelize');

class Leads extends Model {
  /**
   * Check if a lead exists for given criteria.
   */
  static async checkIfExists(leadId) {
    return await this.findOne({
      where: { lead_id: leadId },
      attributes: ['lead_id', 'mobile', 'email', 'lead_status']
    });
  }

  /**
   * Create a new lead record
   */
  static async createLead(leadData) {
    return await this.create(leadData);
  }

  /**
   * Update lead status
   */
  static async updateLeadStatus(leadId, status) {
    return await this.update(
      { lead_status: status },
      { where: { lead_id: leadId } }
    );
  }
}

/**
 * Initializes the Lead model.
 * @param {Sequelize} sequelize - Sequelize instance
 * @param {string} TableName - The table name
 */
module.exports = (sequelize, TableName) => {
  Leads.init(
    {
      lead_id: {
        type: DataTypes.STRING(255),
        field: 'lead_id',
        primaryKey: true,
        allowNull: false
      },
      mobile: {
        type: DataTypes.STRING(255),
        field: 'mobile'
      },
      pan: {
        type: DataTypes.STRING(255),
        field: 'pan'
      },
      pincode: {
        type: DataTypes.JSONB,
        field: 'pincode'
      },
      email: {
        type: DataTypes.STRING(255),
        field: 'email'
      },
      lead_comment: {
        type: DataTypes.STRING(500),
        field: 'lead_comment'
      },
      partner_lead_id: {
        type: DataTypes.STRING(255),
        field: 'partner_lead_id'
      },
      lead_status: {
        type: DataTypes.STRING(255),
        field: 'lead_status'
      },
      alternate_mobile: {
        type: DataTypes.STRING(255),
        field: 'alternate_mobile'
      },
      first_name: {
        type: DataTypes.STRING(255),
        field: 'first_name'
      },
      last_name: {
        type: DataTypes.STRING(255),
        field: 'last_name'
      },
      branchcode: {
        type: DataTypes.STRING(255),
        field: 'branchcode'
      },
      remarks: {
        type: DataTypes.STRING(500),
        field: 'remarks'
      },
      sma_id: {
        type: DataTypes.STRING(255),
        field: 'sma_id'
      },
      agent_name: {
        type: DataTypes.STRING(255),
        field: 'agent_name'
      },
      lead_type: {
        type: DataTypes.STRING(255),
        field: 'lead_type'
      },
      otp_verified: {
        type: DataTypes.BOOLEAN,
        field: 'otp_verified'
      },
      otp_id: {
        type: DataTypes.STRING(255),
        field: 'otp_id'
      },
      product: {
        type: DataTypes.STRING(255),
        field: 'product'
      }
    },
    {
      sequelize,
      tableName: TableName,
      timestamps: true,
      indexes: [
        {
          unique: true,
          fields: ['lead_id']
        }
      ]
    }
  );

  return Leads;
};



