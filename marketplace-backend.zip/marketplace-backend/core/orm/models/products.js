const { DataTypes, Model } = require('sequelize');

const ProductFields = {
    PRODUCT_ID: 'productId',
    NAME: 'name',
    TYPE: 'type',
    PARENT_ID: 'parentId',
    IS_ACTIVE: 'isActive',
    ICON: 'icon',
    META: 'meta',
    CREATED_AT: 'createdAt',
    UPDATED_AT: 'updatedAt'
}

class Products extends Model {
    /**
     * Define associations
     */
    static associate(models) {

        // Products has many ProductDetails
        Products.belongsTo(models.ProductDetails, {
            foreignKey: ProductFields.PRODUCT_ID,
            targetKey: ProductFields.PRODUCT_ID,
            as: 'details'
        });

        // Products has many ProductForms
        Products.hasMany(models.ProductForms, {
            foreignKey: ProductFields.PRODUCT_ID,
            targetKey: ProductFields.PRODUCT_ID,
            as: 'forms'
        });

        // Products has many ProductBanners
        Products.hasMany(models.ProductBanners, {
            foreignKey: ProductFields.PRODUCT_ID,
            targetKey: ProductFields.PRODUCT_ID,
            as: 'banners'
        });

        // Self-referential association for hierarchical products
        Products.belongsTo(models.Products, {
            foreignKey: ProductFields.PARENT_ID,
            targetKey: ProductFields.PRODUCT_ID,
            as: 'parent'
        });

        Products.hasMany(models.Products, {
            foreignKey: ProductFields.PARENT_ID,
            targetKey: ProductFields.PRODUCT_ID,
            as: 'subTiles'
        });
    }

}

/**
 * Initializes the Products model.
 * @param {import('sequelize').Sequelize} sequelize - Sequelize instance
 * @param {string} TableName - The table name
 */
module.exports = (sequelize, TableName) => {
    Products.AttributeFields = ProductFields;
    Products.init(
        {
            productId: {
                type: DataTypes.UUID,
                field: 'product_id',
                primaryKey: true,
                allowNull: false,
            },
            name: {
                type: DataTypes.STRING(255),
                field: 'name',
                allowNull: false
            },
            type: {
                type: DataTypes.STRING(255),
                field: 'type'
            },
            parentId: {
                type: DataTypes.UUID,
                field: 'parent_id',
                allowNull: true,
                references: {
                    model: 't_products',
                    key: 'product_id'
                }
            },
            isActive: {
                type: DataTypes.BOOLEAN,
                field: 'is_active',
                allowNull: false,
                defaultValue: true
            },
            icon: {
                type: DataTypes.STRING(255),
                field: 'icon'
            },
            meta: {
                type: DataTypes.JSONB,
                field: 'meta'
            }
        },
        {
            sequelize,
            tableName: TableName,
            timestamps: true,
            indexes: [
                { fields: ['name'] },
                { fields: ['type'] },
                { fields: ['parent_id'] },
                { fields: ['is_active'] }
            ]
        }
    );

    return Products;
};


