const { DataTypes, Model } = require('sequelize');

const ProductDetailFields = {
    DETAIL_ID: 'detailId',
    PRODUCT_ID: 'productId',
    CATEGORY: 'category',
    SUB_CATEGORY: 'subCategory',
    PARTNER_AVAILABILITY: 'partnerAvailability',
    COMPETITION_BENCHMARKING: 'competitionBenchmarking',
    OPPORTUNITY_TYPE: 'opportunityType',
    IS_ACTIVE: 'isActive',
    FAQ: 'faq',
    META: 'meta',
    CREATED_AT: 'createdAt',
    UPDATED_AT: 'updatedAt'
}

class ProductDetails extends Model {
    /**
     * Define associations
     */
    static associate(models) {

        // ProductDetails belongs to Products
        ProductDetails.belongsTo(models.Products, {
            foreignKey: ProductDetailFields.PRODUCT_ID,
            targetKey: ProductDetailFields.PRODUCT_ID,
            as: 'product'
        });
    }
}

/**
 * Initializes the ProductDetails model.
 * @param {import('sequelize').Sequelize} sequelize - Sequelize instance
 * @param {string} TableName - The table name
 */
module.exports = (sequelize, TableName) => {
    ProductDetails.AttributeFields = ProductDetailFields;
    ProductDetails.init(
        {
            detailId: {
                type: DataTypes.UUID,
                field: 'detail_id',
                primaryKey: true,
                allowNull: false
            },
            productId: {
                type: DataTypes.UUID,
                field: 'product_id',
                allowNull: false,
                references: {
                    model: 't_products',
                    key: 'product_id'
                }
            },
            category: {
                type: DataTypes.STRING(255),
                field: 'category',
            },
            subCategory: {
                type: DataTypes.STRING(255),
                field: 'sub_category'
            },
            partnerAvailability: {
                type: DataTypes.STRING(255),
                field: 'partner_availability'
            },
            competitionBenchmarking: {
                type: DataTypes.TEXT,
                field: 'competition_benchmarking'
            },
            opportunityType: {
                type: DataTypes.STRING(255),
                field: 'opportunity_type'
            },
            isActive: {
                type: DataTypes.BOOLEAN,
                field: 'is_active',
                allowNull: false,
                defaultValue: true
            },
            faq: {
                type: DataTypes.JSONB,
                field: 'faq'
            },
            meta: {
                type: DataTypes.JSONB,
                field: 'meta'
            }
        },
        {
            sequelize,
            tableName: TableName,
            timestamps: true,
            indexes: [
                { fields: ['product_id'] },
                { fields: ['is_active'] }
            ]
        }
    );

    return ProductDetails;
};



