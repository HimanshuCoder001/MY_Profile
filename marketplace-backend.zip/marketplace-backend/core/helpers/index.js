'use strict';

const { FormValidationService } = require('./form-validation.service');

module.exports = {
  FormValidationService
};
