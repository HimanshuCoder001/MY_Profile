'use strict';

const { LoggerFactory } = require('@logger');

class FormValidationService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(FormValidationService.name);
  }

  /**
   * Get instance of FormValidationService
   * @returns {FormValidationService} - Instance of FormValidationService
   */
  static getInstance() {
    if (!FormValidationService.instance) {
      FormValidationService.instance = new FormValidationService();
    }
    return FormValidationService.instance;
  }

  /**
   * Validate form data against form schema
   * @param {Object} formData - Form data to validate
   * @param {Object} formSchema - Form schema from formJson
   * @returns {Object} - Validation result
   */
  validateFormData(formData, formSchema) {
    try {
      if (!formData || !formSchema || !formSchema.fields) {
        return {
          isValid: false,
          errors: ['Invalid form data or schema provided'],
          details: {}
        };
      }

      const errors = [];
      const validationDetails = {};

      // Validate each field based on schema
      formSchema.fields.forEach(field => {
        const fieldName = field.name;
        const fieldValue = formData[fieldName];
        const fieldErrors = this.validateField(fieldValue, field);

        if (fieldErrors.length > 0) {
          errors.push(...fieldErrors);
          validationDetails[fieldName] = {
            value: fieldValue,
            errors: fieldErrors,
            field: field
          };
        } else {
          validationDetails[fieldName] = {
            value: fieldValue,
            isValid: true,
            field: field
          };
        }
      });

      return {
        isValid: errors.length === 0,
        errors: errors,
        details: validationDetails,
        fieldCount: formSchema.fields.length,
        errorCount: errors.length
      };

    } catch (error) {
      this.logger.error({ 
        ref: 'validateFormData', 
        message: 'Error validating form data', 
        error 
      });
      
      return {
        isValid: false,
        errors: ['Validation error occurred'],
        details: {},
        error: error.message
      };
    }
  }

  /**
   * Validate individual field based on field schema
   * @param {any} value - Field value
   * @param {Object} field - Field schema
   * @returns {Array} - Array of error messages
   */
  validateField(value, field) {
    const errors = [];
    const fieldName = field.name;

    // Check if field is required
    const isRequired = field.validators?.some(validator => validator.type === 'required');
    
    if (isRequired && (value === undefined || value === null || value === '')) {
      const requiredValidator = field.validators.find(v => v.type === 'required');
      errors.push(requiredValidator?.message || `${fieldName} is required`);
      return errors; // Return early if required field is empty
    }

    // Skip validation if field is empty and not required
    if (value === undefined || value === null || value === '') {
      return errors;
    }

    // Validate based on field type
    switch (field.type) {
      case 'String':
        this.validateStringField(value, field, errors);
        break;
      case 'Phone':
        this.validatePhoneField(value, field, errors);
        break;
      case 'Email':
        this.validateEmailField(value, field, errors);
        break;
      case 'Select':
        this.validateSelectField(value, field, errors);
        break;
      default:
        // Apply common validators for unknown types
        this.applyCommonValidators(value, field, errors);
    }

    return errors;
  }

  /**
   * Validate string field
   * @param {string} value - Field value
   * @param {Object} field - Field schema
   * @param {Array} errors - Errors array to append to
   */
  validateStringField(value, field, errors) {
    if (typeof value !== 'string') {
      errors.push(`${field.name} must be a string`);
      return;
    }

    this.applyCommonValidators(value, field, errors);
  }

  /**
   * Validate phone field
   * @param {string} value - Field value
   * @param {Object} field - Field schema
   * @param {Array} errors - Errors array to append to
   */
  validatePhoneField(value, field, errors) {
    if (typeof value !== 'string') {
      errors.push(`${field.name} must be a string`);
      return;
    }

    // Remove any non-digit characters for validation
    const cleanValue = value.replace(/\D/g, '');

    this.applyCommonValidators(cleanValue, field, errors);

    // Additional phone-specific validation
    if (field.maxLength && cleanValue.length > field.maxLength) {
      errors.push(`${field.name} must not exceed ${field.maxLength} digits`);
    }
  }

  /**
   * Validate email field
   * @param {string} value - Field value
   * @param {Object} field - Field schema
   * @param {Array} errors - Errors array to append to
   */
  validateEmailField(value, field, errors) {
    if (typeof value !== 'string') {
      errors.push(`${field.name} must be a string`);
      return;
    }

    this.applyCommonValidators(value, field, errors);

    // Email format validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(value)) {
      errors.push(`${field.name} must be a valid email address`);
    }
  }

  /**
   * Validate select field
   * @param {string} value - Field value
   * @param {Object} field - Field schema
   * @param {Array} errors - Errors array to append to
   */
  validateSelectField(value, field, errors) {
    if (!field.options || !Array.isArray(field.options)) {
      errors.push(`${field.name} has invalid options configuration`);
      return;
    }

    const validValues = field.options.map(option => option.value);
    if (!validValues.includes(value)) {
      errors.push(`${field.name} must be one of: ${validValues.join(', ')}`);
    }
  }

  /**
   * Apply common validators to field
   * @param {any} value - Field value
   * @param {Object} field - Field schema
   * @param {Array} errors - Errors array to append to
   */
  applyCommonValidators(value, field, errors) {
    if (!field.validators) return;

    field.validators.forEach(validator => {
      switch (validator.type) {
        case 'minLength':
          if (value.length < validator.value) {
            errors.push(validator.message || `${field.name} must be at least ${validator.value} characters`);
          }
          break;

        case 'maxLength':
          if (value.length > validator.value) {
            errors.push(validator.message || `${field.name} must not exceed ${validator.value} characters`);
          }
          break;

        case 'pattern':
          const regex = new RegExp(validator.value);
          if (!regex.test(value)) {
            errors.push(validator.message || `${field.name} format is invalid`);
          }
          break;

        case 'email':
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(value)) {
            errors.push(validator.message || `${field.name} must be a valid email address`);
          }
          break;

        case 'required':
          // Already handled in validateField
          break;

        default:
          // Unknown validator type
          this.logger.warn({ 
            ref: 'applyCommonValidators', 
            message: `Unknown validator type: ${validator.type}`,
            field: field.name,
            validator: validator
          });
      }
    });
  }
}

module.exports = { FormValidationService };
