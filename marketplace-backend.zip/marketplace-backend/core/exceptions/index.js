const marketplaceExceptions = require('./marketplace.exception');

module.exports = {
    ...marketplaceExceptions,
};