'use strict';

/**
 * Base exception class for marketplace application
 */
class MarketplaceException extends Error {
    constructor(message, statusCode = 500, errorCode = null) {
        super(message);
        this.name = this.constructor.name;
        this.statusCode = statusCode;
        this.errorCode = errorCode;
        this.timestamp = new Date().toISOString();
        
        // Maintains proper stack trace for where our error was thrown (only available on V8)
        if (Error.captureStackTrace) {
            Error.captureStackTrace(this, this.constructor);
        }
    }
}

/**
 * Authentication related exceptions
 */
class AuthenticationException extends MarketplaceException {
    constructor(message = 'Authentication failed', errorCode = 'AUTH_FAILED') {
        super(message, 401, errorCode);
    }
}

/**
 * Authorization related exceptions
 */
class AuthorizationException extends MarketplaceException {
    constructor(message = 'Access denied', errorCode = 'ACCESS_DENIED') {
        super(message, 403, errorCode);
    }
}

/**
 * Session validation exceptions
 */
class SessionValidationException extends MarketplaceException {
    constructor(message = 'Session validation failed', errorCode = 'SESSION_INVALID') {
        super(message, 401, errorCode);
    }
}

/**
 * Validation exceptions
 */
class ValidationException extends MarketplaceException {
    constructor(message = 'Validation failed', errorCode = 'VALIDATION_FAILED', errorData = null) {
        super(message, 400, errorCode);
        this.errorData = errorData;
    }
}

/**
 * Not found exceptions
 */
class NotFoundException extends MarketplaceException {
    constructor(message = 'Resource not found', errorCode = 'NOT_FOUND') {
        super(message, 404, errorCode);
    }
}

/**
 * Conflict exceptions
 */
class ConflictException extends MarketplaceException {
    constructor(message = 'Resource conflict', errorCode = 'CONFLICT') {
        super(message, 409, errorCode);
    }
}

/**
 * Rate limit exceptions
 */
class RateLimitException extends MarketplaceException {
    constructor(message = 'Rate limit exceeded', errorCode = 'RATE_LIMIT_EXCEEDED') {
        super(message, 429, errorCode);
    }
}

/**
 * External service exceptions
 */
class ExternalServiceException extends MarketplaceException {
    constructor(message = 'External service error', errorCode = 'EXTERNAL_SERVICE_ERROR') {
        super(message, 502, errorCode);
    }
}

/**
 * Database exceptions
 */
class DatabaseException extends MarketplaceException {
    constructor(message = 'Database error', errorCode = 'DATABASE_ERROR') {
        super(message, 500, errorCode);
    }
}

/**
 * Configuration exceptions
 */
class ConfigurationException extends MarketplaceException {
    constructor(message = 'Configuration error', errorCode = 'CONFIG_ERROR') {
        super(message, 500, errorCode);
    }
}

/**
 * Utility function to create error response object
 * @param {Error} error - Error object
 * @returns {Object} Formatted error response
 */
function createErrorResponse(error) {
    if (error instanceof MarketplaceException) {
        const response = {
            status: false,
            message: error.message,
            errorCode: error.errorCode,
            statusCode: error.statusCode,
            timestamp: error.timestamp,
            resp: {
                data: null
            }
        };

        // Add errors and errorCount only if errorData exists
        if (error.errorData && Array.isArray(error.errorData)) {
            response.resp.errors = error.errorData;
            response.resp.errorCount = error.errorData.length;
        }

        return response;
    }

    // Handle generic errors
    return {
        status: false,
        message: error.message || 'Internal server error',
        errorCode: 'INTERNAL_ERROR',
        statusCode: error.statusCode || 500,
        timestamp: new Date().toISOString(),
        resp: {
            data: null
        }
    };
}

/**
 * Utility function to check if error is a marketplace exception
 * @param {Error} error - Error object
 * @returns {boolean} True if it's a marketplace exception
 */
function isMarketplaceException(error) {
    return error instanceof MarketplaceException;
}

module.exports = {
    MarketplaceException,
    AuthenticationException,
    AuthorizationException,
    SessionValidationException,
    ValidationException,
    NotFoundException,
    ConflictException,
    RateLimitException,
    ExternalServiceException,
    DatabaseException,
    ConfigurationException,
    createErrorResponse,
    isMarketplaceException
};
