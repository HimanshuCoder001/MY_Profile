'use strict';

const { LoggerFactory } = require('@logger');
const { HealthService } = require('./health.service');

class HealthController {
    static instance = null;

    constructor() {
        this.logger = LoggerFactory.getLogger(HealthController.name);
        this.healthService = HealthService.getInstance();
    }

    /**
     * Get instance of HealthController
     * @returns {HealthController} - Instance of HealthController
     */
    static getInstance() {
        if (!HealthController.instance) {
            HealthController.instance = new HealthController();
        }
        return HealthController.instance;
    }

    /**
     * Liveness probe endpoint
     * @param {Object} req - Express request object
     * @param {Object} res - Express response object
     * @param {Function} next - Express next function
     */
    async getLiveness(req, res, next) {
        try {
            this.logger.info({ ref: 'getLiveness', ip: req.ip, userAgent: req.get('User-Agent') });

            const livenessStatus = await this.healthService.getLivenessStatus();
            
            // Set appropriate HTTP status code
            const statusCode = livenessStatus.status === 'healthy' ? 200 : 503;
            
            res.status(statusCode).json({
                success: true,
                data: livenessStatus
            });
        } catch (error) {
            this.logger.error({ ref: 'getLiveness error', error });
            next(error);
        }
    }

    /**
     * Readiness probe endpoint
     * @param {Object} req - Express request object
     * @param {Object} res - Express response object
     * @param {Function} next - Express next function
     */
    async getReadiness(req, res, next) {
        try {
            this.logger.info({ ref: 'getReadiness', ip: req.ip, userAgent: req.get('User-Agent') });

            const readinessStatus = await this.healthService.getReadinessStatus();
            
            // Set appropriate HTTP status code
            const statusCode = readinessStatus.status === 'ready' ? 200 : 503;
            
            res.status(statusCode).json({
                success: true,
                data: readinessStatus
            });
        } catch (error) {
            this.logger.error({ ref: 'getReadiness error', error });
            next(error);
        }
    }

    /**
     * Health check endpoint
     * @param {Object} req - Express request object
     * @param {Object} res - Express response object
     * @param {Function} next - Express next function
     */
    async getHealth(req, res, next) {
        try {
            this.logger.info({ ref: 'getHealth', ip: req.ip, userAgent: req.get('User-Agent') });

            const healthStatus = await this.healthService.getHealthStatus();
            
            // Set appropriate HTTP status code
            const statusCode = healthStatus.status === 'healthy' ? 200 : 503;
            
            res.status(statusCode).json({
                success: true,
                data: healthStatus
            });
        } catch (error) {
            this.logger.error({ ref: 'getHealth error', error });
            next(error);
        }
    }

    /**
     * Simple ping endpoint for basic connectivity check
     * @param {Object} req - Express request object
     * @param {Object} res - Express response object
     * @param {Function} next - Express next function
     */
    async ping(req, res, next) {
        try {
            this.logger.info({ ref: 'ping', ip: req.ip, userAgent: req.get('User-Agent') });

            res.status(200).json({
                success: true,
                data: {
                    message: 'pong',
                    timestamp: new Date().toISOString(),
                    uptime: process.uptime()
                }
            });
        } catch (error) {
            this.logger.error({ ref: 'ping error', error });
            next(error);
        }
    }
}

module.exports = { HealthController };
