'use strict';
const healthRoutes = require('./health.routes');

module.exports = {
    healthRoutes
};
