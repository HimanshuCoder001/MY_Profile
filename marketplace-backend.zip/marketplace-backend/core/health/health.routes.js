'use strict';

const { HealthController } = require('./health.controller');

const healthController = HealthController.getInstance();

module.exports = (router) => {
    /**
     * @route   GET /health/ping
     * @desc    Simple ping endpoint for basic connectivity check
     * @access  Public
     */
    router.get('/ping', healthController.ping.bind(healthController));

    /**
     * @route   GET /health/live
     * @desc    Liveness probe - checks if the application is running
     * @access  Public
     */
    router.get('/live', healthController.getLiveness.bind(healthController));

    /**
     * @route   GET /health/ready
     * @desc    Readiness probe - checks if the application is ready to serve requests
     * @access  Public
     */
    router.get('/ready', healthController.getReadiness.bind(healthController));

    /**
     * @route   GET /health
     * @desc    Comprehensive health check - combines liveness and readiness
     * @access  Public
     */
    router.get('/', healthController.getHealth.bind(healthController));
};
