'use strict';

const { LoggerFactory } = require('@logger');
const { sequelize } = require('@orm');

class HealthService {
    static instance = null;

    constructor() {
        this.logger = LoggerFactory.getLogger(HealthService.name);
    }

    /**
     * Get instance of HealthService
     * @returns {HealthService} - Instance of HealthService
     */
    static getInstance() {
        if (!HealthService.instance) {
            HealthService.instance = new HealthService();
        }
        return HealthService.instance;
    }

    /**
     * Liveness probe - checks if the application is running
     * @returns {Promise<Object>} - Liveness status
     */
    async getLivenessStatus() {
        try {
            this.logger.info({ ref: 'getLivenessStatus', message: 'Liveness check initiated' });

            const status = {
                status: 'healthy',
                timestamp: new Date().toISOString(),
                uptime: process.uptime(),
                memory: {
                    used: process.memoryUsage().heapUsed,
                    total: process.memoryUsage().heapTotal,
                    external: process.memoryUsage().external,
                    rss: process.memoryUsage().rss
                },
                pid: process.pid,
                version: process.version,
                platform: process.platform
            };

            this.logger.info({ ref: 'getLivenessStatus success', status: status.status });
            return status;
        } catch (error) {
            this.logger.error({ ref: 'getLivenessStatus error', error });
            throw error;
        }
    }

    /**
     * Readiness probe - checks if the application is ready to serve requests
     * @returns {Promise<Object>} - Readiness status
     */
    async getReadinessStatus() {
        try {
            this.logger.info({ ref: 'getReadinessStatus', message: 'Readiness check initiated' });

            const checks = {
                database: await this.checkDatabaseConnection(),
                memory: this.checkMemoryUsage(),
                disk: this.checkDiskSpace()
            };

            const isReady = Object.values(checks).every(check => check.status === 'healthy');
            const status = {
                status: isReady ? 'ready' : 'not_ready',
                timestamp: new Date().toISOString(),
                checks
            };

            this.logger.info({ ref: 'getReadinessStatus success', status: status.status, checks: Object.keys(checks) });
            return status;
        } catch (error) {
            this.logger.error({ ref: 'getReadinessStatus error', error });
            throw error;
        }
    }

    /**
     * Health check - comprehensive health status
     * @returns {Promise<Object>} - Health status
     */
    async getHealthStatus() {
        try {
            this.logger.info({ ref: 'getHealthStatus', message: 'Health check initiated' });

            const [liveness, readiness] = await Promise.all([
                this.getLivenessStatus(),
                this.getReadinessStatus()
            ]);

            const isHealthy = liveness.status === 'healthy' && readiness.status === 'ready';
            const status = {
                status: isHealthy ? 'healthy' : 'unhealthy',
                timestamp: new Date().toISOString(),
                liveness,
                readiness
            };

            this.logger.info({ ref: 'getHealthStatus success', status: status.status });
            return status;
        } catch (error) {
            this.logger.error({ ref: 'getHealthStatus error', error });
            throw error;
        }
    }

    /**
     * Check database connection
     * @returns {Promise<Object>} - Database health status
     */
    async checkDatabaseConnection() {
        try {
            // Test database connection by executing a simple query
            await sequelize.authenticate();
            
            return {
                status: 'healthy',
                message: 'Database connection is active',
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            this.logger.error({ ref: 'checkDatabaseConnection error', error });
            return {
                status: 'unhealthy',
                message: 'Database connection failed',
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }

    /**
     * Check memory usage
     * @returns {Object} - Memory health status
     */
    checkMemoryUsage() {
        try {
            const memUsage = process.memoryUsage();
            const heapUsedMB = Math.round(memUsage.heapUsed / 1024 / 1024);
            const heapTotalMB = Math.round(memUsage.heapTotal / 1024 / 1024);
            const memoryUsagePercent = (heapUsedMB / heapTotalMB) * 100;

            // Consider unhealthy if memory usage is above 95% (realistic threshold for small heaps)
            const isHealthy = memoryUsagePercent < 95;

            return {
                status: isHealthy ? 'healthy' : 'unhealthy',
                message: `Memory usage: ${memoryUsagePercent.toFixed(2)}%`,
                details: {
                    heapUsed: `${heapUsedMB}MB`,
                    heapTotal: `${heapTotalMB}MB`,
                    usagePercent: memoryUsagePercent.toFixed(2)
                },
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            this.logger.error({ ref: 'checkMemoryUsage error', error });
            return {
                status: 'unhealthy',
                message: 'Memory check failed',
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }

    /**
     * Check disk space (basic implementation)
     * @returns {Object} - Disk health status
     */
    checkDiskSpace() {
        try {
            // Basic disk space check - in production, you might want to use a library like 'diskusage'
            // For now, we'll return a basic healthy status
            return {
                status: 'healthy',
                message: 'Disk space check passed',
                timestamp: new Date().toISOString()
            };
        } catch (error) {
            this.logger.error({ ref: 'checkDiskSpace error', error });
            return {
                status: 'unhealthy',
                message: 'Disk space check failed',
                error: error.message,
                timestamp: new Date().toISOString()
            };
        }
    }
}

module.exports = { HealthService };
