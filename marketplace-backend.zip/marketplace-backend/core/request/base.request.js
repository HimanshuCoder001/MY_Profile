'use strict';

const SMRequest = require('@vishant.harshadbha/sm-request');
const { LoggerFactory } = require('@logger');
const { AMSLog } = require('@odm');
const { v4: uuidv4 } = require('uuid');

class BaseRequest extends SMRequest {
    constructor() {
        super(AMSLog, {
            mailSender: 'alerts@spicebulls.com',
            mailReceiver: ['noreply@spicebulls.com'],
            projectName: 'marketplace'
        });
        this.logger = LoggerFactory.getLogger(BaseRequest.name);
    }

    /**
     * Static method to access the singleton instance
     * @returns {BaseRequest} The singleton instance of BaseRequest
     */
    static make() {
        return new BaseRequest();
    }

    /**
     * Makes an HTTP POST request with retry capability.
     * @param {Object} config - Configuration for the request
     * @param {Object} reqBody - Data to be sent with the request
     * @param {string} clientId - Client identifier
     * @param {string} applicationNumber - Application number (optional)
     * @param {string} requestId - Request identifier
     * @param {Object} options - Additional options for the request
     * @param {Object} [options.query={}] - Additional options for the request
     * @param {number} [options.maxRetries=0] - Maximum number of retry attempts
     * @returns {Promise<Object>} The response from the POST request
     */
    async handle(config, reqBody, clientId = '', applicationNumber = '', requestId = '', options = {}) {
        const { host, port, protocol, headers, method } = config;
        let url = config.url || '';

        if (options.query) {
            const query = new URLSearchParams(options.query).toString();
            url = `${url}?${query}`;
        }

        const requestOptions = {
            data: reqBody,
            host: host,
            port: port || 443,
            method: method || 'POST',
            path: url,
            protocol: protocol || 'https',
            headers: {
                ...headers,
                clientId,
                ...(applicationNumber && applicationNumber.trim() ? { applicationNumber } : {}),
                requestId: requestId || uuidv4(),
                ...(options?.headers || {}),
            },
        };

        this.logger.info({ ref: 'request options', data: requestOptions });

        const maxRetries = options.maxRetries !== undefined ? options.maxRetries : 0;
        return await this.post(requestOptions, { retryCount: maxRetries });
    }
}

module.exports = { BaseRequest };