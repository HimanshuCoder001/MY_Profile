'use strict';

const { LoggerFactory } = require('@logger');
const { ams } = require('@odm');
const { safeSerialize } = require('@utils');

class AMSService {
  constructor() {
    this.logger = LoggerFactory.getLogger(AMSService.name);
    this.db = ams;
    this.collectionName = 'marketplaceExternalcalls';
  }

  /**
   * Get singleton instance
   * @returns {AMSService}
   */
  static getInstance() {
    if (!AMSService.instance) {
      AMSService.instance = new AMSService();
    }
    return AMSService.instance;
  }

  /**
   * Create AMS log object for request
   * @param {Object} config - Request configuration
   * @param {Object} headers - Request headers
   * @returns {Object} AMS log object
   * @private
   */
  _createRequestLog(config, headers) {
    return {
      REQUEST: {
        dateTime: config.startTime || Date.now(),
        options: config,
        headers,
      },
      RESPONSE: null,
    };
  }

  /**
   * Create AMS log object for success response
   * @param {Object} amsLog - Base AMS log object
   * @param {Object} data - Response data
   * @param {Object} headers - Response headers
   * @param {number} statusCode - Response status code
   * @returns {Object} Updated AMS log object
   * @private
   */
  _createSuccessResponseLog(amsLog, data, headers, statusCode) {
    amsLog.RESPONSE = {
      dateTime: Date.now(),
      body: data,
      headers,
      statusCode,
    };
    amsLog.DURATION = amsLog.RESPONSE.dateTime - amsLog.REQUEST.dateTime;
    return amsLog;
  }

  /**
   * Create AMS log object for error response
   * @param {Object} amsLog - Base AMS log object
   * @param {Object} error - Error details
   * @param {string} errorType - Type of error (response, timeout, request)
   * @returns {Object} Updated AMS log object
   * @private
   */
  _createErrorResponseLog(amsLog, error, errorType = 'response') {
    let body;
    
    switch (errorType) {
      case 'timeout':
        body = 'ABORTED';
        break;
      case 'response':
        body = { 
          status: error.status, 
          data: error.data, 
          error: `Request failed with status ${error.status}` 
        };
        break;
      case 'request':
        body = { 
          error: error.message, 
          code: error.code, 
          status: error.status 
        };
        break;
      default:
        body = error;
    }

    amsLog.RESPONSE = {
      dateTime: Date.now(),
      body,
    };
    amsLog.DURATION = amsLog.RESPONSE.dateTime - amsLog.REQUEST.dateTime;
    return amsLog;
  }

  /**
   * Check if collection exists
   * @returns {Promise<boolean>}
   * @private
   */
  async _collectionExists() {
    try {
      const collections = await this.db.db.listCollections({ name: this.collectionName }).toArray();
      return collections.length > 0;
    } catch (error) {
      this.logger.error('Failed to check collection existence', { 
        error: error.message, 
        collectionName: this.collectionName 
      });
      return false;
    }
  }

  /**
   * Create collection if it doesn't exist
   * @returns {Promise<void>}
   * @private
   */
  async _ensureCollectionExists() {
    try {
      if (this._collectionExistsCache) {
        return;
      }

      const exists = await this._collectionExists();
      if (!exists) {
        try {
          await this.db.createCollection(this.collectionName);
          this.logger.info('Created AMS collection', { collectionName: this.collectionName });
        } catch (createError) {
          if (createError.code === 48 || createError.message.includes('already exists')) {
            this.logger.debug('Collection already exists (race condition)', { collectionName: this.collectionName });
          } else {
            throw createError;
          }
        }
      }
      
      this._collectionExistsCache = true;
    } catch (error) {
      this.logger.error('Failed to create collection', { 
        error: error.message, 
        collectionName: this.collectionName 
      });
    }
  }

  /**
   * Log AMS event asynchronously without waiting for completion
   * @param {Object} amsLog - AMS log object
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} requestId - Request identifier
   * @param {Object} flags - Flags for including identifiers
   */
  logEvent(amsLog, clientId = '', applicationNumber = '', requestId = '', flags = {}) {
    const { 
      clientIdFlag = true, 
      applicationNumberFlag = true, 
      requestIdFlag = true 
    } = flags;

    this._logEventAsync(amsLog, clientId, applicationNumber, requestId, flags).catch(error => {
      this.logger.error('Failed to log AMS event', { 
        error: error.message, 
        amsLog,
        clientId,
        applicationNumber,
        requestId
      });
    });
  }

  /**
   * Internal async method to handle the actual logging
   * @param {Object} amsLog - AMS log object
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} requestId - Request identifier
   * @param {Object} flags - Flags for including identifiers
   * @returns {Promise<void>}
   * @private
   */
  async _logEventAsync(amsLog, clientId, applicationNumber, requestId, flags) {
    try {
      await this._ensureCollectionExists();

      let duration = amsLog.DURATION;
      if (!duration && amsLog.REQUEST && amsLog.RESPONSE) {
        duration = amsLog.RESPONSE.dateTime - amsLog.REQUEST.dateTime;
      } else if (!duration) {
        duration = 0;
      }

      const serializedAmsLog = safeSerialize(amsLog);

      const logDocument = {
        clientId: clientId || 'NA',
        eventType: 'request-resp',
        result: { ...serializedAmsLog, DURATION: duration },
        requestId: requestId || 'NA',
        applicationNumber: applicationNumber || 'NA',
        txnId: 'NA',
        timestamp: new Date()
      };

      await this.db.collection(this.collectionName).insertOne(logDocument);
    } catch (error) {
      if (error.message.includes('collection') || error.message.includes('not found')) {
        try {
          this._collectionExistsCache = false;
          await this._ensureCollectionExists();
          await this.db.collection(this.collectionName).insertOne(logDocument);
        } catch (retryError) {
          this.logger.error('Failed to log AMS event after retry', { 
            error: retryError.message,
            originalError: error.message
          });
        }
      } else {
        throw error;
      }
    }
  }

  /**
   * Log successful request
   * @param {Object} config - Request configuration
   * @param {Object} headers - Request headers
   * @param {Object} response - Response data
   * @param {Object} responseHeaders - Response headers
   * @param {number} statusCode - Response status code
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} requestId - Request identifier
   * @param {Object} flags - Flags for including identifiers
   */
  logSuccess(config, headers, response, responseHeaders, statusCode, clientId, applicationNumber, requestId, flags = {}) {
    const amsLog = this._createRequestLog(config, headers);
    this._createSuccessResponseLog(amsLog, response, responseHeaders, statusCode);
    this.logEvent(amsLog, clientId, applicationNumber, requestId, flags);
  }

  /**
   * Log error response
   * @param {Object} config - Request configuration
   * @param {Object} headers - Request headers
   * @param {Object} error - Error details
   * @param {string} errorType - Type of error
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} requestId - Request identifier
   * @param {Object} flags - Flags for including identifiers
   */
  logError(config, headers, error, errorType, clientId, applicationNumber, requestId, flags = {}) {
    const amsLog = this._createRequestLog(config, headers);
    this._createErrorResponseLog(amsLog, error, errorType);
    this.logEvent(amsLog, clientId, applicationNumber, requestId, flags);
  }

  /**
   * Log request with existing AMS log object
   * @param {Object} amsLog - Existing AMS log object
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} requestId - Request identifier
   * @param {Object} flags - Flags for including identifiers
   */
  logExisting(amsLog, clientId, applicationNumber, requestId, flags = {}) {
    this.logEvent(amsLog, clientId, applicationNumber, requestId, flags);
  }
}

module.exports = { AMSService };
