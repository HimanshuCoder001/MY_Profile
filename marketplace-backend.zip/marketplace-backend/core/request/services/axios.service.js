'use strict';

const axios = require('axios');
const { v4: uuidv4 } = require('uuid');
const { LoggerFactory } = require('@logger');
const retry = require('async-retry');

const { buildAxiosConfig, buildFinalHeaders, maskHeaders } = require('../utils');
const { ResponseService } = require('./response.service');

class AxiosService {
  constructor() {
    this.logger = LoggerFactory.getLogger(AxiosService.name);
    this.responseService = ResponseService.getInstance();
  }

  /**
   * Get the singleton instance of the AxiosService
   * @returns {AxiosService}
   */
  static getInstance() {
    if (!AxiosService.instance) {
      AxiosService.instance = new AxiosService();
    }
    return AxiosService.instance;
  }

  /**
   * Create a new instance (use only for testing or special cases)
   * @returns {AxiosService}
   */
  static make() {
    return new AxiosService();
  }

  /**
   * Unified request handler using axios
   * @param {Object} config - { host, port, protocol, headers, method, url, baseURL? }
   * @param {Object} payload - request body for non-GET
   * @param {string} clientId
   * @param {string} applicationNumber - Optional application number (will not be logged if not provided)
   * @param {string} requestId
   * @param {Object} options - { query, headers, timeout, maxRetries, skipAmsLogging? }
   * @returns {Promise<Object>} response data
   */
  async handle(config, payload = {}, clientId = '', applicationNumber = '', requestId = '', options = {}) {
    const finalRequestId = requestId || uuidv4();
    const finalHeaders = buildFinalHeaders(config, options, clientId, applicationNumber, finalRequestId);
    const axiosConfig = buildAxiosConfig(config, payload, finalHeaders, options);
    const maskedHeaders = maskHeaders(finalHeaders);
    const maxRetries = Number.isInteger(options.maxRetries) ? options.maxRetries : 0;

    this.responseService.logRequestInit(axiosConfig, maskedHeaders);

    return await retry(async (bail, attempt) => {
      try {
        // Add metadata for logging
        axiosConfig.startTime = Date.now();
        axiosConfig.attempt = attempt;

        const response = await axios.request(axiosConfig);
        return await this.responseService.processResponse(
          response, axiosConfig, maskedHeaders,
          clientId, applicationNumber, finalRequestId, bail, options
        );
      } catch (error) {
        return await this.responseService.handleRequestError(
          error, axiosConfig, maskedHeaders,
          clientId, applicationNumber, finalRequestId, bail, options
        );
      }
    }, {
      retries: maxRetries,
      factor: options.retryFactor || 2,
      minTimeout: options.minTimeout || 100,
      maxTimeout: options.maxTimeout || undefined,
      randomize: Boolean(options.retryJitter) || false,
      onRetry: (err, attempt) => {
        this.responseService.logRetryCallback(err, attempt);
      }
    });
  }
}

module.exports = { AxiosService };
