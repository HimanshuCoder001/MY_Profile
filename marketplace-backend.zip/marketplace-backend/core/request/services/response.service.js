'use strict';

const config = require('config');
const { LoggerFactory } = require('@logger');
const { AMSService } = require('./ams.service');
const { isRetryableStatus, createResponseError, createRequestErrorContext } = require('../utils');
const { safeStringify, safeInspect } = require('../../utils/common.util');

class ResponseService {
  constructor() {
    this.logger = LoggerFactory.getLogger(ResponseService.name);
    this.amsService = AMSService.getInstance();
  }

  /**
   * Get singleton instance
   * @returns {ResponseService}
   */
  static getInstance() {
    if (!ResponseService.instance) {
      ResponseService.instance = new ResponseService();
    }
    return ResponseService.instance;
  }

  /**
   * Log request initialization
   * @param {Object} axiosConfig - Axios configuration
   * @param {Object} maskedHeaders - Masked headers
   */
  logRequestInit(axiosConfig, maskedHeaders) {
    // this.logger.info({
    //   ref: 'axios request init',
    //   data: {
    //     baseURL: axiosConfig.baseURL,
    //     url: axiosConfig.url,
    //     method: axiosConfig.method,
    //     params: axiosConfig.params,
    //     timeout: axiosConfig.timeout,
    //     headers: maskedHeaders,
    //   }
    // });
    // Clone and sanitize config for logging to fix payload : "[Circular Reference]"
    this.logger.info({
      ref: 'axios request init',
      data: {
        baseURL: axiosConfig.baseURL,
        url: axiosConfig.url,
        method: axiosConfig.method,
        params: axiosConfig.params,
        timeout: axiosConfig.timeout,
        headers: maskedHeaders,
        payload: safeStringify(axiosConfig.data)
      }
    });
  }

  /**
   * Log response information
   * @param {Object} response - Axios response
   */
  logResponse(response) {
    this.logger.info({ 
      ref: 'axios response', 
      data: { 
        status: response.status, 
        durationMs: Date.now() - response.config.startTime, 
        attempt: response.config.attempt 
      } 
    });
  }

  /**
   * Log retry attempt
   * @param {Error} error - Error object
   * @param {number} attempt - Attempt number
   */
  logRetryAttempt(error, attempt) {
    this.logger.warn({ 
      ref: 'axios retryable error', 
      data: { 
        attempt, 
        code: error.code, 
        status: error?.response?.status 
      } 
    });
  }

  /**
   * Log retry callback
   * @param {Error} error - Error object
   * @param {number} attempt - Attempt number
   */
  logRetryCallback(error, attempt) {
    this.logger.warn({ 
      ref: 'axios onRetry', 
      data: { 
        attempt, 
        code: error.code, 
        status: error?.response?.status 
      } 
    });
  }

  /**
   * Handle successful response
   * @param {Object} response - Axios response
   * @param {Object} axiosConfig - Axios configuration
   * @param {Object} maskedHeaders - Masked headers
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} finalRequestId - Request identifier
   * @param {Object} options - Request options including skipAmsLogging
   * @returns {Object} Response data
   */
  async handleSuccessResponse(response, axiosConfig, maskedHeaders, clientId, applicationNumber, finalRequestId, options = {}) {
    const { status, data, headers: responseHeaders } = response;
    
    // Only include applicationNumber in logs if it's provided
    const flags = {
      applicationNumberFlag: Boolean(applicationNumber && applicationNumber.trim())
    };
    
    // Skip AMS logging if skipAmsLogging is enabled or global AMS logging is disabled
    const shouldSkipAmsLogging = options.skipAmsLogging || !config.get('ams.enabled') || config.get('ams.skipLogging');
    if (!shouldSkipAmsLogging) {
      await this.amsService.logSuccess(
        axiosConfig,
        maskedHeaders,
        data,
        responseHeaders,
        status,
        clientId,
        applicationNumber,
        finalRequestId,
        flags
      );
    } else {
      this.logger.debug({
        ref: 'handleSuccessResponse',
        message: 'AMS logging skipped for this request',
        path: axiosConfig.url,
        method: axiosConfig.method,
        reason: options.skipAmsLogging ? 'request-level' : 'global-config'
      });
    }
    
    return data !== undefined ? data : response;
  }

  /**
   * Handle error response
   * @param {Object} response - Axios response
   * @param {Object} axiosConfig - Axios configuration
   * @param {Object} maskedHeaders - Masked headers
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} finalRequestId - Request identifier
   * @param {Function} bail - Retry bail function
   * @param {Object} options - Request options including skipAmsLogging
   * @returns {Object} Error object
   */
  async handleErrorResponse(response, axiosConfig, maskedHeaders, clientId, applicationNumber, finalRequestId, bail, options = {}) {
    const { status, data } = response;
    const isRetryable = isRetryableStatus(status);
    
    // Only include applicationNumber in logs if it's provided
    const flags = {
      applicationNumberFlag: Boolean(applicationNumber && applicationNumber.trim())
    };
    
    // Skip AMS logging if skipAmsLogging is enabled or global AMS logging is disabled
    const shouldSkipAmsLogging = options.skipAmsLogging || !config.get('ams.enabled') || config.get('ams.skipLogging');
    if (!shouldSkipAmsLogging) {
      await this.amsService.logError(
        axiosConfig,
        maskedHeaders,
        { status, data },
        'response',
        clientId,
        applicationNumber,
        finalRequestId,
        flags
      );
    } else {
      this.logger.debug({
        ref: 'handleErrorResponse',
        message: 'AMS logging skipped for this error response',
        path: axiosConfig.url,
        method: axiosConfig.method,
        status,
        reason: options.skipAmsLogging ? 'request-level' : 'global-config'
      });
    }
    
    const error = createResponseError(status, data);
    
    if (isRetryable) {
      throw error; // retry
    } else {
      return bail(error); // don't retry
    }
  }

  /**
   * Handle request error
   * @param {Error} error - Error object
   * @param {Object} axiosConfig - Axios configuration
   * @param {Object} maskedHeaders - Masked headers
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} finalRequestId - Request identifier
   * @param {Function} bail - Retry bail function
   * @param {Object} options - Request options including skipAmsLogging
   * @returns {Object} Error object or throws
   */
  async handleRequestError(error, axiosConfig, maskedHeaders, clientId, applicationNumber, finalRequestId, bail, options = {}) {
    const { isTimeoutError, isRetryableError, createRequestErrorContext } = require('../utils');
    
    const isTimeout = isTimeoutError(error);
    const retryable = isRetryableError(error);
    
    // Only include applicationNumber in logs if it's provided
    const flags = {
      applicationNumberFlag: Boolean(applicationNumber && applicationNumber.trim())
    };
    
    // Skip AMS logging if skipAmsLogging is enabled or global AMS logging is disabled
    const shouldSkipAmsLogging = options.skipAmsLogging || !config.get('ams.enabled') || config.get('ams.skipLogging');
    if (!shouldSkipAmsLogging) {
      if (isTimeout) {
        await this.amsService.logError(
          axiosConfig,
          maskedHeaders,
          { message: 'Request timeout' },
          'timeout',
          clientId,
          applicationNumber,
          finalRequestId,
          flags
        );
      } else {
        await this.amsService.logError(
          axiosConfig,
          maskedHeaders,
          createRequestErrorContext(error),
          'request',
          clientId,
          applicationNumber,
          finalRequestId,
          flags
        );
      }
    } else {
      this.logger.debug({
        ref: 'handleRequestError',
        message: 'AMS logging skipped for this request error',
        path: axiosConfig.url,
        method: axiosConfig.method,
        errorType: isTimeout ? 'timeout' : 'request',
        reason: options.skipAmsLogging ? 'request-level' : 'global-config'
      });
    }
    
    if (!retryable) {
      return bail(error);
    }
    
    this.logRetryAttempt(error, error.attempt);
    throw error; // retry
  }

  /**
   * Process axios response
   * @param {Object} response - Axios response
   * @param {Object} axiosConfig - Axios configuration
   * @param {Object} maskedHeaders - Masked headers
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} finalRequestId - Request identifier
   * @param {Function} bail - Retry bail function
   * @param {Object} options - Request options including skipAmsLogging
   * @returns {Object} Response data or error
   */
  async processResponse(response, axiosConfig, maskedHeaders, clientId, applicationNumber, finalRequestId, bail, options = {}) {
    const { status } = response;
    
    this.logResponse(response);

    if (status >= 200 && status < 300) {
      return await this.handleSuccessResponse(
        response, axiosConfig, maskedHeaders, 
        clientId, applicationNumber, finalRequestId, options
      );
    }
    
    return await this.handleErrorResponse(
      response, axiosConfig, maskedHeaders, 
      clientId, applicationNumber, finalRequestId, bail, options
    );
  }
}

module.exports = { ResponseService };
