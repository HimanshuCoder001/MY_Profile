'use strict';

const { ResponseService } = require('./response.service');
const { AxiosService } = require('./axios.service');
const { AMSService } = require('./ams.service');


module.exports = {
  ResponseService,
  AxiosService,
  AMSService,
};
