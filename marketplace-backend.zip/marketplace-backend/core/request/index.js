'use strict';

const { BaseRequest } = require('./base.request');
const { 
  ResponseService,
  AxiosService,
  AMSService,
} = require('./services');

module.exports = {
    BaseRequest,
    AMSService,
    ResponseService,
    AxiosService,
};