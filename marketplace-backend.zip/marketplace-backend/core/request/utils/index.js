'use strict';

const { buildBaseURL, selectAgent, buildAxiosConfig, DEFAULT_TIMEOUT_MS, SHARED_HTTP_AGENT, SHARED_HTTPS_AGENT } = require('./config.util');
const { maskHeaders, buildFinalHeaders, SENSITIVE_HEADERS } = require('./header.util');
const { isRetryableError, isTimeoutError, isRetryableStatus, createResponseError, createRequestErrorContext } = require('./error.util');

module.exports = {
    // Config utilities
    buildBaseURL,
    selectAgent,
    buildAxiosConfig,
    DEFAULT_TIMEOUT_MS,
    SHARED_HTTP_AGENT,
    SHARED_HTTPS_AGENT,

    // Header utilities
    maskHeaders,
    buildFinalHeaders,
    SENSITIVE_HEADERS,

    // Error utilities
    isRetryableError,
    isTimeoutError,
    isRetryableStatus,
    createResponseError,
    createRequestErrorContext,
};