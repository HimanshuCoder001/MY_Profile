'use strict';

const http = require('http');
const https = require('https');

// Keep-alive agents for connection reuse and lower latency
const SHARED_HTTP_AGENT = new http.Agent({ keepAlive: true, maxSockets: 100 });
const SHARED_HTTPS_AGENT = new https.Agent({ keepAlive: true, maxSockets: 100 });

const DEFAULT_TIMEOUT_MS = 40000;

/**
 * Build baseURL from config
 * @param {Object} config
 * @returns {string}
 */
function buildBaseURL(config) {
  if (config.baseURL) return config.baseURL;
  const protocol = String(config.protocol || 'https').replace(':', '').toLowerCase();
  const host = config.host || 'localhost';
  const port = config.port && String(config.port);
  const isDefaultPort = (!port) || (protocol === 'https' && port === '443') || (protocol === 'http' && port === '80');
  return isDefaultPort ? `${protocol}://${host}` : `${protocol}://${host}:${port}`;
}

/**
 * Select keep-alive agent by protocol
 * @param {string} protocol
 * @returns {{ httpAgent?: http.Agent, httpsAgent?: https.Agent }}
 */
function selectAgent(protocol) {
  const proto = String(protocol || 'https').replace(':', '').toLowerCase();
  return proto === 'http' ? { httpAgent: SHARED_HTTP_AGENT } : { httpsAgent: SHARED_HTTPS_AGENT };
}

/**
 * Build request configuration
 * @param {Object} config - Base config
 * @param {Object} reqBody - Request body
 * @param {Object} finalHeaders - Final headers
 * @param {Object} options - Additional options
 * @returns {Object} Axios configuration
 */
function buildAxiosConfig(config, reqBody, finalHeaders, options) {
  const { method } = config || {};
  const resolvedMethod = (method || 'POST').toUpperCase();
  const baseURL = buildBaseURL(config || {});
  const agent = selectAgent(config?.protocol);

  return {
    baseURL,
    url: config?.url || '/',
    method: resolvedMethod,
    headers: finalHeaders,
    timeout: options.timeout || DEFAULT_TIMEOUT_MS,
    params: options.query || undefined,
    data: resolvedMethod === 'GET' ? undefined : reqBody,
    validateStatus: () => true,
    responseType: options.responseType || 'json',
    ...agent,
    ...(options.axios || {}),
  };
}

module.exports = {
  buildBaseURL,
  selectAgent,
  buildAxiosConfig,
  DEFAULT_TIMEOUT_MS,
  SHARED_HTTP_AGENT,
  SHARED_HTTPS_AGENT,
};
