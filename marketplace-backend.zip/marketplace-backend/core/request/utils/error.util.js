'use strict';

/**
 * Whether the error is retryable
 * @param {any} error
 * @returns {boolean}
 */
function isRetryableError(error) {
  const networkCodes = ['ECONNABORTED', 'ECONNREFUSED', 'ENOTFOUND', 'EAI_AGAIN', 'ETIMEDOUT', 'EHOSTUNREACH'];
  if (networkCodes.includes(error?.code)) return true;
  const status = error?.response?.status;
  return status >= 500 && status < 600;
}

/**
 * Check if error is a timeout error
 * @param {Error} error
 * @returns {boolean}
 */
function isTimeoutError(error) {
  return error.code === 'ECONNABORTED' || error.message.includes('timeout');
}

/**
 * Check if response status indicates retryable error
 * @param {number} status
 * @returns {boolean}
 */
function isRetryableStatus(status) {
  return status >= 500;
}

/**
 * Create standardized error object
 * @param {number} status
 * @param {any} data
 * @returns {Error}
 */
function createResponseError(status, data) {
  const error = new Error(`Request failed with status ${status}`);
  error.response = { status, data };
  return error;
}

/**
 * Create request error object with additional context
 * @param {Error} error
 * @returns {Object}
 */
function createRequestErrorContext(error) {
  return {
    message: error.message,
    code: error.code,
    status: error?.response?.status,
  };
}

module.exports = {
  isRetryableError,
  isTimeoutError,
  isRetryableStatus,
  createResponseError,
  createRequestErrorContext,
};
