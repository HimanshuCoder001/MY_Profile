'use strict';

const SENSITIVE_HEADERS = ['authorization', 'x-api-key', 'cookie', 'set-cookie', 'iv'];

/**
 * Mask sensitive headers for safe logging
 * @param {Object} headers
 * @returns {Object}
 */
function maskHeaders(headers) {
  const out = { ...(headers || {}) };
  for (const key of Object.keys(out)) {
    if (SENSITIVE_HEADERS.includes(String(key).toLowerCase())) {
      out[key] = '***';
    }
  }
  return out;
}

/**
 * Build final headers with identifiers
 * @param {Object} config - Base config
 * @param {Object} options - Additional options
 * @param {string} clientId - Client identifier
 * @param {string} applicationNumber - Application number (optional)
 * @param {string} finalRequestId - Request identifier
 * @returns {Object} Final headers
 */
function buildFinalHeaders(config, options, clientId, applicationNumber, finalRequestId) {
  const { headers } = config || {};
  return {
    ...(headers || {}),
    ...(options.headers || {}),
    ...(clientId ? { clientId } : {}),
    ...(applicationNumber && applicationNumber.trim() ? { applicationNumber } : {}),
    requestId: finalRequestId,
  };
}

module.exports = {
  maskHeaders,
  buildFinalHeaders,
  SENSITIVE_HEADERS,
};
