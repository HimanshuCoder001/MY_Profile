const config = require("config");
const httpErrors = require('http-errors');
const { logger } = require('@spice-money/common-logger');
const { SessionService } = require('@modules/session/services');
const { AuthRequest } = require('@modules/session/requests');
const { SessionValidationException } = require("@exceptions")

/**
 * Authentication middleware for API key and token-based authentication
 * Supports multiple authentication types and IP whitelisting
 */
class AuthMiddleware {
  static instance = null;

  // Configuration constants
  static NON_AUTH_URLS = config.get("non-auth-urls");
  static CONTEXT_PATH = config.get("contextPath");
  static API_KEYS_MAP = config.get("api-key");
  
  // Cache compiled regex patterns for non-auth URLs
  static NON_AUTH_PATTERNS = Object.keys(AuthMiddleware.NON_AUTH_URLS).map(pattern => ({
    pattern,
    regex: new RegExp(`^${pattern.replace(/:[^/]+/g, '[^/]+')}$`)
  }));

  constructor() {
    this.sessionService = SessionService.getInstance();
    this.authRequest = AuthRequest.make();
    logger.info(`Initializing Auth middleware 🔑`);
  }

  /**
   * Get singleton instance 
   * @returns {AuthMiddleware}
   */
  static getInstance() {
    if (!AuthMiddleware.instance) {
      AuthMiddleware.instance = new AuthMiddleware();
    }
    return AuthMiddleware.instance;
  }

  /**
   * Main authentication middleware
   * Handles both API key and token-based authentication
   */
  authenticate = async (req, res, next) => {
    try {
      // Skip authentication for non-auth URLs
      if (this.isNonAuthUrl(req.path)) {
        return next();
      }

      const authResult = await this.performAuthentication(req);
      
      // Attach authentication data to request
      req.consumer = authResult.consumer;
      if (authResult.session) {
        req.session = authResult.session;
      }

      return next();
    } catch (error) {
      logger.debug({ 
        ref: 'authenticate', 
        message: 'Authentication failed', 
        path: req.path,
        ip: req.ip,
        error: error.message 
      });
      next(error);
    }
  }

  /**
   * Perform authentication using available methods
   * @private
   */
  performAuthentication = async (req) => {
    const apiKey = this.extractApiKey(req);
    let consumer = null;
  
    if (apiKey) {
      try {
        consumer = this.validateApiKey(apiKey);
      } catch (err) {
        // Log the failed API key validation but proceed with token auth
        logger.warn({
          ref: 'performAuthentication',
          message: 'Invalid API key, falling back to token-only auth',
          error: err.message,
          apiKey,
          ip: req.ip
        });
      }
    }
  
    if (consumer) {
      return await this.authenticateWithApiKey(req, consumer);
    }
  
    return await this.authenticateWithTokenOnly(req);
  }

  /**
   * Authenticate using API key (with optional token validation)
   * @private
   */
  authenticateWithApiKey = async (req, consumer) => {
    let session = null;

    this.validateConsumerPermissions(consumer);
    this.validateRequest(req, consumer);
    
    if (consumer.authType.includes('token')) {
      const token = this.extractTokenFromAuthHeader(req);
      session = await this.sessionService.validateToken(token, req.ip);
    }

    return { consumer, session };
  }

  /**
   * Authenticate using token only (when API key auth is not available)
   * @private
   */
  authenticateWithTokenOnly = async (req) => {
    const payload = this.extractTokenFromTokenHeader(req);
    const session = await this.validateTokenSession(payload);
    
    const consumer = {
      authType: ['token'],
      enabled: true,
      isIpCheckEnabled: false,
      requestTypes: ['*'] // Allow all request types for token auth
    };

    return { consumer, session };
  }

  /**
   * Extract API key from request headers
   * @private
   */
  // extractApiKey = (req) => {
  //   const apiKey = req.headers?.xapikey;
  //   if (!apiKey) {
  //     throw new httpErrors.Unauthorized('API key is required');
  //   }
  //   return apiKey;
  // }
  extractApiKey = (req) => {
    return req.headers?.xapikey || null;
  }

  /**
   * Extract token from Authorization header (for API Key + Token auth)
   * @private
   */
  extractTokenFromAuthHeader = (req) => {
    const authHeader = req.headers?.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new httpErrors.Unauthorized('Bearer token is required in Authorization header');
    }
    
    return authHeader.substring(7); // Remove 'Bearer ' prefix
  }

  /**
   * Extract token from token header (for Token-only auth)
   * @private
   */
  extractTokenFromTokenHeader = (req) => {
    const payload = {
      sessionID: req.headers?.token,
      aggID: req.headers?.aggid,
      clientID: req.headers?.clientid,
      publicIP: req.ip,
      udf1: '',
      udf2: '',
      requestMode: req.headers?.udf1,
      lang: req.headers?.lang,
    };
    
    if (!req.headers?.token) {
      throw new httpErrors.Unauthorized('Token is required in token header');
    }
    
    return payload;
  }

  /**
   * Validate API key and return consumer configuration
   * @private
   */
  validateApiKey = (apiKey) => {
    const consumer = AuthMiddleware.API_KEYS_MAP[apiKey];
    
    if (!consumer) {
      throw new httpErrors.Unauthorized('Invalid API key');
    }
    
    if (!consumer.enabled) {
      throw new httpErrors.Unauthorized('API key is disabled');
    }
    
    return consumer;
  }

  /**
   * Validate consumer permissions and configuration
   * @private
   */
  validateConsumerPermissions = (consumer) => {
    if (!consumer.authType || !Array.isArray(consumer.authType)) {
      throw new httpErrors.Unauthorized('Invalid consumer configuration');
    }

    const validAuthTypes = ['api-key', 'token'];
    const hasValidAuthType = consumer.authType.some(type => validAuthTypes.includes(type));
    
    if (!hasValidAuthType) {
      throw new httpErrors.Unauthorized('No valid authentication type configured');
    }
  }

  /**
   * Validate session using the specific payload structure
   * @private
   */
  validateTokenSession = async (payload) => {
    try {
      const response = await this.authRequest.validateSession(payload);
      if (response.responseStatus === 'SU' || response.responseStatus === 'S') {
        return {
          sessionId: response.sessionID,
          clientId: response.clientID,
          aggId: response.aggID,
          publicIP: payload.publicIP,
          udf1: response.udf1,
          lang: response.lang,
        };
      }

      throw new SessionValidationException('Session validation failed');
    } catch (error) {
      if (error instanceof httpErrors.Unauthorized) {
        throw error;
      }
      
      logger.error({ 
        ref: 'validateTokenSession', 
        message: 'Session validation error',
        error: error.message,
        stack: error.stack 
      });
      
      throw new SessionValidationException('Session validation failed');
    }
  }

  /**
   * Check if URL is in non-auth list using cached regex patterns
   * @private
   */
  isNonAuthUrl = (path) => {
    return AuthMiddleware.NON_AUTH_PATTERNS.some(({ regex }) => regex.test(path));
  }

  /**
   * Validate request IP and method permissions
   * @private
   */
  validateRequest = (req, consumer) => {
    const clientIP = req.ip;
    const route = req.path?.replace(AuthMiddleware.CONTEXT_PATH, '');
    const requestType = `${req.method}_${route}`;

    // Validate IP if IP checking is enabled
    if (consumer.isIpCheckEnabled && !this.isValidIP(clientIP, consumer)) {
      throw new httpErrors.Unauthorized(`IP ${clientIP} not whitelisted`);
    }

    // Validate request type
    if (!this.isValidRequestType(requestType, consumer)) {
      throw new httpErrors.Unauthorized(`Method ${req.method} and URI ${route} not permitted`);
    }
  }

  /**
   * Validate client IP against allowed IPs
   * @private
   */
  isValidIP = (clientIP, consumer) => {
    return Array.isArray(consumer.allowedIp) && consumer.allowedIp.includes(clientIP);
  }

  /**
   * Validate request type against allowed request types
   * @private
   */
  isValidRequestType = (requestType, consumer) => {
    if (!Array.isArray(consumer.requestTypes)) {
      return false;
    }
    
    // Check for wildcard permission
    if (consumer.requestTypes.includes('*')) {
      return true;
    }
    
    // Check for exact match
    if (consumer.requestTypes.includes(requestType)) {
      return true;
    }
    
    // Check for pattern matches with parameters (e.g., :productId)
    return consumer.requestTypes.some(pattern => {
      const regexPattern = pattern.replace(/:[^/]+/g, '[^/]+');
      const regex = new RegExp(`^${regexPattern}$`);
      return regex.test(requestType);
    });
  }
}

module.exports = { AuthMiddleware };