const { logger } = require('@spice-money/common-logger');
const createError = require('http-errors');

class ErrorMiddleware {
    static instance = null;

    constructor() {
        // Bind methods to preserve 'this' context
        logger.info('Initializing error middleware ⚠️');
        this.handleError = this.handleError.bind(this);
        this.handleNotFound = this.handleNotFound.bind(this);
        this.applyErrorMiddleware = this.applyErrorMiddleware.bind(this);
    }

    /**
     * Get the singleton instance of the ErrorMiddleware
     * @returns {ErrorMiddleware} The singleton instance
     */
    static getInstance() {
        if (!ErrorMiddleware.instance) {
            ErrorMiddleware.instance = new ErrorMiddleware();
        }
        return ErrorMiddleware.instance;
    }

    /**
     * Format error message based on environment
     * @param {Error} err - Error object
     * @returns {string} Formatted error message
     */
    getErrorMessage(err) {
        if (process.env.NODE_ENV === 'development') {
            return err.message || 'Internal Server Error';
        }
        return err.status === 500 ? 'Internal Server Error' : (err.message || 'An error occurred');
    }

    /**
     * Handle 404 errors
     * @param {import('express').Request} req - Express request object
     * @param {import('express').Response} res - Express response object
     * @param {import('express').NextFunction} next - Express next function
     */
    handleNotFound(req, res, next) {
        logger.info(`Initializing 404 handler 🔍`);
        next(createError(404, `Route not found: ${req.method} ${req.url}`));
    }

    /**
     * Handle all errors
     * @param {Error} err - Error object
     * @param {import('express').Request} req - Express request object
     * @param {import('express').Response} res - Express response object
     * @param {import('express').NextFunction} next - Express next function
     */
    handleError(err, req, res, _next) {
        const statusCode = err.status || err.statusCode || 500;
        
        // Log error with context
        logger.error('Error occurred:', {
            error: err,
            path: req.path,
            method: req.method,
            requestId: req.id,
            timestamp: new Date().toISOString()
        });

        // Send error response
        res.status(statusCode).json({
            status: false,
            message: this.getErrorMessage(err),
            ...(process.env.NODE_ENV === 'development' && { 
                stack: err.stack,
                details: err
            })
        });
    }

    /**
     * Apply error middleware to Express application
     * @param {import('express').Application} app - Express application instance
     */
    applyErrorMiddleware(app) {
        logger.info('Applying error middleware 🔧');
        app.use(this.handleNotFound);
        app.use(this.handleError);
        logger.info('Error middleware applied successfully ✅');
    }
}

module.exports = { ErrorMiddleware }; 
