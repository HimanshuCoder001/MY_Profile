/**
 * Middleware module exports
 * This module serves as the central export point for all middleware components
 */

const { logger } = require('@spice-money/common-logger');
const express = require('express');
const requestIp = require('request-ip');
const helmet = require('helmet');
const { requestLogMiddleware } = require('@spice-money/common-logger/express'); // eslint-disable-line
const { AuthMiddleware } = require('./auth.middleware');
const { CorsMiddleware } = require('./cors.middleware');
const { HeaderMiddleware } = require('./header.middleware');

class AppMiddleware {
  static instance = null;

  constructor() {
    this.initialize();
  }

  /**
   * Get the singleton instance of the AppMiddleware
   * @returns {AppMiddleware} The singleton instance
   */
  static getInstance() {
    if (!AppMiddleware.instance) {
      AppMiddleware.instance = new AppMiddleware();
    }
    return AppMiddleware.instance;
  }

  /**
   * Initialize middleware instances
   */
  initialize() {
    logger.info('Initializing middleware loader 🔄');
    this.auth = new AuthMiddleware();
    this.cors = new CorsMiddleware();
    logger.info('Middleware loader initialized successfully ✅');
  }

  /**
   * Initialize basic middleware
   * @param {express.Application} app - Express application instance
   */
  initializeBasicMiddleware(app) {
    logger.info('Initializing basic middleware 🔑');
    app.use(requestIp.mw({ attributeName: 'ip' }));
    app.use(express.urlencoded({ extended: true }));
    app.use(express.json({ limit: '50mb' }));
  }

  /**
   * Initialize request logging middleware
   * @param {express.Application} app - Express application instance
   */
  initializeRequestLogging(app) {
    logger.info('Initializing request logging middleware 🔑');
    app.use(requestLogMiddleware({
      logger,
      maskHeaders: ['xapikey', 'authorization'],
      includeRequestId: true
    }));
  }

  /**
   * Initialize security middleware
   * @param {express.Application} app - Express application instance
   */
  initializeSecurityMiddleware(app) {
    logger.info('Initializing security middleware 🔑');
    app.use(helmet({
      frameguard: { action: "deny" },
      contentSecurityPolicy: {
        directives: {
          frameAncestors: ["'none'"]
        }
      }
    }));
  }

  /**
   * Initialize CORS middleware
   * @param {express.Application} app - Express application instance
   */
  initializeCorsMiddleware(app) {
    const corsMiddleware = this.cors.handle();
    if (Array.isArray(corsMiddleware)) {
      corsMiddleware.forEach((middleware) => app.use(middleware));
    } else {
      app.use(corsMiddleware);
    }
  }

  /**
   * Initialize authentication middleware
   * @param {express.Application} app - Express application instance
   */
  initializeAuthMiddleware(app) {
    app.use(this.auth.authenticate);
  }

  /**
   * Add Last-Modified header middleware
   * @param {express.Application} app - Express application instance
   */
  addLastModifiedHeader(app) {
    app.use((req, res, next) => {
      res.setHeader('Last-Modified', new Date().toUTCString());
      next();
    });
  }

  /**
   * Initialize header extractor
   * @param {express.Application} app - Express application instance
   */
  initializeHeaderExtractor(app) {
    HeaderMiddleware.getInstance().initializeHeaderExtractor(app);
  }

  /**
   * Apply all middleware to Express application
   * @param {express.Application} app - Express application instance
   */
  applyMiddleware(app) {
    logger.info('Applying all middleware to application 🔧');

    // Initialize basic middleware
    this.initializeBasicMiddleware(app);

    // Initialize request logging
    this.initializeRequestLogging(app);

    // Initialize security middleware
    this.initializeSecurityMiddleware(app);

    // Initialize CORS middleware
    this.initializeCorsMiddleware(app);

    // Initialize authentication middleware
    this.initializeAuthMiddleware(app);

    // Initialize header extractor
    this.initializeHeaderExtractor(app);

    // Add Last-Modified header
    this.addLastModifiedHeader(app);

    // Note: Error middleware will be applied after routes in app.js
    logger.info('All middleware applied successfully ✅');
  }
}

module.exports = { AppMiddleware };
