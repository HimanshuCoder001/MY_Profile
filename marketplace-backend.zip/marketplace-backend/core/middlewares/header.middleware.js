const { ServiceFactory } = require('../factory');
const { LoggerFactory } = require('../logger');

class HeaderMiddleware {
    static instance = null;

    constructor() {
        this.logger = LoggerFactory.getLogger(HeaderMiddleware.name);
        this.headerExtractorFactory = this.headerExtractorFactory.bind(this);
        this.serviceFactory = ServiceFactory.getInstance();
    }

    /**
     * Get instance of HeaderMiddleware
     * @returns {HeaderMiddleware}
     */
    static getInstance() {
        if (!HeaderMiddleware.instance) {
            HeaderMiddleware.instance = new HeaderMiddleware();
        }
        return HeaderMiddleware.instance;
    }

    /**
     * Header extractor factory
     * @param {Object} req - Request object
     * @param {Object} res - Response object
     * @param {Function} next - Next function
     */
    headerExtractorFactory(req, res, next) {
        this.serviceFactory.setHeaderExtractor(req.headers, ['origin', 'referer']);
        this.logger.info({ ref: 'Header extractor initialized', headers: req.headers });
        next();
    }

    /**
     * Initialize header extractor
     * @param {Object} app - Express application
     */
    initializeHeaderExtractor(app) {
        app.use(this.headerExtractorFactory);
    }
}

module.exports = { HeaderMiddleware };
