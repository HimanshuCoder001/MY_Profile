const { ErrorMiddleware } = require('./error.middleware');
const { AppMiddleware } = require('./app.middleware');
const { AuthMiddleware } = require('./auth.middleware');

module.exports = {
    ErrorMiddleware,
    AppMiddleware,
    AuthMiddleware
};
