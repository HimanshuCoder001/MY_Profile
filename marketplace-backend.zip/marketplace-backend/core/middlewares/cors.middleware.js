const config = require("config");
const cors = require('cors');
const { logger } = require('@spice-money/common-logger');

class CorsMiddleware {
    static instance = null;

    constructor() {
        logger.info(`Initializing CORS middleware 🔑`);
        this.initializeConfig();
    }

    static getInstance() {
        if (!CorsMiddleware.instance) {
            CorsMiddleware.instance = new CorsMiddleware();
        }
        return CorsMiddleware.instance;
    }

    /**
     * Initialize CORS configuration from config
     */
    initializeConfig() {
        this.config = {
            contextPath: config.get('contextPath'),
            cors: {
                allowedOrigins: config.get('cors.origins'),
                allowLocalhost: config.get('cors.allowLocalhost'),
                methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
                headers: ['Content-Type', 'Authorization', 'X-API-Key']
            }
        };
    }

    /**
     * Express middleware handler for CORS
     * @returns {Function} Express middleware function
     */
    handle() {
        if (this.config.cors.allowLocalhost) {
            return [
                this.localhostCorsMiddleware,
                cors()
            ];
        }

        const corsOptions = {
            methods: this.config.cors.methods,
            origin: this.config.cors.allowedOrigins,
            credentials: true,
            optionsSuccessStatus: 204
        };

        return cors(corsOptions);
    }

    /**
     * CORS middleware for localhost
     * @param {Object} req - Express request object
     * @param {Object} res - Express response object
     * @param {Function} next - Express next middleware function
     */
    localhostCorsMiddleware = (req, res, next) => {
        res.setHeader('Access-Control-Allow-Origin', '*');
        res.setHeader('Access-Control-Allow-Methods', this.config.cors.methods.join(', '));
        res.setHeader('Access-Control-Allow-Headers', this.config.cors.headers.join(', '));
        res.setHeader('Access-Control-Allow-Credentials', 'true');
        res.setHeader('Content-Type', 'application/json; charset=utf-8');
        next();
    }
}

module.exports = { CorsMiddleware }; 