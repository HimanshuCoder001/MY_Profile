'use strict';

const { LoggerFactory } = require('@logger');

class ServiceFactory {
    static instance = null;
    static services = new Map();

    constructor() {
        this.logger = LoggerFactory.getLogger(ServiceFactory.name);
    }

    /**
     * Singleton getInstance method
     * @returns {ServiceFactory}
     */
    static getInstance() {
        if (!ServiceFactory.instance) {
            ServiceFactory.instance = new ServiceFactory();
        }
        return ServiceFactory.instance;
    }

    /**
     * Set header extractor
     * @param {Object} headers - Headers object
     * @param {string[]} headerNames - Array of header names
     */
    setHeaderExtractor(headers, headerNames) {
        if (headerNames) {
            headerNames.forEach(header => {
                ServiceFactory.services.set(header, headers[header.toLowerCase()] || '');
            }); 
        }
    }

    /**
     * Get header extractor
     * @param {string} headerName - Name of the header to get
     * @returns {string} Header value
     */
    getHeaderExtractor(headerName) {
        return ServiceFactory.services.get(headerName);
    }
}

module.exports = { ServiceFactory }; 
