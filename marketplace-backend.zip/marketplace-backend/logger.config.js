module.exports = {
    logLevel: process.env.LOG_LEVEL || 'info',
    sizeLimit: 3072,
    middlewares: [],
    transportConfig: {
      dirname: './logs',
      filename: '%DATE%',
      datePattern: 'YYYY-MM-DD',
      extension: '.log',
      zippedArchive: true,
      maxSize: '20m',
      maxFiles: '14d',
    },
    accessLog: true,
    accessLogConfig: {
      dirname: './logs',
      filename: 'access-%DATE%',
      datePattern: 'YYYY-MM-DD',
      extension: '.log',
      zippedArchive: true,
      maxSize: '20m',
      maxFiles: '14d',
    },
    maskConfig: {
      maskValue: '*****',
      delimiter: '.',
      maskStrings: true,
      stringPattern: undefined,
    },
    maskLogKeys: ['pan', 'panNo', 'pan_no'],
    defaultMeta: {
      service: 'marketplace-api',
    },
  };
  
