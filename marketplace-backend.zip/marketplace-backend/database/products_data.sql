-- Insert Products
INSERT INTO "lead-gen".t_products (product_id,
                                   name,
                                   type,
                                   parent_id,
                                   is_active,
                                   meta,
                                   created_at,
                                   updated_at)
VALUES
-- Shop keeper Insurance
('9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'Shop keeper Insurance',
 'insurance',
 null,
 true,
 NULL,
 NOW(),
 NOW()),
-- Mobile screen protection
('4324b3fe-62c2-46dc-917c-1df526e46aab',
 'Mobile screen protection',
 'insurance',
 null,
 false,
 NULL,
 NOW(),
 NOW()),
-- Digital Fraud Protection
('7e4634a6-c649-470c-9c7e-64a975ba26ec',
 'Digital Fraud Protection',
 'insurance',
 null,
 false,
 NULL,
 NOW(),
 NOW()),
-- Health Cover & Accidental Cover
('c4b3519d-e5cf-4338-aefd-4d1acc0a232c',
 'Health Cover & Accidental Cover',
 'insurance',
 null,
 false,
 NULL,
 NOW(),
 NOW()),
-- 2 Wheeler
('df21f1af-70b2-4a92-a95c-d91345e0b4ca',
 '2 Wheeler',
 'insurance',
 null,
 false,
 NULL,
 NOW(),
 NOW());


-- Insert Product Details for Child Products
INSERT INTO "lead-gen".t_product_details (detail_id,
                                          product_id,
                                          category,
                                          sub_category,
                                          partner_availability,
                                          competition_benchmarking,
                                          opportunity_type,
                                          is_active,
                                          faq,
                                          meta,
                                          created_at,
                                          updated_at)
VALUES
-- Mobile Screen Protection Details
('77d95a59-ecc7-4764-a69d-649333553992',
 '4324b3fe-62c2-46dc-917c-1df526e46aab',
 'Assistance',
 'Non-Pos',
 'One Assist',
 'Airtel Payments Bank',
 'NOP - 6000',
 true,
 '[]'::json,
 NULL,
 NOW(),
 NOW()),
-- Digital Fraud Protection Details
('d6fb7323-0d0d-4851-819b-89437b572418',
 '7e4634a6-c649-470c-9c7e-64a975ba26ec',
 'Assistance',
 'Non-Pos',
 'One Assist',
 '',
 'NOP - 10000',
 true,
 '[]'::json,
 NULL,
 NOW(),
 NOW()),
-- Shop Keeper Insurance Details
('3a000e31-dc12-4c6b-96d1-b0860f02e66a',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'Assistance',
 'Non-Pos',
 'Alliance broker',
 'CSC, Roinet, Bankit',
 'NOP - 2000',
 true,
 '[]'::json,
 NULL,
 NOW(),
 NOW()),
-- Health Cover & Accidental Cover Details
('18a8e44f-c139-4f6e-afa8-bff6839abec3',
 'c4b3519d-e5cf-4338-aefd-4d1acc0a232c',
 'Assistance',
 'Non-Pos',
 'Care Health & One Assist',
 'Airtel Payments Bank, Fino Payment bank, RNFI',
 'NOP - 5000',
 true,
 '[]'::json,
 NULL,
 NOW(),
 NOW()),
-- Health Cover & Accidental Cover Details
('81035cd2-9119-41cd-b64f-7730447bdea8',
 'df21f1af-70b2-4a92-a95c-d91345e0b4ca',
 'Insurance',
 'POS Product',
 'Digit',
 'Airtel Payments Bank, CSC,RNFI',
 'NOP - 10000',
 true,
 '[]'::json,
 NULL,
 NOW(),
 NOW());

INSERT INTO "lead-gen".t_product_banners (banner_id,
                                          product_id,
                                          banner_type,
                                          title,
                                          subtitle,
                                          description,
                                          image_url,
                                          mobile_image_url,
                                          icon_url,
                                          target_url,
                                          display_order,
                                          is_active,
                                          meta,
                                          created_at,
                                          updated_at)
VALUES
-- 1) Fire
('3b2b1c3c-2f2c-4a3b-8b7e-7e4e2a8f5a11',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'Covered in Shopkeeper Insurance',
 'Fire',
 NULL,
 'The policy covers damage to the insured property caused by fire resulting from its own fermentation, natural heating, or spontaneous combustion.',
 NULL, NULL, 'https://cdn.example.com/icons/fire.png', NULL,
 1, TRUE,
 '{}'::jsonb,
 NOW(), NOW()),

-- 2) Cash in Safe & Transit
('a9e12e79-6f3b-4de2-8ad7-5acb7a9b2b31',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'Covered in Shopkeeper Insurance',
 'Cash in Safe & Transit',
 NULL,
 'This policy covers the loss of money while it is kept in safe inside shop or being transported between the business premises and other locations.',
 NULL, NULL, 'https://cdn.example.com/icons/cash-safe-transit.png', NULL,
 2, TRUE,
 '{}'::jsonb,
 NOW(), NOW()),

-- 3) Natural Calamities
('0c7b1b9e-0b65-4105-8f9c-9d9f7a3f6e42',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'Covered in Shopkeeper Insurance',
 'Natural Calamities',
 NULL,
 'Coverage for physical loss to the insured property because of storm, earthquakes, volcanic eruptions, cyclone, tempest, flood, etc.',
 NULL, NULL, 'https://cdn.example.com/icons/natural-calamities.png', NULL,
 3, TRUE,
 '{}'::jsonb,
 NOW(), NOW()),

-- 4) Health Tele Consultation
('6b8c6c3e-3f3e-4b9f-8e21-2c2d7f9a0b53',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'Covered in Shopkeeper Insurance',
 'Health Tele Consultation',
 NULL,
 'Free tele-doctor access, fully covered under your shop insurance benefit—instant, convenient, and visible from day one.',
 NULL, NULL, 'https://cdn.example.com/icons/health-tele-consultation.png', NULL,
 4, TRUE,
 '{}'::jsonb,
 NOW(), NOW()),

-- 5) Theft
('f4dd5bb1-4a5a-4c1a-9e9b-8c1b9a7d0c64',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'Covered in Shopkeeper Insurance',
 'Theft',
 NULL,
 'Theft or Burglary reported within 7 days from the insured premises after the occurrence of the incident.',
 NULL, NULL, 'https://cdn.example.com/icons/theft.png', NULL,
 5, TRUE,
 '{}'::jsonb,
 NOW(), NOW()),

-- 6) Personal Accident Cover
('19b1f3a8-0c5e-4a3c-8b91-5e7d1f6a7b75',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'Covered in Shopkeeper Insurance',
 'Personal Accident Cover',
 NULL,
 'This policy covers the insured for Accidental Death, Partial or Total Disability.',
 NULL, NULL, 'https://cdn.example.com/icons/personal-accident-cover.png', NULL,
 6, TRUE,
 '{}'::jsonb,
 NOW(), NOW());


INSERT INTO "lead-gen".t_product_banners (banner_id,
                               product_id,
                               banner_type,
                               title,
                               subtitle,
                               description,
                               image_url,
                               mobile_image_url,
                               icon_url,
                               target_url,
                               display_order,
                               is_active,
                               meta,
                               created_at,
                               updated_at)
VALUES
-- 1) Enter Personal Details
('c1b8a1e2-8f2a-4b2c-bb37-bbe06a5c7181',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'How To Buy Insurance For Your Shop ?',
 'Enter Personal Details',
 NULL,
 'Start by filling out your personal information — name, contact info, etc.',
 NULL, NULL, 'https://cdn.example.com/icons/step1-personal-details.png', NULL,
 1, TRUE,
 '{}'::jsonb,
 NOW(), NOW()),

-- 2) Choose a Plan
('b03a91b9-9b8f-4a5b-ae37-7286a978cf2b',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'How To Buy Insurance For Your Shop ?',
 'Choose a Plan',
 NULL,
 'Browse and select the insurance package that best fits your shop’s needs.',
 NULL, NULL, 'https://cdn.example.com/icons/step2-choose-plan.png', NULL,
 2, TRUE,
 '{}'::jsonb,
 NOW(), NOW()),

-- 3) Provide Shop Information
('8e31de77-b76f-45c6-9a8c-1e816a54e6a7',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'How To Buy Insurance For Your Shop ?',
 'Provide Shop Information',
 NULL,
 'Enter essential shop details such as address and ownership type.',
 NULL, NULL, 'https://cdn.example.com/icons/step3-shop-info.png', NULL,
 3, TRUE,
 '{}'::jsonb,
 NOW(), NOW()),

-- 4) Make Payment
('0a799a27-2a0c-4c9f-8dcb-52f7a028c10c',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'How To Buy Insurance For Your Shop ?',
 'Make Payment',
 NULL,
 'Complete the transaction to confirm your selected plan.',
 NULL, NULL, 'https://cdn.example.com/icons/step4-make-payment.png', NULL,
 4, TRUE,
 '{}'::jsonb,
 NOW(), NOW()),

-- 5) Policy Issued
('7f34dc4d-320e-4af1-8f0b-b2783a7e4e9d',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'How To Buy Insurance For Your Shop ?',
 'Policy Issued',
 NULL,
 'Once the payment is successful, your policy is generated – you will get details on it.',
 NULL, NULL, 'https://cdn.example.com/icons/step5-policy-issued.png', NULL,
 5, TRUE,
 '{}'::jsonb,
 NOW(), NOW());

-- Insert Sample Product Forms
INSERT INTO "lead-gen".t_product_forms (
  form_id,
  product_id,
  name,
  description,
  form_type,
  form_json,
  is_active,
  meta,
  created_at,
  updated_at
)
VALUES
-- Flutter dynamic form
(
 'a2f7b9f4-5c1b-4f3e-9b0c-2c7a0de9a111',
 '9e0e68b4-1d7d-4e74-b7a4-674c506ff611',
 'Shop Keeper Insurance Lead Form',
 'Shop Keeper Insurance',
 'SHOP_INSURANCE_LEAD_FORM',
 '{
   "title": "Fill the Details",
   "submit": { "label": "View Plans" },
   "fields": [
     {
       "type": "text",
       "name": "fullName",
       "label": "Name",
       "placeholder": "please enter the name",
       "keyboard": "text",
       "autofillHint": "name",
       "validators": [
         { "type": "required", "message": "Name is required" },
         { "type": "minLength", "value": 2, "message": "Enter at least 2 characters" }
       ]
     },
     {
       "type": "phone",
       "name": "mobile",
       "label": "Mobile Number",
       "placeholder": "please enter the mobile no",
       "keyboard": "phone",
       "maxLength": 10,
       "validators": [
         { "type": "required", "message": "Mobile number is required" },
         { "type": "pattern", "value": "^\\d{10}$", "message": "Enter a valid 10-digit number" }
       ]
     },
     {
       "type": "email",
       "name": "email",
       "label": "Email ID",
       "placeholder": "please enter the email",
       "keyboard": "email",
       "autofillHint": "email",
       "validators": [
         { "type": "required", "message": "Email is required" },
         { "type": "email", "message": "Enter a valid email" }
       ]
     },
     {
       "type": "select",
       "name": "gender",
       "label": "Gender",
       "options": [
         { "label": "Male", "value": "male" },
         { "label": "Female", "value": "female" },
         { "label": "Other", "value": "other" },
         { "label": "Prefer not to say", "value": "na" }
       ],
       "validators": [
         { "type": "required", "message": "Please select gender" }
       ]
     }
   ]
 }'::jsonb,
 TRUE,
 '{"source":"ui-mock","version":"1.0"}'::jsonb,
 NOW(), NOW());