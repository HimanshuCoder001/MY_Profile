'use strict';
require('express-router-group');

const express = require('express');
const router = express.Router();
const {
  dmsRoutes,
  grahakLoanRoutes,
  productTileRoutes,
  walletRoutes,
  sessionRoutes,
  shopInsuranceRoutes
} = require('@modules');

const { healthRoutes } = require('@core/health');
const { sendWrapped } = require('@utils');

express.response.sendWrapped = sendWrapped;

router.group('/health', (router) => healthRoutes(router));  // Working, need in PM2 automation script
router.group('/session', (router) => sessionRoutes(router)); // WIP
router.group('/dms', (router) => dmsRoutes(router)); // Need to check with Ankush
// router.group('/bank-sathi', (router) => bankSRoutes(router)); // No longer in use
router.group('/grahak-loan', (router) => grahakLoanRoutes(router)); // Verified
router.group('/product-tile', (router) => productTileRoutes(router)); // WIP
router.group('/insurance', (router) => walletRoutes(router));   // WIP
router.group('/shop-insurance', (router) => shopInsuranceRoutes(router)); // Shop Insurance Management System

module.exports = router;
