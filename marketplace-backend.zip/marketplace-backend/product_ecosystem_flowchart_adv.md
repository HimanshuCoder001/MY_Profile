# Product Ecosystem Flowchart - Fixed Version

```mermaid
graph TB
    %% Main Product Table
    subgraph "Core Product Management"
        Products["📦 PRODUCTS<br/>Table: t_products<br/>Primary Key: product_id"]
        Products -->|1:N| ProductDetails
        Products -->|1:N| ProductForms
        Products -->|1:N| ProductBanners
    end

    %% Product Details
    subgraph "Product Information"
        ProductDetails["📋 PRODUCT DETAILS<br/>Table: t_product_details<br/>Primary Key: detail_id<br/>FK: product_id"]
        ProductDetails -->|Belongs to| Products
    end

    %% Product Forms
    subgraph "Product Forms & Versions"
        ProductForms["📝 PRODUCT FORMS<br/>Table: t_product_forms<br/>Primary Key: form_id<br/>FK: product_id"]
        ProductForms -->|Belongs to| Products
    end

    %% Product Banners - Multiple Arrays by Type
    subgraph "Product Banners by Type"
        ProductBanners["🖼️ PRODUCT BANNERS<br/>Table: t_product_banners<br/>Primary Key: banner_id<br/>FK: product_id<br/>Key Field: banner_type"]
        ProductBanners -->|Belongs to| Products
        
        %% Banner Types
        HeroBanners["🏆 HERO BANNERS<br/>banner_type: 'hero'<br/>Multiple banners per product"]
        CategoryBanners["📂 CATEGORY BANNERS<br/>banner_type: 'category'<br/>Multiple banners per product"]
        PromotionalBanners["🎯 PROMOTIONAL BANNERS<br/>banner_type: 'promotional'<br/>Multiple banners per product"]
        FeaturedBanners["⭐ FEATURED BANNERS<br/>banner_type: 'featured'<br/>Multiple banners per product"]
        MobileBanners["📱 MOBILE BANNERS<br/>banner_type: 'mobile'<br/>Multiple banners per product"]
        
        ProductBanners -->|Multiple Arrays| HeroBanners
        ProductBanners -->|Multiple Arrays| CategoryBanners
        ProductBanners -->|Multiple Arrays| PromotionalBanners
        ProductBanners -->|Multiple Arrays| FeaturedBanners
        ProductBanners -->|Multiple Arrays| MobileBanners
    end

    %% Business Process Tables
    subgraph "Business Operations"
        Leads["👥 LEADS<br/>Table: t_leads<br/>Primary Key: lead_id"]
        Transactions["💰 TRANSACTIONS<br/>Table: t_transactions<br/>Primary Key: request_id"]
        ServiceableClients["✅ SERVICEABLE CLIENTS<br/>Table: t_serviceable_clients<br/>Composite Key: client_id + redirection_type"]
    end

    %% Product Hierarchy
    subgraph "Product Hierarchy"
        ParentProducts["🏢 PARENT PRODUCTS<br/>parent_id = NULL"]
        ChildProducts["🏪 CHILD PRODUCTS<br/>parent_id = product_id"]
        
        ParentProducts -->|1:N| ChildProducts
        ChildProducts -->|Belongs to| ParentProducts
    end

    %% Data Flow Process
    subgraph "Data Flow Process"
        Start([🚀 START])
        ProductCreation["➕ STEP 1: CREATE PRODUCT"]
        BannerAssignment["🖼️ STEP 2: ASSIGN BANNERS BY TYPE"]
        FormVersioning["📝 STEP 3: CREATE FORM VERSIONS"]
        DetailEnrichment["📋 STEP 4: ADD PRODUCT DETAILS"]
        LeadGeneration["👥 STEP 5: GENERATE LEADS"]
        TransactionProcessing["💰 STEP 6: PROCESS TRANSACTIONS"]
        ClientServiceability["✅ STEP 7: CHECK CLIENT SERVICEABILITY"]
        
        Start --> ProductCreation
        ProductCreation --> BannerAssignment
        ProductCreation --> FormVersioning
        ProductCreation --> DetailEnrichment
        ProductCreation --> LeadGeneration
        LeadGeneration --> TransactionProcessing
        TransactionProcessing --> ClientServiceability
    end

    %% Relationships
    Leads -.->|product field| Products
    Transactions -.->|source field| Products
    ServiceableClients -.->|redirection_type| Products

    %% Styling
    classDef productTable fill:#e1f5fe,stroke:#01579b,stroke-width:2px
    classDef bannerTable fill:#fff3e0,stroke:#e65100,stroke-width:2px
    classDef businessTable fill:#f3e5f5,stroke:#4a148c,stroke-width:2px
    classDef processNode fill:#e8f5e8,stroke:#2e7d32,stroke-width:2px

    class Products,ProductDetails,ProductForms productTable
    class ProductBanners,HeroBanners,CategoryBanners,PromotionalBanners,FeaturedBanners,MobileBanners bannerTable
    class Leads,Transactions,ServiceableClients businessTable
    class Start,ProductCreation,BannerAssignment,FormVersioning,DetailEnrichment,LeadGeneration,TransactionProcessing,ClientServiceability processNode
```

## **Key Features of the Product Ecosystem:**

### **1. Core Product Structure**
- **Products** table serves as the central entity
- Supports hierarchical structure (parent-child relationships)
- Contains basic product information (name, type, active status)

### **2. Product Details Management**
- **ProductDetails** stores comprehensive product information
- Includes categories, subcategories, product types
- Contains FAQ data and competition benchmarking
- Partner availability and opportunity type tracking

### **3. Dynamic Form System**
- **ProductForms** manages multiple form versions per product
- JSON-based form definitions for flexibility
- Version control and status management
- Meta information storage

### **4. Multi-Type Banner System** ⭐
**This is the core feature you mentioned - multiple arrays of objects against one single product divided by ProductBanners type column:**

- **ProductBanners** supports multiple banner types per product
- **Each product can have multiple banners of each type:**
  - 🏆 **Hero Banners** (`banner_type: 'hero'`) - Primary display banners
  - 📂 **Category Banners** (`banner_type: 'category'`) - Category-specific displays
  - 🎯 **Promotional Banners** (`banner_type: 'promotional'`) - Campaign-specific banners
  - ⭐ **Featured Banners** (`banner_type: 'featured'`) - Highlight banners
  - 📱 **Mobile Banners** (`banner_type: 'mobile'`) - Mobile-optimized banners
- Client-specific banner targeting with `client_id` field
- Order management with `display_order` for proper sequencing
- Rich media support (images, mobile images, icons, target URLs)

### **5. Business Process Integration**
- **Leads** table tracks product-specific lead generation
- **Transactions** records product-related financial activities
- **ServiceableClients** manages client eligibility per product type

### **6. Data Flow Process**
1. **Product Creation** - Initialize product with basic information
2. **Banner Assignment** - Create multiple banner arrays by type
3. **Form Versioning** - Design and version dynamic forms
4. **Detail Enrichment** - Add comprehensive product details
5. **Lead Generation** - Track product-specific leads
6. **Transaction Processing** - Handle financial activities
7. **Client Serviceability** - Validate client eligibility

This architecture allows for flexible product management with multiple banner types, dynamic forms, and comprehensive business process tracking.
