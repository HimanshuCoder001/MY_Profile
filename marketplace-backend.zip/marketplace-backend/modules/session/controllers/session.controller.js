const { LoggerFactory } = require('@logger');
const { SessionService } = require('../services');

class SessionController {
  static instance = null;

  constructor() {
    this.sessionService = SessionService.getInstance();
    this.logger = LoggerFactory.getLogger(SessionController.name);
  }

  /**
   * Get instance of SessionController
   * @returns {SessionController} - Instance of SessionController
   */
  static getInstance() {
    if (!SessionController.instance) {
      SessionController.instance = new SessionController();
    }
    return SessionController.instance;
  }

  /**
   * Validate session
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response from the request
   */
  async validateSession(req, res) {
    try {
      const { session, clientId, aggId, udf1, lang } = req.body;
      const ip = req.ip;
      const response = await this.sessionService.validateSession(session, clientId, aggId, udf1, lang, ip);
      res.sendWrapped(null, response, 'Session validated successfully');
    } catch (error) {
      this.logger.error({ ref: 'validateSession', error });
      res.sendWrapped(error);
    }
  }

  /**
   * Get session by API key
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The session data
   */
  async getSessionByApiKey(req, res) {
    try {
      const { apiKey } = req.params;
      const session = await this.sessionService.getSessionByApiKey(apiKey);
      res.sendWrapped(null, session);
    } catch (error) {
      this.logger.error({ ref: 'getSessionByApiKey', error });
      res.sendWrapped(error);
    }
  }

  /**
   * Update session status
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The updated session
   */
  async updateSessionStatus(req, res) {
    try {
      const { apiKey } = req.params;
      const { status } = req.body;
      
      const session = await this.sessionService.updateSessionStatus(apiKey, status);
      res.sendWrapped(null, session);
    } catch (error) {
      this.logger.error({ ref: 'updateSessionStatus', error });
      res.sendWrapped(error);
    }
  }
}

module.exports = { SessionController };