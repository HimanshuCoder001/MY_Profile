const { SessionController } = require('./session.controller');

module.exports = {
    SessionController,
};