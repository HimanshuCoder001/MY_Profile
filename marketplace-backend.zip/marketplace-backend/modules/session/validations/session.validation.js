'use strict';

const { ValidationUtil } = require('@utils');
const {
  validateSessionSchema,
} = require('./schemas');

class SessionValidation {
  /**
   * Validate session schema using common validation utility
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   * @param {Function} next - Next middleware function
   * @returns {void}
   */
  static validateSessionSchema(req, res, next) {
    return ValidationUtil.validateSchema(req, res, next, validateSessionSchema, {
      errorFormat: 'structured',
      logScope: 'SessionValidation'
    });
  }
}

module.exports = { SessionValidation };