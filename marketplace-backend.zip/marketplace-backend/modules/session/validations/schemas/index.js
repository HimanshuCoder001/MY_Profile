const validateSessionSchema = require('./validate-session.schema.json');

module.exports = {
  validateSessionSchema,
};