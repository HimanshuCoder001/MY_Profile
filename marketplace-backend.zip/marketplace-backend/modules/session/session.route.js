'use strict';

const { SessionController } = require('./controllers');
const { SessionValidation } = require('./validations/session.validation');

const sessionController = SessionController.getInstance();

module.exports = (router) => {
    router.post('/validate', SessionValidation.validateSessionSchema, sessionController.validateSession.bind(sessionController));
};