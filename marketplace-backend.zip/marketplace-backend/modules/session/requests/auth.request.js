'use strict';

const config = require('config');
const { LoggerFactory } = require('@logger');
const { AxiosService } = require('@request');

class AuthRequest {
    static instance = null;

    constructor() {
        this.axiosService = AxiosService.make();
        this.authConfig = config.get('auth');
        this.logger = LoggerFactory.getLogger(AuthRequest.name);
    }

    /**
     * Make a new instance of AuthRequest
     * @returns {AuthRequest}
     */
    static make() {
        return new AuthRequest();
    }

    /**
     * Validate session
     * @param {Object} data - The data for the request
     * @param {string} data.session - The session to validate
     * @param {string} data.clientId - The client ID
     * @param {string} data.aggId - The agg ID
     * @param {string} data.udf - The udf
     * @param {string} data.lang - The language
     * @returns {Promise<Object>} - The response from the request
     */
    async validateSession(data) {
        try {
            const { host, port, protocol, endpoints, headers } = this.authConfig;

            const config = {
                host,
                port,
                protocol,
                headers,
                method: endpoints.session_validate.method || 'POST',
                url: endpoints.session_validate.url,
            };
    
            return this.axiosService.handle(config, data, data.clientId);
        } catch (error) {
            this.logger.error({ ref: 'validateSession', error });
            throw error;
        }
    }
}

module.exports = { AuthRequest };