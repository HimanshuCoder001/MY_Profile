const { AuthRequest } = require('./auth.request');

module.exports = {
    AuthRequest,
};