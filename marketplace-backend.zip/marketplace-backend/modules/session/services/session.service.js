const { LoggerFactory } = require('@logger');
const { AuthRequest } = require('../requests');
const Session = require('@odm/models/session');
const { generateApiKey, getApiKeyBySource, API_KEY_SOURCE } = require('@utils');
const { SessionValidationException } = require('@exceptions');

class SessionService {
    static instance = null;

    constructor() {
        this.authRequest = AuthRequest.make();
        this.logger = LoggerFactory.getLogger(SessionService.name);
    }

    /**
     * Get instance of SessionService
     * @returns {SessionService}
     */
    static getInstance() {
        if (!SessionService.instance) {
            SessionService.instance = new SessionService();
        }
        return SessionService.instance;
    }

    /**
     * Validate session
     * @param {string} session - The session to validate
     * @param {string} clientId - The client ID
     * @param {string} aggId - The agg ID
     * @param {string} udf1 - The udf1
     * @param {string} lang - The language
     * @param {string} publicIP - The public IP address
     * @returns {Promise<Object>} - The response from the request
     */
    async validateSession(session, clientId, aggId, udf1, lang, publicIP) {
        try {
            const response = await this.authRequest.validateSession({
                sessionID: session,
                clientID: clientId,
                aggID: aggId,
                requestMode: udf1,
                udf2: 'FIRST',
                udf1,
                publicIP,
                lang
            });

            // Check if session validation succeeded
            if (response.responseStatus === 'SU' || response.responseStatus === 'S') {
                this.logger.info({ ref: 'validateSession', message: 'Session validation succeeded, storing in database', response });
                
                // Generate API key for successful session
                const token = generateApiKey();
                
                // Store successful session in MongoDB
                const sessionData = new Session({
                    sessionId: session,
                    clientId,
                    aggId,
                    publicIP,
                    udf1,
                    lang,
                    token,
                    validationResponse: response
                });

                await sessionData.save();
                return {
                    apiKey: getApiKeyBySource(API_KEY_SOURCE.CREDIT).apiKey,
                    token,
                };
            }

            throw new SessionValidationException('Session validation failed');
        } catch (error) {
            this.logger.error({ ref: 'validateSession', error });
            throw error;
        }
    }

    /**
     * Validate token by finding session in database
     * @param {string} token - The token to validate
     * @param {string} publicIP - The public IP address
     * @returns {Promise<Object>} - The session data if valid
     */
    async validateToken(token, publicIP) {
        try {
            const session = await Session.findOne({ token: token }, 'validationResponse sessionId aggId clientId udf1 lang');

            if (!session) {
                throw new SessionValidationException('Invalid or expired token');
            }

            const response = await this.authRequest.validateSession({
                sessionID: session.validationResponse.sessionID,
                clientID: session.clientId,
                aggID: session.aggId,
                requestMode: session.udf1,
                udf2: '',
                udf1: '',
                publicIP,
                lang: session.lang
            });

            // Check if session validation succeeded
            if (response.responseStatus === 'SU' || response.responseStatus === 'S') {
                return session;
            }

            throw new SessionValidationException('Session validation failed');
        } catch (error) {
            this.logger.error({ ref: 'validateToken', error });
            throw error;
        }
    }
}

module.exports = { SessionService };