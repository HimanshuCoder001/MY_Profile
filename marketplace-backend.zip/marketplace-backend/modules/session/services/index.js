const { SessionService } = require('./session.service');

module.exports = {
    SessionService,
};