'use strict';

const config = require('config');
const { BaseRequest } = require('@request');
const { LoggerFactory } = require('@logger');

class DmsRequest {

    constructor() {
        this.baseRequest = BaseRequest.make();
        this.dmsConfig = config.get('dms');
        this.logger = LoggerFactory.getLogger(DmsRequest.name);
    }

    static make() {
        return new DmsRequest();
    }

    /**
     * Get DMS file
     * @param {Object} payload - The payload for the request
     * @returns {Promise<Object>} - The response from the request
     */
    async getDmsFile(documentType, clientId, applicationNumber, requestId) {
        try {
            const { host, port, protocol, endpoints, headers } = this.dmsConfig;

            const config = {
                host,
                port,
                protocol,
                headers,
                method: endpoints.get_file.method || 'GET',
                url: `${endpoints.get_file.url}/${clientId}?documentType=${documentType}`,
            };

            return await this.baseRequest.handle(config, {}, clientId, applicationNumber, requestId);
        } catch (error) {
            this.logger.error({ ref: 'get DMS file error', error });
            throw error;
        }
    }

    /**
     * Upload to DMS
     * @param {Object} payload - The payload for the request
     * @returns {Promise<Object>} - The response from the request
     */
    async uploadToDms(payload, clientId, applicationNumber, requestId) {
        try {
            const { host, port, protocol, endpoints, headers } = this.dmsConfig;

            const config = {
                host,
                port,
                protocol,
                headers,
                method: endpoints.upload_to_dms.method || 'POST',
                url: endpoints.upload_to_dms.url,
            };

            return await this.baseRequest.handle(config, payload, clientId, applicationNumber, requestId);
        } catch (error) {
            this.logger.error({ ref: 'upload to DMS file error', error });
            throw error;
        }
    }
}

module.exports = { DmsRequest };