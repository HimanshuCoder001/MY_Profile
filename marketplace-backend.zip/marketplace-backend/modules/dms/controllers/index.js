const { DMSController } = require('./dms.controller');

module.exports = {
    DMSController,
};