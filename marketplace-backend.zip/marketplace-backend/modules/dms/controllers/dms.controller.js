'use strict';

const { LoggerFactory } = require('@logger');
const { DmsRequest } = require('../request/dms.request');
const { v4: uuidv4 } = require('uuid');

class DMSController {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(DMSController.name);
    this.dmsRequest = DmsRequest.make();
  }

  /**
   * Get the singleton instance of DMSController
   * @returns {DMSController}
   */
  static getInstance() {
    if (!DMSController.instance) {
      DMSController.instance = new DMSController();
    }
    return DMSController.instance;
  }

  /**
   * Get the document details
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async getDocumentDetails(req, res) {
    try {
      const { documentType, applicationNumber } = req.body;
      const { clientid: clientId } = req.headers;
      const requestId = uuidv4();

      const response = await this.dmsRequest.getDmsFile(documentType, clientId, applicationNumber, requestId);
      this.logger.info({ ref: "get DMS document details response", data: response });

      return res.sendWrapped(null, response);
    } catch (error) {
      this.logger.error({ ref: "Error in getDocumentDetails", error });
      return res.sendWrapped(error);
    }
  };

  /**
   * Upload the document
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async uploadDocument(req, res) {
    try {
      const { mobileNo, file } = req.body;
      const { clientid: clientId } = req.headers;
      const requestId = uuidv4();

      const reqData = {
        file: file,
        documentType: "proof_of_funds_transfer",
        smaId: clientId,
        mobileNo: mobileNo,
        applicationNumber: mobileNo,
      };
      const response = await this.dmsRequest.uploadToDms(reqData, clientId, mobileNo, requestId);
      this.logger.info({ ref: "upload DMS document response", data: response });

      return res.sendWrapped(null, response);
    } catch (error) {
      this.logger.error({ ref: "Error in uploadDocument", error });
      return res.sendWrapped(error);
    }
  };
}

module.exports = { DMSController };
