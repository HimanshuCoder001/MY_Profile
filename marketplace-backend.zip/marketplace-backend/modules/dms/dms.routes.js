'use strict';

const { DMSController } = require('./controllers');

const dmsController = DMSController.getInstance();

module.exports = (router) => {
    router.post('/get-document-details', (req, res) => dmsController.getDocumentDetails(req, res));
    router.post('/upload-document', (req, res) => dmsController.uploadDocument(req, res));
}