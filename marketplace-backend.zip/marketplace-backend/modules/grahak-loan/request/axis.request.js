'use strict';

const config = require('config');
const { AxiosService } = require('@request');
const { LoggerFactory } = require('@logger');

class AxisRequest {

    constructor() {
        this.axiosService = AxiosService.getInstance();
        this.axisConfig = config.get('axis');
        this.logger = LoggerFactory.getLogger(AxisRequest.name);
    }

    /**
     * Make a new instance of AxisRequest
     * @returns {AxisRequest}
     */
    static make() {
        return new AxisRequest();
    }

    /**
     * Get Axis serviceable products
     * @param {Object} payload - The payload for the request
     * @returns {Promise<Object>} - The response from the request
     */
    async getAxisServiceableProducts(payload) {
        try {
            const { host, port, protocol, endpoints, headers } = this.axisConfig;

            const config = {
                host,
                port,
                protocol,
                headers: { ...headers, clientId: payload?.clientId },
                method: endpoints.serviceable_product.method || 'POST',
                url: endpoints.serviceable_product.url,
            };

            return await this.axiosService.handle(config, payload, payload?.clientId, '', '', { skipAmsLogging: true });
        } catch (error) {
            this.logger.error({ ref: 'getAxisServiceableProducts', error });
            throw error;
        }
    }

    /**
     * Get Axis serviceable applications
     * @param {Object} payload - The payload for the request
     * @returns {Promise<Object>} - The response from the request
     */
    async getAxisServiceableApplications(payload) {
        try {
            const { host, port, protocol, endpoints, headers } = this.axisConfig;

            const config = {
                host,
                port,
                protocol,
                headers: { ...headers, clientId: payload?.clientId },
                method: endpoints.serviceable_applications.method || 'POST',
                url: `${endpoints.serviceable_applications.url}?is_cdn=true`,
            };

            return await this.axiosService.handle(config, payload, payload?.clientId, '', '', { skipAmsLogging: true });
        } catch (error) {
            this.logger.error({ ref: 'getAxisServiceableApplications', error });
            throw error;
        }
    }
}

module.exports = { AxisRequest };