const { LoggerFactory } = require('@logger');
const { getItem, setItem } = require('@utils');
const GrahakLoanStaticDataModel = require('@odm/models/grahakLoan');
const { AxisRequest } = require('../request/axis.request');
const { CACHE_KEYS } = require('@utils');

class GrahakLoanService {
    static instance = null;

    constructor() {
        this.logger = LoggerFactory.getLogger(GrahakLoanService.name);
        this.axisRequest = AxisRequest.make();
    }

    /**
     * Get the instance of the GrahakLoanService
     * @returns {GrahakLoanService}
     */
    static getInstance() {
        if (!GrahakLoanService.instance) {
            GrahakLoanService.instance = new GrahakLoanService();
        }
        return GrahakLoanService.instance;
    }

    /**
     * Get the axis products for a given clientId
     * @param {string} clientId - The clientId
     * @returns {Promise<Object>} - The axis products
     */
    async getAxisProducts(clientId) {
        let data = await getItem(CACHE_KEYS.AXIS_LOAN_CENTER);
        if (data) return JSON.parse(data);

        const response = await this.axisRequest.getAxisServiceableApplications({ clientId });
        if (response.status === false) {
            this.logger.error({ ref: 'getAxisProducts', error: response.message });
            throw new Error(response.message);
        }
        data = response.resp.data;

        await setItem(CACHE_KEYS.AXIS_LOAN_CENTER, JSON.stringify(data));
        return data;
    }

    /**
     * Get the loan center dashboard data
     * @returns {Promise<Object>} - The loan center dashboard data
     */
    async getLoanCenterDashBoardData() {
        let data = await getItem(CACHE_KEYS.LOAN_CENTER_DASHBOARD);
        if (data) return JSON.parse(data);

        data = await GrahakLoanStaticDataModel.aggregate([
            { $match: {} },
            {
                $addFields: {
                    grahakServices: {
                        $filter: {
                            input: "$grahakServices",
                            as: "service",
                            cond: { $eq: ["$$service.isActive", true] }
                        }
                    }
                }
            },
            { $limit: 1 }
        ]);

        data = data && data.length ? data[0] : {};
        await setItem(CACHE_KEYS.LOAN_CENTER_DASHBOARD, JSON.stringify(data));
        return data;
    }

    /**
     * Calculate the sum of amounts from the history response
     * @param {Array} historyResp - The history response
     * @returns {number} - The sum of amounts
     */
    calculateSumOfAmounts(historyResp) {
        let sum = 0;
        try {
            for (const hist of historyResp) {
                const amount = hist.adhikariEarning;
                if (amount === undefined || amount === '' || isNaN(Number(amount))) {
                    continue;
                }
                sum += Number(amount);
            }
            return sum;
        } catch (error) {
            this.logger.error({ ref: 'calculate sum of amounts exception', error });
            return error;
        }
    }
}

module.exports = { GrahakLoanService };