const { GrahakLoanService } = require('./grahak-loan.service');

module.exports = {
    GrahakLoanService,
};