const { GrahakLoanController, EarningController, CreditScoreController, AmsLogController, HistoryController } = require('./controllers');

const grahakLoanController = GrahakLoanController.getInstance();
const earningController = EarningController.getInstance();
const creditScoreController = CreditScoreController.getInstance();
const amsLogController = AmsLogController.getInstance();
const historyController = HistoryController.getInstance();
module.exports = (router) => {

    // Grahak Loan Routes
    router.get('/removeCache', grahakLoanController.removeCacheData.bind(grahakLoanController));  // need to confirm - Vishant
    router.get('/commissiondetails', grahakLoanController.commissionDetails.bind(grahakLoanController));
    router.get('/dashboard', grahakLoanController.grahakLoanDashboardDetails.bind(grahakLoanController));
    // router.post('/createdashboarddetails', grahakLoanController.createGrahakLoanDashboardDetails.bind(grahakLoanController));
    // router.post('/updatedashboarddetails', grahakLoanController.updateGrahakLoanDashboardDetails.bind(grahakLoanController));

    // Earning Routes
    router.get('/earning', earningController.getClientOverAllEarnings.bind(earningController));
    router.get('/earningcommissioncounts', earningController.getEarningCommissionsCount.bind(earningController));
    router.get('/filteredearningcommission', earningController.getFilteredCommisionDetails.bind(earningController));

    // Credit Score Routes
    router.get('/creditscorestaticdetails', creditScoreController.creditScoreStaticDetails.bind(creditScoreController)); // need to confirm - Muheeb

    // AMS Log Routes
    router.post('/getamsdetails', amsLogController.amsLogsDetails.bind(amsLogController)); // need to confirm - Vishant

    // History Routes
    router.post('/history', historyController.historyDetails.bind(historyController));
    router.post('/lenderhistorydetails', historyController.lenderHistoryDetails.bind(historyController)); // need to confirm - ANkit

};