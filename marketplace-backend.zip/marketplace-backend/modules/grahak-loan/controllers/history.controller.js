'use strict';

const mo = require("moment");
const xlsx = require('xlsx');
const shortid = require('shortid');
const { Op } = require('sequelize');

const HistoryModel = require("@odm/models/history");
const { marketPlaceSqModels } = require("@orm");

const { LoggerFactory } = require('@logger');
const { LENDER_LOGOS, kebabToScreamingSnake } = require('@utils');

class HistoryController {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(HistoryController.name);
    this.leads = marketPlaceSqModels.Leads;
  }

  /**
   * Get the singleton instance of the HistoryController
   * @returns {HistoryController}
   */
  static getInstance() {
    if (!HistoryController.instance) {
      HistoryController.instance = new HistoryController();
    }
    return HistoryController.instance;
  }

  async historyDetails(req, res) {
    try {
      const filter = {};
      const defaultFilter = {};
      const leadFilters = {};
      if (req.body.clientId) {
        filter.clientId = req.body.clientId;
        defaultFilter.clientId = req.body.clientId;
      }
      if (!req.body.clientId) {
        return res.sendWrapped("clientId is required", null);
      }
      if (req.body.fromDate && !req.body.toDate) {
        return res.sendWrapped("toDate is required", null);
      }
      if (req.body.fromDate) {
        filter.applicationCreatedDate = {
          $gte: mo(req.body.fromDate).startOf('day').format('YYYY-MM-DD HH:mm:ss'),
          $lte: mo(req.body.toDate).set({ hour: 23, minute: 59, second: 59 }).format('YYYY-MM-DD HH:mm:ss')
        };
      }
      if (req.body.status) {
        filter.transactionStatus = { $in: req.body.status }
      }

      if (req.body.mobileNumber) {
        const regexPattern = new RegExp(`\\d*${req.body.mobileNumber}\\d*`);
        filter.mobileNumber = {
          $regex: regexPattern
        }
      }

      if (req.body.customerName) {
        filter.customerName = req.body.customerName;
      }
      if (req.body.grahakId) {
        filter.grahikId = req.body.grahakId; // What will be the grahikId??
      }

      const resp = await HistoryModel.find(defaultFilter);
      const leadResp = await this.leads.findAll({
        attributes: [
          ['sma_id', 'clientId'],
          "lead_id",
          "mobile",
          "pan",
          "pincode",
          "email",
          "lead_comment",
          "partner_lead_id",
          "lead_status",
          "alternate_mobile",
          "first_name",
          "last_name",
          "branchcode",
          "remarks",
          "agent_name",
          "lead_type",
          "otp_verified",
          "otp_id",
          "product",
          "created_at",
          "updated_at"],
        where: {
          sma_id: req.body.clientId,
        },
        order: [['created_at', 'DESC']],
      });
      const finalRespArr = [];
      if (resp.length) {
        resp.forEach(ele => {
          const finalRespObj = {
            clientId: ele.customerid,
            loanId: ele.loanId,
            customerid: ele.customerid,
            customerName: ele.customerName,
            mobileNumber: ele.mobileNumber,
            lender: ele.lender,
            transactionStatus: ele.transactionStatus,
            commissionEarned: ele.adhikariEarning,
            loanTenure: ele.loanTenure,
            transactionId: ele.loanId,
            PAN: ele.PAN,
            messageText: ele.messageText,
            DisbursedAmt: ele.DisbursedAmt,
            adhikariEarning: ele.adhikariEarning,
            applicationCreatedDate: ele.applicationCreatedDate
          }
          finalRespArr.push(finalRespObj)
        });
      }

      const statusValue = [];
      const mobileNoValue = [];
      const customerValue = [];
      const partnerLeadValue = [];
      if (finalRespArr.length) {
        finalRespArr.forEach((finalResp) => {
          statusValue.push(finalResp.transactionStatus)
          mobileNoValue.push(finalResp.mobileNumber)
          customerValue.push(finalResp.customerName)
        });
      }

      if (leadResp.length) {
        leadResp.forEach((finalRes) => {
          statusValue.push(finalRes.lead_status)
          mobileNoValue.push(finalRes.mobile)
          const customerName = `${finalRes.first_name} ${finalRes.last_name}`;
          partnerLeadValue.push(finalRes.partner_lead_id);
          customerValue.push(customerName)
        });
      }

      const finalRespObj = {
        history_filters: {
          transaction_status: {
            filter_name: "Status",
            filter_values: [...new Set(statusValue)]
          },
          mobile_number: {
            filter_name: "Mobile Number",
            filter_values: [...new Set(mobileNoValue)]
          },
          customer_name: {
            filter_name: "Customer Name",
            filter_values: [...new Set(customerValue)]
          },
          partner_lead_id: {
            filter_name: "Partner Lead ID",
            filter_values: [...new Set(partnerLeadValue)]
          }
        },
      }
      if (filter) {
        const filteredResp = await HistoryModel.aggregate([
          {
            $match: filter
          }
        ]);
        if (req.body.customerName) {
          const splitCustomerName = req.body.customerName.split(" ");
          leadFilters.first_name = splitCustomerName[0];
          leadFilters.last_name = splitCustomerName[1];
        }
        if (req.body.clientId) {
          leadFilters.sma_id = req.body.clientId;
        }

        if (req.body.fromDate) {
          leadFilters.created_at = {
            [Op.between]: [
              mo(req.body.fromDate).startOf('day').format('YYYY-MM-DD HH:mm:ss'),
              mo(req.body.toDate).set({ hour: 23, minute: 59, second: 59 }).format('YYYY-MM-DD HH:mm:ss')
            ],
          };
        }
        if (req.body.status) {
          leadFilters.lead_status = {
            [Op.in]: req.body.status
          };
        }
        if (req.body.mobileNumber) {
          leadFilters.mobile = {
            [Op.like]: `%${req.body.mobileNumber}%`
          };
        }
        const leadResponse = await this.leads.findAll({
          attributes: [['sma_id', 'clientId'], "lead_id", "mobile", "pan", "pincode", "email", "lead_comment", "partner_lead_id", "lead_status", "alternate_mobile", "first_name", "last_name", "branchcode", "remarks", "agent_name", "lead_type", "otp_verified", "otp_id", "product", "created_at", "updated_at"],
          where: {...leadFilters, partner_lead_id: {
            [Op.ne]: null
          }},
          order: [['created_at', 'DESC']],
        });

        const filteredFinalRespArr = [];
        if (filteredResp && filteredResp.length) {
          filteredResp.forEach(ele => {
            const filteredfinalRespObj = {
              clientId: ele.clientId,
              loanId: ele.loanId,
              customerid: ele.customerid,
              customerName: ele.customerName,
              mobileNumber: ele.mobileNumber,
              lender: ele.lender,
              transactionStatus: ele.transactionStatus,
              commissionEarned: ele.adhikariEarning,
              loanAmount: ele.loanAmount,
              interestRate: ele.interestRate,
              loanTenure: ele.loanTenure,
              transactionId: ele.loanId,
              PAN: ele.PAN,
              messageText: ele.messageText,
              DisbursedAmt: ele.DisbursedAmt,
              adhikariEarning: ele.adhikariEarning,
              applicationCreatedDate: ele.applicationCreatedDate,
            }
            filteredFinalRespArr.push(filteredfinalRespObj)
          });
        }
        if (leadResponse?.length) {
          const smCategoryObj = leadResponse.map(obj => {
            const lenderLogo = LENDER_LOGOS[kebabToScreamingSnake(obj.product)];
            if (obj.product && lenderLogo) {
              return { ...obj, smCategory: obj.product, logo: lenderLogo };
            } else {
              return { ...obj, smCategory: "NA", logo: LENDER_LOGOS.DEFAULT_LOGO };
            }
          });

          filteredFinalRespArr.push(...smCategoryObj);
        }
        finalRespObj.history_result = filteredFinalRespArr;
      }
      return res.sendWrapped(null, finalRespObj);
    } catch (err) {
      this.logger.error({ ref: 'historyDetails Exception', error: err });
      return res.status(500).json({ message: err });
    }
  }

  async lenderHistoryDetails(req, res) {
    try {
      try {
        if (!req.files) {
          return res.status(400).send("No files were uploaded.");
        }
        const readOpts = { // <--- need these settings in readFile options
          cellText: false,
          cellDates: true
        };
        const jsonOpts = {
          header: 1,
          defval: '',
          blankrows: true,
          raw: false,
          // dateNF: 'd"/"m"/"yyyy' // <--- need dateNF in sheet_to_json options (note the escape chars)
        }
        const file = req.files.excelFile.data;
        const workbook = xlsx.read(file, { type: 'buffer' }, readOpts);
        const sheetName = workbook.SheetNames[0]; // Assuming the data is on the first sheet
        const worksheet = workbook.Sheets[sheetName];
        const data = xlsx.utils.sheet_to_json(worksheet, jsonOpts);
        // If the first row contains headers, you can use the following line to create an array of objects with key-value pairs
        const headers = data.shift();
        const jsonArr = data.map(row => {
          const obj = {};
          headers.forEach((header, index) => {
            obj[header] = row[index];
          });
          return obj;
        });

        try {
          Promise.all(
            jsonArr.map(async (details) => {
              if (details.customer_id) {
                let lendorLoanRecords;
                if (details['Lender Loan ID']) {
                  lendorLoanRecords = await HistoryModel.findOne({ lendorLoanRecord: details['Lender Loan ID'] });
                }

                if (lendorLoanRecords && lendorLoanRecords.lendorLoanRecord) {
                  const updateObj = {
                    loanId: details.loanId ? details.loanId : lendorLoanRecords.loanId,
                    lendorLoanRecord: details['Lender Loan ID'] ? details['Lender Loan ID'] : lendorLoanRecords.lendorLoanRecord,
                    clientId: details?.customer_id ? details?.customer_id : lendorLoanRecords?.customer_id,
                    customerid: details?.customer_id ? details?.customer_id : lendorLoanRecords?.customer_id,
                    customerName: details?.customer_name ? details?.customer_name : lendorLoanRecords?.customer_name,
                    lender: details?.Lender ? details?.Lender : lendorLoanRecords?.lender,
                    mobileNumber: details?.mobile_no ? details?.mobile_no : lendorLoanRecords.mobileNumber,
                    PAN: details?.PAN ? details?.PAN : lendorLoanRecords?.PAN,
                    transactionStatus: details?.Status ? details?.Status : lendorLoanRecords?.transactionStatus,
                    messageText: details['Message text to be shown'] ? details['Message text to be shown'] : lendorLoanRecords.messageText,
                    loanAmount: details['Loan Amount'] ? details['Loan Amount'] : lendorLoanRecords.loanAmount,
                    DisbursedAmt: details?.Disbursed_Amt ? details?.Disbursed_Amt : lendorLoanRecords.DisbursedAmt,
                    adhikariEarning: details['Adhikari Earning'] ? details['Adhikari Earning'] : lendorLoanRecords.adhikariEarning,
                    applicationCreatedDate: details?.application_created_date ? details?.application_created_date : lendorLoanRecords?.applicationCreatedDate,
                    payoutDate: details['Payout Date'] ? details['Payout Date'] : lendorLoanRecords.payoutDate,
                    fileInfo: req.files.excelFile.name + new Date().toISOString(),
                    updated_at: new Date().toISOString(),
                  }
                  const update = { $set: updateObj };
                  const filter = { lendorLoanRecord: details['Lender Loan ID'] };
                  await HistoryModel.updateOne(filter, update);
                } else {
                  const randomID = shortid.generate().slice(0, 6);
                  const loanId = "SM" + randomID;
                  const lendorDetailsObj = {
                    loanId,
                    lendorLoanRecord: details['Lender Loan ID'] || null,
                    clientId: details?.customer_id || null,
                    customerid: details?.customer_id || null,
                    customerName: details?.customer_name || null,
                    lender: details?.Lender || null,
                    mobileNumber: details?.mobile_no || null,
                    PAN: details?.PAN || null,
                    transactionStatus: details?.Status || null,
                    messageText: details['Message text to be shown'] || null,
                    loanAmount: details['Loan Amount'] || null,
                    DisbursedAmt: details?.Disbursed_Amt || null,
                    adhikariEarning: details['Adhikari Earning'] || null,
                    applicationCreatedDate: details?.application_created_date,
                    created_at: new Date().toISOString(),
                    fileInfo: req.files.excelFile.name + new Date().toISOString()
                  }
                  this.logger.info({ ref: 'lenderHistoryDetails lendorDetailsObj created', data: lendorDetailsObj });
                  return await HistoryModel.create(lendorDetailsObj);
                }
              }
            }));
        } catch (err) {
          this.logger.info({ ref: 'Error reading the file exception', error: err });
          res.status(500).json({ "error": 'Error reading the file' });
        }

        return res.sendWrapped(null, 'Data uploaded successfully');
      } catch (err) {
        this.logger.info({ ref: 'Error reading the file exception', error: err });
        res.status(500).json({ "error": 'Error reading the file' });
      }
    } catch (err) {
      this.logger.info({ ref: 'lenderHistoryDetails exception', error: err });
      return res.status(500).json({ message: err });
    }
  };
}

module.exports = { HistoryController };