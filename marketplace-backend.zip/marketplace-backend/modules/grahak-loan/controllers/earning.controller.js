const mo = require("moment");
const HistoryModel = require("@odm/models/history");
const { LoggerFactory } = require('@logger');
const { EARNINGS_FILTER } = require('@utils');

class EarningController {

  constructor() {
    this.logger = LoggerFactory.getLogger(EarningController.name);
  }

  /**
   * Get the singleton instance of the EarningController
   * @returns {EarningController}
   */
  static getInstance() {
    if (!EarningController.instance) {
      EarningController.instance = new EarningController();
    }
    return EarningController.instance;
  }

  /**
   * Get the earning commissions count
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async getEarningCommissionsCount(req, res) {
    try {
      const { clientId, search } = req.query;
      if (!clientId) {
        return res.sendWrapped("ClientId is required");
      }
      let start = mo(),
        end = mo();
      let title = "This month earnings";
      switch (search) {
        case EARNINGS_FILTER.LAST_MONTH:
          start = start.subtract(1, "month").startOf("month");
          end = end.subtract(1, "month").endOf("month");
          title = "Last month earnings";
          break;
        case EARNINGS_FILTER.LAST_SIX_MONTH:
          start = start.subtract(6, "month").startOf("month");
          end = end.subtract(1, "month").endOf("month");
          title = "Last six months earnings";
          break;
        default:
          start = start.subtract(1, "month");
          end = end;
          break;
      }

      /** Retrieve the data based on filter */
      const earnings = await HistoryModel.aggregate([
        {
          $project: {
            year: { $substr: ["$applicationCreatedDate", 0, 4] },
            month: { $substr: ["$applicationCreatedDate", 5, 2] },
            day: { $substr: ["$applicationCreatedDate", 8, 2] },
            adhikariEarning: 1,
            clientId: 1,
          },
        },
        {
          $project: {
            adhikariEarning: 1,
            clientId: 1,
            applicationCreatedDate: {
              $dateFromString: {
                dateString: { $concat: ["$year", "-", "$month", "-", "$day"] },
              },
            },
          },
        },
        {
          $match: {
            clientId,
            applicationCreatedDate: {
              $gte: new Date(start.startOf("day")),
              $lte: new Date(end.endOf("day")),
            },
          },
        },
      ]);

      /** Response */
      let totalEarnings = 0;
      let totalLoanApplied = 0;
      earnings.map((earning) => {
        const adhikariEarning = !isNaN(Number(earning?.adhikariEarning))
          ? Number(earning.adhikariEarning)
          : 0;
        totalEarnings += adhikariEarning;
        totalLoanApplied += 1;
      });
      const response = {
        title: "Total Earnings (₹)",
        filters: Object.values(EARNINGS_FILTER),
        earnings: {
          title,
          type: "currency",
          value: totalEarnings,
        },
        loanApplied: {
          title: "Total loan applied",
          type: "numeric",
          value: totalLoanApplied,
        },
      };
      this.logger.info({ ref: "getEarningCommissionsCount response", data: response });
      return res.sendWrapped(null, response);
    } catch (error) {
      this.logger.error({ ref: "Error in getEarningCommissionsCount", error });
      return res.sendWrapped(error);
    }
  };

  async getClientOverAllEarnings(req, res) {
    const clientId = req.query?.clientId;
    if (!clientId) {
      return res.sendWrapped("Client Id is required");
    }

    /** Response format */
    const response = {
      casesSubmitted: {
        title: "Cases Submitted",
        type: "numeric",
        value: 0,
      },
      disbursedCases: {
        title: "Disbursed Cases",
        type: "numeric",
        value: 0,
      },
      commissionEarned: {
        title: "Commission Earned",
        type: "currency",
        value: 0,
      },
      commissionPending: {
        title: "Commission Pending",
        type: "currency",
        value: 0,
      },
      chartDetails: {
        config: [0, 10, 20, 30, 40, 50],
        earnings: [],
      },
    };
    try {
      /** Retrieve all the records of client */
      const clientEarningsRaw = await HistoryModel.aggregate([
        { $match: { clientId } },
        {
          $project: {
            applicationCreatedDate: {
              $substr: ["$applicationCreatedDate", 0, 10],
            },
            adhikariEarning: 1,
            transactionStatus: 1,
            payoutDate: 1,
          },
        },
      ]);

      /** Manipulate the data */
      response.casesSubmitted.value = clientEarningsRaw.length;
      const everyDayEarnings = {};
      clientEarningsRaw.map((earning) => {
        /** Total Commission */
        const adhikariEarning = !isNaN(Number(earning?.adhikariEarning))
          ? Number(earning.adhikariEarning)
          : 0;

        /** Commission pending sum */
        if (!earning.payoutDate) {
          response.commissionPending.value += adhikariEarning;
        } else {
          response.disbursedCases.value += 1;
          response.commissionEarned.value += adhikariEarning;
        }

        /** Earnings based on day */
        everyDayEarnings[earning.applicationCreatedDate] =
          (everyDayEarnings[earning.applicationCreatedDate] || 0) +
          adhikariEarning;
      });

      /** Earnigs by day for Chart */
      const earningsRecords = Object.keys(everyDayEarnings);
      const dates = earningsRecords.sort((a, b) => a.localeCompare(b));
      for (let i = 0; i < dates.slice(0, 7).length; i++) {
        response.chartDetails.earnings.push({
          date: mo(dates[i]).format("D MMM"),
          totalEarnings: everyDayEarnings[dates[i]] || 0,
        });
      }
      this.logger.info({ ref: "getClientOverAllEarnings response", data: response });
      return res.sendWrapped(null, response);
    } catch (error) {
      this.logger.error({ ref: "Error in getClientOverAllEarnings", error });
      return res.sendWrapped(error);
    }
  };

  async getFilteredCommisionDetails(req, res) {
    try {
      if (req.query && !req.query.clientId) {
        return res.sendWrapped("clientId is required", null);
      }
      const filter = {
        clientId: req.query.clientId,
      };
      if (req.query.filter && req.query.filter.toLowerCase() === "earned") {
        filter.payoutDate = { $ne: null, $exists: true };
      }
      if (req.query.filter && req.query.filter.toLowerCase() === "pending") {
        filter.payoutDate = { $eq: null, $exists: false };
      }
      const historyResp = await HistoryModel.find(filter);
      if (historyResp && !historyResp.length) {
        return res.sendWrapped("Data not available", null);
      }
      const finalRespArr = [];
      historyResp.forEach((hist) => {
        const finalRespObj = {
          loanId: hist.loanId,
          applicationCreatedDate: hist.applicationCreatedDate,
          lender: hist.lender,
          customerName: hist.customerName,
          mobileNumber: hist.mobileNumber,
          loanAmount: hist.loanAmount,
          commissionEarned: hist.adhikariEarning,
          status: hist?.payoutDate ? "Earned" : "Pending",
        };
        finalRespArr.push(finalRespObj);
      });
      this.logger.info({ ref: "getFilteredCommisionDetails response", data: finalRespArr });
      return res.sendWrapped(null, finalRespArr);
    } catch (error) {
      this.logger.error({ ref: "Error in getFilteredCommisionDetails", error });
      return res.sendWrapped(error);
    }
  };
}

module.exports = { EarningController };
