'use strict';

const { LoggerFactory } = require('@logger');
const CreditScoreStaticDataModel = require('@odm/models/creditScoreStatic');

class CreditScoreController {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(CreditScoreController.name);
  }

  /**
   * Get the singleton instance of the CreditScoreController
   * @returns {CreditScoreController}
   */
  static getInstance() {
    if (!CreditScoreController.instance) {
      CreditScoreController.instance = new CreditScoreController();
    }
    return CreditScoreController.instance;
  }

  /**
   * Get the credit score static details
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async creditScoreStaticDetails(req, res) {
    try {
      const result = await CreditScoreStaticDataModel.findOne().lean();
      return res.sendWrapped(null, { ...result });
    } catch (error) {
      this.logger.error({ ref: 'credit score static details error', error });
      return res.sendWrapped(error);
    }
  };
}

module.exports = { CreditScoreController };
