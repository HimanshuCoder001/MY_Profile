const { GrahakLoanController } = require('./grahak-loan.controller');
const { EarningController } = require('./earning.controller');
const { CreditScoreController } = require('./credit-score.controller');
const { AmsLogController } = require('./ams-log.controller');
const { HistoryController } = require('./history.controller');

module.exports = {
    GrahakLoanController,
    EarningController,
    CreditScoreController,
    AmsLogController,
    HistoryController
}