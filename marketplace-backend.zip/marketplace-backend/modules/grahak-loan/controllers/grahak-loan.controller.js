const GrahakLoanStaticDataModel = require('@odm/models/grahakLoan');
const HistoryModel = require('@odm/models/history');
const { AxisRequest } = require('../request/axis.request');
const { FAQ_DATA, AXIS_GRAHAK_SERVICES, CACHE_KEYS, removeCache } = require('@utils');
const { marketPlaceSqModels } = require("@orm");
const { GrahakLoanService } = require('../services');
const { LoggerFactory } = require('@logger');

class GrahakLoanController {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(GrahakLoanController.name);
    this.grahakLoanService = GrahakLoanService.getInstance();
    this.axisRequest = AxisRequest.make();
    this.serviceableClients = marketPlaceSqModels.ServiceableClients;
  }

  /**
   * Get the singleton instance of the GrahakLoanController
   * @returns {GrahakLoanController}
   */
  static getInstance() {
    if (!GrahakLoanController.instance) {
      GrahakLoanController.instance = new GrahakLoanController();
    }
    return GrahakLoanController.instance;
  }

  /**
   * Create the grahak loan dashboard details
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async createGrahakLoanDashboardDetails(req, res) {
    try {
      this.logger.info({ ref: 'create grahak loan dashboard details request', data: req.body });
      const isAlreadyExist = await GrahakLoanStaticDataModel.findOne({});

      if (isAlreadyExist) {
        this.logger.info({ ref: 'dashboard details is already exist' });
        return res.sendWrapped('Dashboard details is already exist');
      }

      const resp = await GrahakLoanStaticDataModel.create(req.body);
      this.logger.info({ ref: 'create grahak loan dashboard details response', data: resp });
      return res.sendWrapped(null, { ...resp });
    } catch (error) {
      this.logger.error({ ref: 'create grahak loan dashboard details exception', error });
      return res.sendWrapped(error);
    }
  }

  async updateGrahakLoanDashboardDetails(req, res) {
    try {
      this.logger.info({ ref: 'update grahak loan dashboard details request', data: req.body });
      const isExist = await GrahakLoanStaticDataModel.findOne().lean();
      
      if (!isExist) {
        this.logger.info({ ref: 'grahak loan details does not exist' });
        return res.sendWrapped('Grahak loan details does not exist!');
      }

      const resp = await GrahakLoanStaticDataModel.findByIdAndUpdate(
        isExist._id,
        {
          ...isExist,
          ...req.body,
        },
        { new: true },
      );
      this.logger.info({ ref: 'update grahak loan dashboard details response', data: resp });
      return res.sendWrapped(null, resp);
    } catch (error) {
      this.logger.error({ ref: 'update grahak loan dashboard details exception', error });
      return res.sendWrapped(error);
    }
  }

  async grahakLoanDashboardDetails(req, res) {
    this.logger.info({ ref: 'grahak loan dashboard details request', data: req.body });
    const { headers } = req;
    const { clientid: clientId } = headers;
    try {
      const [resp, axisLoanDetails, axisProducts] = await Promise.all([
        this.grahakLoanService.getLoanCenterDashBoardData(),
        this.axisRequest.getAxisServiceableProducts({ clientId }),
        this.grahakLoanService.getAxisProducts('1260388')]);
      if (resp && resp.hasOwnProperty('_id')) {
        delete resp._id;
      }

      this.logger.info({ ref: 'grahak loan dashboard details response', data: resp });
      this.logger.info({ ref: 'grahak loan dashboard details axisLoanDetails', data: axisLoanDetails });
      this.logger.info({ ref: 'grahak loan dashboard details axisProducts', data: axisProducts });

      if (axisLoanDetails?.status === true && axisLoanDetails?.resp?.data && axisProducts?.length > 0) {
        let serviceableProducts = axisLoanDetails.resp.data;
        let filteredAxisProducts = axisProducts.filter((item) => {
          item.redirection_type = 'FORMCONFIG';
          if (item.loan_type == 'gold-loan') {
            item.redirection_type = 'GOLDLOAN';
          }
          if (item.loan_type == 'two-wheeler') {
            item.additionalDetails = resp?.twoWheelerLoanDetails;
            item.redirection_type = 'TWOWHEELER';
          }
          const matchingService = AXIS_GRAHAK_SERVICES.find((items) => items.loanType.toLowerCase() === item.loan_type.toLowerCase());
          this.logger.info({ ref: 'grahak loan dashboard details matchingService', data: matchingService });
          item.title = item.loan_type_name;
          delete item.loan_type_name;
          if (matchingService) {
            item.index = matchingService.index;
            if (matchingService.redirection_url) {
              item.redirection_url = matchingService.redirection_url;
            }
            if (matchingService.tag) {
              item.tag = matchingService.tag;
            }
            if (matchingService.title) {
              item.title = matchingService.title;
            }
          }
          item.index = parseInt(item.index);
          if (serviceableProducts[item.loan_type.replace(/-/g, '')] && matchingService.status) {
            return item;
          }
        });

        //remove the MICROLAP tile for all the user
        resp.grahakServices = resp.grahakServices.filter(
          service => service.redirection_type !== "MICROLAP"
        );

        resp.grahakServices = [...resp.grahakServices, ...filteredAxisProducts];
      }
      if (FAQ_DATA.length) {
        this.logger.info({ ref: 'faqs updated' });
        resp.faqs = FAQ_DATA;
      }
      this.logger.info({ ref: 'grahak loan dashboard details end' });
      return res.sendWrapped(null, { ...resp });
    } catch (error) {
      this.logger.error({ ref: 'grahak loan dashboard details exception', error });
      return res.sendWrapped(error);
    }
  }

  async commissionDetails(req, res) {
    try {
      this.logger.info({ ref: 'commission details request', data: req.body });
      if (req.query && !req.query.clientId) {
        return res.sendWrapped('clientId is required', null);
      }

      const filter = {
        clientId: req.query.clientId,
      };

      const historyResp = await HistoryModel.find(filter);

      if (historyResp && !historyResp.length) {
        this.logger.info({ ref: 'commission details data not available' });
        return res.sendWrapped('Data not available', null);
      }
      const commissionEarned = {};
      const sumOfCommisionEarned = this.grahakLoanService.calculateSumOfAmounts(historyResp);

      if (historyResp && historyResp.length) {
        commissionEarned.earned = {
          title: 'Commission earned',
          value: sumOfCommisionEarned,
          growth: {
            daily: '',
            monthly: '',
          },
        },
          commissionEarned.loan_applied = {
            title: 'Total loan applied',
            value: historyResp.length,
            growth: {
              daily: '',
              monthly: '',
            },
          };
      }
      this.logger.info({ ref: 'commission details response', data: commissionEarned });
      return res.sendWrapped(null, { commissions: commissionEarned });
    } catch (error) {
      this.logger.error({ ref: 'commission details exception', error });
      return res.sendWrapped(error);
    }
  }

  async removeCacheData(req, res) {
    try {
      const key = CACHE_KEYS[req?.query?.cache];
      if (key) await removeCache(key);

      return res.sendWrapped(null, {}, 'Cache removed successfully');
    } catch (error) {
      this.logger.error({ ref: 'remove cache data exception', error });
      return res.sendWrapped(error);
    }
  };
}

module.exports = { GrahakLoanController };
