'use strict';

const { LoggerFactory } = require('@logger');
const AmsLogsModel = require("@odm/models/amsLogs");
const mo = require("moment");

class AmsLogController {
    static instance = null;

    constructor() {
        this.logger = LoggerFactory.getLogger(AmsLogController.name);
    }

    /**
     * Get the singleton instance of the AmsLogController
     * @returns {AmsLogController}
     */
    static getInstance() {
        if (!AmsLogController.instance) {
            AmsLogController.instance = new AmsLogController();
        }
        return AmsLogController.instance;
    }

    /**
     * Get the AMS logs details
     * @param {Object} req - The request object
     * @param {Object} res - The response object
     * @returns {Promise<Object>} - The response object
     */
    async amsLogsDetails(req, res) {
        try {
            const { clientId, fromDate, toDate } = req.body;
            const filter = {};

            if (clientId) {
                filter.clientId = clientId;
            }

            if (fromDate && toDate) {
                filter.timestamp = {
                    $gte: new Date(fromDate),
                    $lte: new Date(toDate)
                };
            } else if (!clientId) {
                const today = mo().startOf('day');
                filter.timestamp = {
                    $gte: today.toDate()
                };
            }

            const options = {
                sort: { timestamp: -1 },
                limit: 1000
            };

            const resp = await AmsLogsModel.find(filter, null, options);

            this.logger.info(`AMS logs query executed`, {
                filter,
                resultCount: resp.length,
                clientId: clientId || 'none'
            });

            return res.sendWrapped(null, resp);
        } catch (error) {
            this.logger.error('Error fetching AMS logs', {
                error: error.message,
                stack: error.stack,
                body: req.body
            });

            return res.sendWrapped('Failed to fetch AMS logs', null, 500);
        }
    }
}

module.exports = { AmsLogController };