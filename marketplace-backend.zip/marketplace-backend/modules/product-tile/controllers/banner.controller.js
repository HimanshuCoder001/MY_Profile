'use strict';

const { LoggerFactory } = require('@logger');
const { BannerService } = require('../services');

class BannerController {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(BannerController.name);
    this.bannerService = BannerService.getInstance();
  }

  /**
   * Get instance of BannerController
   * @returns {BannerController} - Instance of BannerController
   */
  static getInstance() {
    if (!BannerController.instance) {
      BannerController.instance = new BannerController();
    }
    return BannerController.instance;
  }
  
  /**
   * Get product banners by product ID
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async getBannersByProductId(req, res) {
    try {
      const { productId } = req.params;
      
      this.logger.info({ ref: 'getBannersByProductId request', productId });
      
      if (!productId) {
        return res.status(400).sendWrapped('Product ID is required');
      }

      // Get banners from service
      const banners = await this.bannerService.getProductBanners(productId);

      this.logger.info({ ref: 'getBannersByProductId response', productId, count: banners.length });
      return res.sendWrapped(null, banners);
    } catch (error) {
      this.logger.error({ ref: 'getBannersByProductId exception', productId: req.params.productId, error });
      return res.sendWrapped(error);
    }
  }
}

module.exports = { BannerController };