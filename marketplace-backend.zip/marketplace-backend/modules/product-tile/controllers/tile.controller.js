'use strict';

const { LoggerFactory } = require('@logger');
const { TileService } = require('../services');

class TileController {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(TileController.name);
    this.tileService = TileService.getInstance();
  }

  /**
   * Get the singleton instance of the TileController
   * @returns {TileController}
   */
  static getInstance() {
    if (!TileController.instance) {
      TileController.instance = new TileController();
    }
    return TileController.instance;
  }

  /**
   * Get product list with optional filters
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async getProductList(req, res) {
    try {
      const { type } = req.body;

      const products = await this.tileService.getProductList({ type });
      return res.sendWrapped(null, products);
    } catch (error) {
      this.logger.error({ ref: 'getProductList exception', error });
      return res.sendWrapped(error);
    }
  }

  /**
   * Get single product with details and banners
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async getProductById(req, res) {
    try {
      const { productId } = req.params;
      
      if (!productId) {
        return res.status(400).sendWrapped('Product ID is required');
      }

      const product = await this.tileService.getProductById(productId);
      return res.sendWrapped(null, product);
    } catch (error) {
      this.logger.error({ ref: 'getProductById exception', productId: req.params.productId, error });
      
      if (error.message === 'Product not found') {
        return res.status(404).sendWrapped('Product not found');
      }
      
      return res.sendWrapped(error);
    }
  }

}

module.exports = { TileController };
