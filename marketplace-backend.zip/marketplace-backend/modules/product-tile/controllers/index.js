'use strict';

const { TileController } = require('./tile.controller');
const { BannerController } = require('./banner.controller');
const { FormController } = require('./form.controller');

module.exports = {
  TileController,
  BannerController,
  FormController
};
