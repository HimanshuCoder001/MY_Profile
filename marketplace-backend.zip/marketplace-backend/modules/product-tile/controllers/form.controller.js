const { LoggerFactory } = require('@logger');
const { FormService } = require('../services');

class FormController {
    static instance = null;

    constructor() {
        this.logger = LoggerFactory.getLogger(FormController.name);
        this.formService = FormService.getInstance();
    }

    /**
     * Get instance of FormController
     * @returns {FormController} - Instance of FormController
     */
    static getInstance() {
        if (!FormController.instance) {
            FormController.instance = new FormController();
        }
        return FormController.instance;
    }

    /**
     * Get form by product id
     * @param {Object} req - The request object
     * @param {Object} res - The response object
     * @returns {Promise<Object>} - The response object
     */
    async getFormByProductId(req, res) {
        try {
            const { productId } = req.params;
            const { type, locale } = req.query;

            const form = await this.formService.getFormByProductId(productId, type, { locale });
            res.sendWrapped(null, form);
        } catch (error) {
            this.logger.error({ ref: 'get form by product id error', productId, error });
            res.sendWrapped(error);
        }
    }
}

module.exports = { FormController };