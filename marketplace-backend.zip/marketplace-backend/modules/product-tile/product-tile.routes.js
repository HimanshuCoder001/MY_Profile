'use strict';

const { TileController, BannerController, FormController } = require('./controllers');
const { ProductTileValidation } = require('./validations/product-tile.validation');

const tileController = TileController.getInstance();
const bannerController = BannerController.getInstance();
const formController = FormController.getInstance();

module.exports = (router) => {
    router.post('/list', ProductTileValidation.validateProductListSchema, tileController.getProductList.bind(tileController));
    router.get('/:productId', tileController.getProductById.bind(tileController));
    router.get('/:productId/banners', bannerController.getBannersByProductId.bind(bannerController));
    router.get('/:productId/form', ProductTileValidation.validateProductFormSchema, formController.getFormByProductId.bind(formController));
};
