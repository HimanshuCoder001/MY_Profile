const productListSchema = require('./product-list.schema.json');
const productFormSchema = require('./product-form.schema.json');

module.exports = {
  productListSchema,
  productFormSchema,
};