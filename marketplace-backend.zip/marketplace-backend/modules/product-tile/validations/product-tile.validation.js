'use strict';

const { ValidationUtil } = require('@utils');
const {
  productListSchema,
  productFormSchema,
} = require('./schemas');

class ProductTileValidation {
  /**
   * Validate product list schema using common validation utility
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   * @param {Function} next - Next middleware function
   * @returns {void}
   */
  static validateProductListSchema(req, res, next) {
    return ValidationUtil.validateSchema(req, res, next, productListSchema, {
      errorFormat: 'structured',
      logScope: 'ProductTileValidation'
    });
  }

  /**
   * Validate product form schema using common validation utility
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   * @param {Function} next - Next middleware function
   * @returns {void}
   */
  static validateProductFormSchema(req, res, next) {
    return ValidationUtil.validateSchema(req, res, next, productFormSchema, {
      errorFormat: 'structured',
      logScope: 'ProductTileValidation'
    });
  }
}

module.exports = { ProductTileValidation };