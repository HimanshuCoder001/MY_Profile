'use strict';

const { LoggerFactory } = require('@logger');
const { ProductsService } = require('@orm/services');
const { INSURANCE_SERVICES } = require('@utils');

class TileService {
    static instance = null;

    constructor() {
        this.logger = LoggerFactory.getLogger(TileService.name);
        this.productsService = ProductsService.getInstance();
    }

    /**
     * Get instance of TileService
     * @returns {TileService} - Instance of TileService
     */
    static getInstance() {
        if (!TileService.instance) {
            TileService.instance = new TileService();
        }
        return TileService.instance;
    }

    /**
     * Get product list with optional filters using common query functions
     * @param {Object} filters - Filter criteria
     * @param {string} filters.type - Product type filter
     * @param {string} filters.parentId - Parent product ID filter
     * @param {boolean} filters.isActive - Active status filter
     * @param {Object} options - Query options
     * @returns {Promise<Array>} - List of products
     */
    async getProductList(filters = {}, options = {}) {
        try {
            this.logger.info({ ref: 'get product list', filters, options });

            // Merge options with pagination
            const finalOptions = {
                ...options,
                nest: true,
                raw: false
            };

            // Use common list with includes function
            const products = await this.productsService.listWithIncludes(filters, finalOptions);
            this.logger.info({ ref: 'get product list success', count: products.length });

            return filters.type === 'insurance' ? { tiles: products, insuranceDetails: INSURANCE_SERVICES } : products;
        } catch (error) {
            this.logger.error({ ref: 'get product list error', error });
            throw error;
        }
    }

    /**
     * Get single product with details and banners using common query functions
     * @param {string} productId - Product ID
     * @returns {Promise<Object>} - Product with details and banners
     */
    async getProductById(productId) {
        try {
            this.logger.info({ ref: 'getProductById', productId });

            if (!productId) {
                throw new Error('Product ID is required');
            }

            // Use common getById with extended includes function
            const product = await this.productsService.getByIdWithExtendedIncludes(productId, {
                nest: true,
                raw: false,
            });

            if (!product) {
                throw new Error('Product not found');
            }

            this.logger.info({ ref: 'getProductById success', productId });
            return product;
        } catch (error) {
            this.logger.error({ ref: 'getProductById error', productId, error });
            throw error;
        }
    }

    /**
     * Get products by type using common query functions
     * @param {string} type - Product type
     * @param {Object} options - Query options
     * @returns {Promise<Array>} - List of products by type
     */
    async getProductsByType(type, options = {}) {
        try {
            this.logger.info({ ref: 'getProductsByType', type, options });

            if (!type) {
                throw new Error('Product type is required');
            }

            const filters = { type };
            return await this.getProductList(filters, options);
        } catch (error) {
            this.logger.error({ ref: 'getProductsByType error', type, error });
            throw error;
        }
    }

    /**
     * Get child products using common query functions
     * @param {string} parentId - Parent product ID
     * @param {Object} options - Query options
     * @returns {Promise<Array>} - List of child products
     */
    async getChildProducts(parentId, options = {}) {
        try {
            this.logger.info({ ref: 'getChildProducts', parentId, options });

            if (!parentId) {
                throw new Error('Parent product ID is required');
            }

            const filters = { parentId };
            return await this.getProductList(filters, options);
        } catch (error) {
            this.logger.error({ ref: 'getChildProducts error', parentId, error });
            throw error;
        }
    }

    /**
     * Search products with custom where clause using common query functions
     * @param {Object} whereClause - Custom where clause
     * @param {Object} options - Query options
     * @returns {Promise<Array>} - List of products matching search criteria
     */
    async searchProducts(whereClause = {}, options = {}) {
        try {
            this.logger.info({ ref: 'searchProducts', whereClause, options });

            return await this.productsService.listWithIncludes(whereClause, options);
        } catch (error) {
            this.logger.error({ ref: 'searchProducts error', whereClause, error });
            throw error;
        }
    }
}

module.exports = { TileService };
