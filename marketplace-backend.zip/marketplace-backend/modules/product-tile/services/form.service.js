const { LoggerFactory } = require('@logger');
const { ProductFormService } = require('@orm/services');

class FormService {
    static instance = null;

    constructor() {
        this.logger = LoggerFactory.getLogger(FormService.name);
        this.productFormService = ProductFormService.getInstance();
    }

    /**
     * Get instance of FormService
     * @returns {FormService} - Instance of FormService
     */
    static getInstance() {
        if (!FormService.instance) {
            FormService.instance = new FormService();
        }
        return FormService.instance;
    }

    /**
     * Get form by product id
     * @param {string} productId - Product ID
     * @param {string} type - Form type
     * @param {Object} options - Options
     * @param {string} options.locale - Locale
     * @returns {Promise<Object>} - Form object
     */
    async getFormByProductId(productId, type, options = {}) {
        return await this.productFormService.getFormByProductId(productId, type, options);
    }
}

module.exports = { FormService };