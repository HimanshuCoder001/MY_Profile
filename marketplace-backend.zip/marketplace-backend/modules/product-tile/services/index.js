'use strict';

const { TileService } = require('./tile.service');
const { BannerService } = require('./banner.service');
const { FormService } = require('./form.service');

module.exports = {
  TileService,
  BannerService,
  FormService
};
