'use strict';

const _ = require('lodash');
const { LoggerFactory } = require('@logger');
const { ProductBannerService } = require('@orm/services/product-banner.service');

class BannerService {
    static instance = null;

    constructor() {
        this.logger = LoggerFactory.getLogger(BannerService.name);
        this.productBannerService = ProductBannerService.getInstance();
    }

    /**
     * Get instance of BannerService
     * @returns {BannerService} - Instance of BannerService
     */
    static getInstance() {
        if (!BannerService.instance) {
            BannerService.instance = new BannerService();
        }
        return BannerService.instance;
    }

    /**
    * Get product banners by product ID using common query functions
    * @param {string} productId - Product ID
    * @param {Object} options - Query options
    * @returns {Promise<Object>} - Object with banner groups keyed by banner key
    */
    async getProductBanners(productId, options = {}) {
        try {
            const banners = await this.productBannerService.getProductBanners(productId);

            if (!banners) {
                this.logger.error({ ref: 'get product banners error', productId, error: 'Banners not found' });
                throw new Error('Banners not found');
            }

            const bannersByKey = _.groupBy(banners, banner => banner.key || 'default');
            const bannersObject = {};

            Object.keys(bannersByKey).forEach(key => {
                bannersObject[key] = {
                    name: bannersByKey[key][0].type,
                    icon: bannersByKey[key][0].bannerIcon,
                    list: bannersByKey[key].map(banner => {
                        const { type, key, ...bannerWithoutTypeAndKey } = banner;
                        return bannerWithoutTypeAndKey;
                    })
                };
            });

            this.logger.info({ ref: 'get product banners success', productId, count: banners.length, keys: Object.keys(bannersByKey) });
            return bannersObject;
        } catch (error) {
            this.logger.error({ ref: 'get product banners error', productId, error });
            throw error;
        }
    }
}

module.exports = { BannerService };