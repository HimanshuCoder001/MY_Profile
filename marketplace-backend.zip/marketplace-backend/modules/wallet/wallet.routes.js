'use strict';

const { WalletController } = require('./controllers');
const { WalletValidation } = require('./validation/wallet.validation');

const walletController = WalletController.getInstance();

module.exports = (router) => {
  // Check Wallet Balance for Insurance with validation
  router.get(
    '/check-balance',
    (req, res) => walletController.checkBalanceInsurance(req, res)
  );

  // Perform Insurance Debit Transaction with validation
  router.post(
    '/debit',
    WalletValidation.validateProcessWalletTransactionSchema,
    (req, res) => walletController.performInsuranceTransaction(req, res)
  );
};
