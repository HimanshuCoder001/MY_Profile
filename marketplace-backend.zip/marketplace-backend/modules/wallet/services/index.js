const { WalletWrapperService } = require('./walletWrapper.service');

module.exports = {
    WalletWrapperService,
};