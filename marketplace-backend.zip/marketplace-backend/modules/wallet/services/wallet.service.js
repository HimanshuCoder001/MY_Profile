'use strict';

const { LoggerFactory } = require('@logger');
const { WalletRequest } = require('../request/wallet.request');
const { marketPlaceSqModels } = require('@orm');
const LeadFlowModel = require('@odm/models/leadFlow');
const { ShopInsuranceService } = require('../../shop-insurance/services/shop-insurance.service');
const { v4: uuidv4 } = require('uuid');
const Session = require('@odm/models/session');
const { nameMatchScore } = require('@utils');
const DebitModel = require('@odm/models/debit');


class WalletService {
  constructor() {
    this.logger = LoggerFactory.getLogger(WalletService.name);
    this.walletRequest = WalletRequest.getInstance();
    this.transactions = marketPlaceSqModels.Transactions;
    this.flowConfig = ShopInsuranceService.getInstance().getFlowConfiguration();

    const config = require('config');
    this.walletCoreConfig = config.get('walletCore');
    this.minBalanceInsurance = parseFloat(this.walletCoreConfig.serviceFees['INSURANCE']);
  }

  validateBusinessRules(data, leadDetails) {
    const errors = [];

    const leadLenderName = data.customer_details.full_name;
    const leadCustomerName =  leadDetails.customerDetails.fullName;

    const similarity = nameMatchScore(leadLenderName, leadCustomerName); // 0–1
    const mismatch = Math.round((1 - similarity) * 100);
    const thresholdPercent = Math.round((1 - 0.8) * 100);
    const isValid = mismatch <= thresholdPercent;

    if (!isValid) {
      // errors.push({ field: 'customer_details.full_name', message: 'Customer name mismatch with onboarding details' });
      throw ('The insurer details not matching with the adhikari details in the system')
    }

    if (data.debit_amount !== data.plan_details.premium_amount) {
      errors.push({ field: 'debit_amount', message: 'debit_amount must match premium_amount' });
    }

    const dob = new Date(data.customer_details.dob);
    const today = new Date();
    let age = today.getFullYear() - dob.getFullYear();
    if (today.getMonth() < dob.getMonth() || 
        (today.getMonth() === dob.getMonth() && today.getDate() < dob.getDate())) {
      age--;
    }
    if (age < 18) {
      errors.push({ field: 'customer_details.dob', message: 'Customer must be at least 18 years old' });
    }

    const start = new Date(data.plan_details.policy_start_date);
    const end = new Date(data.plan_details.policy_end_date);
    const now = new Date();
    now.setHours(0, 0, 0, 0);

    if (start < now) {
      errors.push({ field: 'plan_details.policy_start_date', message: 'Start date must be today or in future' });
    }

    if (end <= start) {
      errors.push({ field: 'plan_details.policy_end_date', message: 'End date must be after start date' });
    }

    const reqTime = new Date(data.request_timestamp);

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  async getBalance({ headers, body }) {
    const logId = uuidv4();
    const requestId = uuidv4();
    const { clientid: clientId } = headers;
    const { reqType = 'NA', sessionId = '' } = body;
    const applicationNumber = null;
    const ref = "getBalance";

    this.logger.info(ref, 'Start getBalance', { logId, clientId, reqType, sessionId });

    try {
        const encryptedHeaders = await this.walletRequest.encryptHeaders({ sessionId }, reqType, clientId, applicationNumber, requestId);
        this.logger.info(ref, 'getBalance Encrypted headers', { logId, encryptedHeaders });

        const rawRequest = {
        requestId: `req${uuidv4().replace(/-/g, '')}`,
        retailerId: clientId,
        udf1: "", udf2: "", udf3: "", udf4: "", udf5: ""
        };
        this.logger.info(ref, 'getBalance raw request', { logId, rawRequest });

        const encryptedRequest = await this.walletRequest.encryptRequest(rawRequest, clientId, applicationNumber, requestId);
        this.logger.info(ref, 'getBalance Encrypted request', { logId, encryptedRequest });

        // TODO: Uncomment when walletRequest methods are implemented
        const encryptedResponse = await this.walletRequest.walletBalanceRequest(
        encryptedRequest, encryptedHeaders, clientId, applicationNumber, requestId
        );

        this.logger.info(ref, 'getBalance Encrypted response', { logId, encryptedResponse });

        const decryptedResponse = await this.walletRequest.decryptResponse(
        encryptedResponse.enbody,
        reqType, clientId, applicationNumber, requestId
        );

        if (decryptedResponse?.responseStatus === "S") {
        return decryptedResponse.payload?.wallets || null;
        } else if (decryptedResponse?.responseStatus === "F") {
        throw new Error("Insufficient Wallet Balance. Please recharge your wallet and relogin to proceed further");
        }
        throw new Error("Wallet balance not found. Please try after sometime");

        // Need to check on how to update the flow steps without leadId
        // Vendor will only send client_id, lead_id where leadId vs lead_id are different

    } catch (error) {
      this.logger.error(ref, error, { logId, requestId });
      this.logger.info(ref, 'getBalance exception stack trace', { logId, error: error.stack });
      throw error;
    }
  }

  async debit({ headers, body, walletRequestId }) {
    const logId = uuidv4();
    const requestId = uuidv4();
    const { clientid: clientId } = headers;
    const { debitAmount, udf1 = "", udf2 = "", reqType = 'NA', sessionId = '' } = body;
    const applicationNumber = null;
    const ref = "debitWallet";


    this.logger.info(ref, 'Start debit', { logId, clientId, requestId, debitAmount });

    try {
      const encryptedHeaders = await this.walletRequest.encryptHeaders({ sessionId }, reqType, clientId, applicationNumber, requestId);
      // console.log("encryptedHeaders-----------------------------", JSON.stringify(encryptedHeaders));
      
      const serviceId = this.walletRequest.getServiceId(reqType);
      // console.log("serviceId-----------------------------", JSON.stringify(serviceId));

      if (!serviceId) {
        const supportedTypes = Object.keys(this.serviceHeaderMap).join(', ');
        const error = new Error(`Unsupported reqType: '${reqType}'. Supported types are: ${supportedTypes}`);
        this.logger.error(ref, error, { logId, reqType, availableServiceIds: Object.keys(this.serviceIdMap) });
        throw error;
      }
      
      const rawRequest = {
        requestId: walletRequestId,
        retailerId: clientId,
        transInitId: `trans${uuidv4().replace(/-/g, '')}`,
        serviceId,
        productCode: "",
        totalAmount: debitAmount,
        serviceCharges: "",
        serviceTax: "",
        otherCharges: "",
        udf1, udf2, udf3: "", udf4: "", udf5: ""
      };
      // console.log("rawRequest-----------------------------", JSON.stringify(rawRequest));

      const encryptedRequest = await this.walletRequest.encryptRequest(rawRequest, clientId, applicationNumber, requestId);
      // console.log("encryptedRequest-----------------------------", JSON.stringify(encryptedRequest));

      const encryptedResponse = await this.walletRequest.walletDebitRequest(encryptedRequest, encryptedHeaders, clientId, applicationNumber, requestId);
      // console.log("encryptedResponse-----------------------------", JSON.stringify(encryptedResponse));

      const decryptedResponse = await this.walletRequest.decryptResponse(encryptedResponse.enbody, reqType, clientId, applicationNumber, requestId);
      // console.log("decryptedResponse-----------------------------", JSON.stringify(decryptedResponse));

      // const decryptedResponse = JSON.parse(decryptedResponseStr) || {};
      // console.log("decryptedResponse-----------------------------", JSON.stringify(decryptedResponse));

      this.logger.info(ref, 'debit response', { logId, data: decryptedResponse });

      if (decryptedResponse?.responseStatus === "S") {
        return decryptedResponse;
      }

      throw new Error("Debit transaction failed");
    } catch (error) {
      this.logger.error(ref, error, { logId, requestId });
      throw error;
    }
  }

  async updateDebit({ headers, body, walletRequestId }) {
    const logId = uuidv4();
    const requestId = uuidv4();
    const { clientid: clientId } = headers;
    const {
      requestId: reqRequestId,
      transInitId,
      transInitRefNo,
      transStatus,
      isRefund,
      refundReason,
      refundAmount,
      refundCharges = "",
      udf1 = "",
      udf2 = "",
      reqType = 'NA',
      sessionId = ''
    } = body;
    const applicationNumber = null;
    const ref = "updateDebitWallet";
  
    this.logger.info(ref, 'Start updateDebit', { logId, clientId, reqRequestId });
  
    try {
      const encryptedHeaders = await this.walletRequest.encryptHeaders(
        { sessionId },
        reqType,
        clientId,
        applicationNumber,
        requestId
      );
  
      const rawRequest = {
        requestId: walletRequestId,
        retailerId: clientId,
        transInitId,
        transInitRefNo,
        transStatus,
        transUpdSeq: "",
        isRefund,
        refundReason,
        refundAmount,
        refundCharges,
        udf1, udf2, udf3: "", udf4: "", udf5: ""
      };
  
      const encryptedRequest = await this.walletRequest.encryptRequest(
        rawRequest,
        clientId,
        applicationNumber,
        requestId
      );
      // console.log("updateDebit encryptedRequest:", JSON.stringify(encryptedRequest));
  
      const encryptedResponse = await this.walletRequest.walletDebitUpdateRequest(
        encryptedRequest,
        encryptedHeaders,
        clientId,
        applicationNumber,
        requestId
      );
      // console.log("updateDebit encryptedResponse:", JSON.stringify(encryptedResponse));
  
      const decryptedResponse = await this.walletRequest.decryptResponse(
        encryptedResponse.enbody,
        reqType,
        clientId,
        applicationNumber,
        requestId
      );
      // console.log("updateDebit decryptedResponse:", JSON.stringify(decryptedResponse));
  
      this.logger.info(ref, 'updateDebit response', { logId, data: decryptedResponse });
  
      if (decryptedResponse?.responseStatus === "S") {
        return decryptedResponse;
      }
  
      throw new Error("Update debit transaction failed");
    } catch (error) {
      this.logger.error(ref, error, { logId, requestId: reqRequestId });
      throw error;
    }
  }
  

  async checkWalletBalance(clientId, requestId) {
     // Get the latest document session document from the database
     const session = await Session.findOne({clientId: clientId}, 'validationResponse sessionId aggId clientId udf1 lang token')
     .sort({ createdAt: -1 })  
     .lean();
 
     if (!session) {
         throw new Error('No active session found for this wallet transaction. Please re-login and check');
     }
 
     const { validationResponse } = session;
     const sessionId = validationResponse?.sessionID;

    const balanceReq = {
        headers: { clientid: clientId },
        body: { sessionId, reqType: 'INSURANCE' }
    };

    try {
        const resPayload = await this.getBalance(balanceReq);

        this.logger.info('checkWalletBalance', 'Wallet balance check completed', {
            clientId,
            sessionId,
            requestId,
            balance: resPayload
        });

        // console.log('checkWalletBalance -----------------------------------------', JSON.stringify(resPayload));

        if (!resPayload || !Array.isArray(resPayload)) {
            this.logger.warn('checkWalletBalance', 'Invalid wallet balance response', {
                clientId,
                sessionId,
                requestId,
                balance: resPayload
            });
            throw new Error('Invalid wallet balance response');
        }

        return resPayload; // return the wallet data if valid
    } catch (error) {
        this.logger.error('checkWalletBalance', 'Error while checking wallet balance', {
            clientId,
            sessionId,
            requestId,
            error: error.message,
            stack: error.stack
        });
        throw error;
    }
}

  async performInsuranceTransaction(data, clientId, sessionId, leadDetails) {
    const ref = 'performInsuranceTransaction';
    const logId = uuidv4();

    this.logger.info({ ref, logId, message: 'Starting transaction', clientId });

    // Step 0: Validate input data
    const validation = this.validateBusinessRules(data, leadDetails);
    if (!validation.isValid) {
      await DebitModel.create({
        clientId,
        sessionId,
        requestType: 'INSURANCE',
        requestPayload: data,
        status: 'VALIDATION_FAILED',
        debitResponse: { errors: validation.errors }
      });
      this.logger.warn({ ref, logId, message: 'Validation failed', errors: validation.errors });
      return { success: false, errors: validation.errors };
    }

    // Step 1: Check wallet balance
    const balanceData = await this.getBalance({
      headers: { clientid: clientId },
      body: { sessionId, reqType: 'INSURANCE' }
    });

    if (!Array.isArray(balanceData)) {
      return { success: false, message: 'Invalid wallet balance response' };
    }

    const insuranceWallet = Array.isArray(balanceData)

    if (!insuranceWallet) {
      return { success: false, message: 'Insurance wallet not found' };
    }

    if (parseFloat(insuranceWallet.balance) < this.minBalanceInsurance) {
      return {
        success: false,
        message: `Insufficient balance. Required: ${this.minBalanceInsurance}, Available: ${insuranceWallet.balance}`
      };
    }

    // Step 2: Debit wallet
    const debitAmount = data.debit_amount;
    const debitBody = {
      debitAmount,
      udf1: data.udf1 || 'INSURANCE',
      udf2: data.udf2 || '',
      reqType: 'INSURANCE',
      sessionId
    };

    let debitResponse;
    const walletRequestId = `req${uuidv4().replace(/-/g, '')}`;
    try {
      debitResponse = await this.debit({
        headers: { clientid: clientId },
        body: debitBody,
        walletRequestId
      });
      // console.log("debit response:", JSON.stringify(debitResponse));
    } catch (error) {
      await DebitModel.create({
        clientId,
        sessionId,
        requestType: 'INSURANCE',
        requestPayload: { data, debitBody },
        status: 'DEBIT_FAILED',
        debitResponse: { error: error.message }
      });
      this.logger.error(ref, error, { logId });
      throw new Error('Debit transaction failed');
    }

    if (debitResponse.responseStatus !== 'S') {
      throw new Error('Debit transaction unsuccessful');
    }

    // Step 3: Save transaction in DB
    const {
      requestId: debitRequestId,
      transInitId,
      transInitRefNo
    } = debitResponse.payload || {};

    // Generate request_id for DB as it cannot be null
    const request_id = debitRequestId || uuidv4();

    await this.transactions.createTransaction({
      request_id,
      source: 'INSURANCE', 
      client_id: clientId,
      session_id: sessionId,
      req_type: walletRequestId,
      service_id: this.walletRequest.getServiceId
        ? this.walletRequest.getServiceId('INSURANCE')
        : this.serviceIdMap['INSURANCE'],
      debit_amount: debitAmount,
      transInitId,
      transInitRefNo,
      transaction_status: debitResponse.responseStatus || 'UNKNOWN',
      is_refund: 'N',
      refund_reason: '',
      refund_amount: '',
      wallet_balance: insuranceWallet.balance,
      balance_ts: new Date(),
      debit_ts: new Date(),
      client_details: data.customer_details || {},
      transaction_details: data.plan_details || {}
    });

    // Step 4: Update debit status
    const updateBody = {
      requestId: request_id,  // Use the same request_id saved in DB here
      transInitId,
      transInitRefNo,
      transStatus: 'SUCCESS',
      isRefund: 'N',
      refundReason: '',
      refundAmount: '',
      udf1: debitBody.udf1,
      udf2: debitBody.udf2,
      reqType: 'INSURANCE',
      sessionId
    };

    // console.log("updateBody:", JSON.stringify(updateBody));

    let updateResponse;
    try {
      updateResponse = await this.updateDebit({
        headers: { clientid: clientId },
        body: updateBody,
        walletRequestId
      });
    } catch (error) {
      await DebitModel.create({
        clientId,
        sessionId,
        requestType: 'INSURANCE',
        requestPayload: { data, debitBody, updateBody },
        status: 'DEBIT_UPDATE_FAILED',
        debitResponse: { error: error.message }
      });
      this.logger.error(ref, error, { logId });
      throw new Error('Update debit transaction failed');
    }

    // console.log("updateResponse:", JSON.stringify(updateResponse));

    // Step 5: Update transaction status in DB
    await this.transactions.updateTransactionStatus(
      request_id,  // use consistent request_id
      updateResponse?.payload?.transStatus || 'UPDATED',
      { update_ts: new Date() }
    );

    // Add log to MongoDB
    try {
      await DebitModel.create({
        clientId,
        sessionId,
        requestType: debitBody?.reqType,
        requestPayload: {
          data,
          debitBody,
          updateBody,
        },
        debitResponse,
        updateResponse,
        requestId: request_id,
        walletRequestId,
        status: 'SUCCESS'
      });
    } catch (error) {
      this.logger.error(ref, error, { logId, requestId });
      this.logger.info(ref, 'performInsuranceTransaction log exception stack trace', { logId, error: error.stack });
    } 
    

    return {
      success: true,
      message: 'Transaction processed successfully',
      data: {
        balance: insuranceWallet.balance,
        debitResponse,
        updateResponse
      }
    };
  }
}

module.exports = { WalletService };
