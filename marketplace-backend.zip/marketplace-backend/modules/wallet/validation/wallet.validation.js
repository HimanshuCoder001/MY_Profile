'use strict';

const { ValidationUtil } = require('@utils');
const checkWalletBalanceSchema = require('./schemas/insurance.balance-check.schema.json');
const processWalletTransactionSchema = require('./schemas/insurance.transaction.schema.json');

class WalletValidation {
  /**
   * Validate wallet transaction request body
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   * @param {Function} next - Next middleware function
   */
  static validateProcessWalletTransactionSchema(req, res, next) {
    return ValidationUtil.validateSchema(req, res, next, processWalletTransactionSchema, {
      errorFormat: 'structured',
      logScope: 'WalletValidation::ProcessTransaction'
    });
  }

  /**
   * Validate wallet balance check request body
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   * @param {Function} next - Next middleware function
   */
  static validateCheckWalletBalanceSchema(req, res, next) {
    return ValidationUtil.validateSchema(req, res, next, checkWalletBalanceSchema, {
      errorFormat: 'structured',
      logScope: 'WalletValidation::CheckBalance'
    });
  }
}

module.exports = { WalletValidation };
