'use strict';

const config = require('config');
const { AxiosService } = require('@request');
const { LoggerFactory } = require('@logger');

class WalletRequest {
  constructor() {
    this.axiosService = AxiosService.getInstance();
    this.logger = LoggerFactory.getLogger(WalletRequest.name);

    this.walletEncryptDecryptConfig = config.get('walletEncryptDecrypt');
    this.walletCoreConfig = config.get('walletCore');

    const { serviceIds, serviceHeaders } = this.walletCoreConfig;

    this.serviceHeaderMap = {
      'EXPERIAN': serviceHeaders.experianHeaders,
      'ZET': serviceHeaders.zetHeaders,
      'INSURANCE': serviceHeaders.insuranceHeaders
    };

    this.serviceIdMap = {
      'EXPERIAN': serviceIds.experian_service_id,
      'ZET': serviceIds.zet_service_id,
      'INSURANCE': serviceIds.insurance_service_id
    };
  }

    /**
     * Singleton instance getter
     * @return {WalletRequest} Singleton instance of WalletRequest
     * */
  static getInstance() {
    return new WalletRequest();
  }

  async encryptHeaders(payload, reqType, clientId, applicationNumber, requestId) {
    const logger = this.logger;
    const { host, port, protocol, endpoints, headers } = this.walletEncryptDecryptConfig;

    const headersData = this.serviceHeaderMap[reqType];
    if (!headersData) {
      const supportedTypes = Object.keys(this.serviceHeaderMap).join(', ');
      throw new Error(`Unsupported reqType: '${reqType}'. Supported types: ${supportedTypes}`);
    }

    const data = { ...headersData, sessionId: payload.sessionId };
    logger.info({ ref: 'encryptHeaders', message: 'Calling encryptHeaders API', data:  data});

    const conf = {
      host,
      port,
      protocol,
      headers,
      method: endpoints.encrypt_headers.method || 'POST',
      url: endpoints.encrypt_headers.url
    };
    logger.info({ ref: 'encryptHeaders', message: 'Calling encryptHeaders API', conf:  conf});
    return await this.axiosService.handle(conf, data, clientId, applicationNumber, requestId);
  }

  async encryptRequest(payload, clientId, applicationNumber, requestId) {
    const logger = this.logger;
    const { host, port, protocol, endpoints, headers } = this.walletEncryptDecryptConfig;

    const conf = {
      host,
      port,
      protocol,
      headers,
      method: endpoints.encrypt_request.method || 'POST',
      url: endpoints.encrypt_request.url
    };

    logger.info({ ref: 'encryptRequest', message: 'Calling encryptRequest API' });
    return await this.axiosService.handle(conf, payload, clientId, applicationNumber, requestId);
  }

  async decryptResponse(payload, reqType, clientId, applicationNumber, requestId) {
    const logger = this.logger;
    const { host, port, protocol, endpoints, headers } = this.walletEncryptDecryptConfig;

    const conf = {
      host,
      port,
      protocol,
      headers: {
        Authorization: headers.Authorization,
        'content-type': 'text/plain;charset=UTF-8'
      },
      method: endpoints.decrypt_response.method || 'POST',
      url: endpoints.decrypt_response.url
    };

    logger.info({ ref: 'decryptResponse', message: 'Calling decryptResponse API' });
    return await this.axiosService.handle(conf, payload, clientId, applicationNumber, requestId);
  }

  async walletBalanceRequest(encReq, encHeaders, clientId, applicationNumber, requestId) {
    const logger = this.logger;
    const { host, port, protocol, endpoints } = this.walletCoreConfig;

    const conf = {
      host,
      port,
      protocol,
      headers: { authentication: encHeaders },
      method: endpoints.wallet_balance.method || 'POST',
      url: endpoints.wallet_balance.url
    };

    logger.info({ ref: 'walletBalanceRequest', message: 'Calling walletBalanceRequest API' });
    return await this.axiosService.handle(conf, { enbody: encReq }, clientId, applicationNumber, requestId);
  }

  async walletDebitRequest(encReq, encHeaders, clientId, applicationNumber, requestId) {
    const logger = this.logger;
    const { host, port, protocol, endpoints, headers } = this.walletCoreConfig;

    const conf = {
      host,
      port,
      protocol,
      headers: { ...headers, authentication: encHeaders },
      method: endpoints.wallet_debit.method || 'POST',
      url: endpoints.wallet_debit.url
    };

    logger.info({ ref: 'walletDebitRequest', message: 'Calling walletDebitRequest API' });
    return await this.axiosService.handle(conf, { enbody: encReq }, clientId, applicationNumber, requestId);
  }

  async walletDebitUpdateRequest(encReq, encHeaders, clientId, applicationNumber, requestId) {
    const logger = this.logger;
    const { host, port, protocol, endpoints, headers } = this.walletCoreConfig;

    const conf = {
      host,
      port,
      protocol,
      headers: { ...headers, authentication: encHeaders },
      method: endpoints.wallet_debit_update.method || 'POST',
      url: endpoints.wallet_debit_update.url
    };

    logger.info({ ref: 'walletDebitUpdateRequest', message: 'Calling walletDebitUpdateRequest API' });
    return await this.axiosService.handle(conf, { enbody: encReq }, clientId, applicationNumber, requestId);
  }

  getServiceId(reqType) {
    return this.serviceIdMap[reqType];
  }
}

module.exports = { WalletRequest };
