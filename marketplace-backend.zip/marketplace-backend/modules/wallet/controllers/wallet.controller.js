'use strict';

const { LoggerFactory } = require('@logger');
const { WalletService } = require('../services/wallet.service');
const { v4: uuidv4 } = require('uuid');
const Session = require('@odm/models/session');
const LeadModel = require('@odm/models/lead');
const DebitModel = require('@odm/models/debit');


class WalletController {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(WalletController.name);
    this.walletService = new WalletService();
  }

  /**
   * Singleton instance getter
   * @returns {WalletController} Singleton instance of WalletController
   */
  static getInstance() {
    if (!WalletController.instance) {
      WalletController.instance = new WalletController();
    }
    return WalletController.instance;
  }

  async checkBalanceInsurance(req, res) {
    const ref = 'checkBalanceInsurance';
    const logId = req?.logId || uuidv4();
    const sessionId = req.headers.token;
    const clientId = req.headers.clientid;

    this.logger.info({ ref, logId, message: 'Initiating balance check' });

    try {
      const data = await this.walletService.checkWalletBalance(clientId, sessionId, logId);
      this.logger.info({ ref, logId, message: 'Balance check successful', data });

      return res.sendWrapped(null, data);
    } catch (error) {
      this.logger.error({ ref, logId, message: error.message, stack: error.stack });
      return res.sendWrapped(error);
    }
  }

  async performInsuranceTransaction(req, res) {
    const ref = 'performInsuranceTransaction';
    const logId = uuidv4();

    // Log into Debit Model
    
    // const clientId = req.headers.clientid;
    // const sessionId = req.headers.token;
    const requestData = req.body;
    const clientId = requestData.client_id;

    if (!clientId) {
      return res.sendWrapped('Client not found in the request body');
    }

    // Get the latest document session document from the database
    const session = await Session.findOne({clientId: clientId}, 'validationResponse sessionId aggId clientId udf1 lang token')
    .sort({ createdAt: -1 })  
    .lean();
    // console.log('session -----------------------------------------', JSON.stringify(session));

    const { validationResponse } = session;

    if (!session) {
        throw new Error('No active session found for this walet transaction. Please re-login and check');
    }

    const sessionId = validationResponse?.sessionID;

    if (!sessionId) {
      throw new Error('No active session found for this walet transaction. Please re-login and check');
    }

    // Check if a successful debit transaction already exists for this client
    const existingSuccessfulDebit = await DebitModel.findOne({
      clientId: clientId,
      requestType: 'INSURANCE',
      status: 'SUCCESS'
    })
    .sort({ createdAt: -1 })
    .lean();

    if (existingSuccessfulDebit) {
      this.logger.info({ ref, logId, message: 'Existing successful debit found. Restricting duplicate insurance transaction.', clientId, debitId: existingSuccessfulDebit?._id });
      return res.sendWrapped('Policy is already applied. Please check your wallet summary for deduction status.');
    }

    // Get the latest lead from the database
    const leadDetails = await LeadModel.findOne({clientId: clientId}, 'applicationId clientId customerDetails')
    .sort({ createdAt: -1 })  
    .lean();

    this.logger.info({ ref, logId, message: 'Received request for insurance transaction', clientId });

    try {
      const result = await this.walletService.performInsuranceTransaction(requestData, clientId, sessionId, leadDetails);

      if (!result.success) {
        this.logger.warn({ ref, logId, message: 'Transaction failed', ...result });
        return res.sendWrapped('Transaction failed', {
          success: false,
          message: result.message || 'Transaction failed',
          errors: result.errors || null
        });
      }

      this.logger.info({ ref, logId, message: 'Transaction successful' });
      return res.sendWrapped(null, {
        success: true,
        data: result.data
      });
    } catch (error) {
      this.logger.error({ ref, logId, message: error.message, stack: error.stack });
      return res.sendWrapped(error);
    }
  }
}

module.exports = { WalletController };
