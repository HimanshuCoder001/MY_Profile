const { WalletController } = require('./wallet.controller');

module.exports = {
    WalletController,
};