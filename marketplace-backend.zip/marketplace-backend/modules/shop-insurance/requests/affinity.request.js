'use strict';

const config = require('config');
const { AxiosService } = require('@request');
const { LoggerFactory } = require('@logger');

class AffinityRequest {
  constructor() {
    this.axiosService = AxiosService.getInstance();
    this.logger = LoggerFactory.getLogger(AffinityRequest.name);
    this.affinityConfig = config.get('affinityAPI');
  }

  /**
   * Singleton instance getter
   * @return {AffinityRequest} Singleton instance of AffinityRequest
   */
  static getInstance() {
    return new AffinityRequest();
  }

  /**
   * Generate token from Affinity API
   * @param {Object} payload - Request payload containing username, password, and type
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} requestId - Request identifier (optional)
   * @returns {Promise<Object>} Response from Affinity API
   */
  async generateToken(payload, clientId = '', applicationNumber = '', requestId = '') {
    const { host, port, protocol, headers, endpoints } = this.affinityConfig;

    const conf = {
      host,
      port,
      protocol,
      headers: {
        ...headers,
      },
      method: endpoints.generate_token.method,
      url: endpoints.generate_token.url
    };

    this.logger.info({ 
      ref: 'generateToken', 
      message: 'Calling Affinity generateToken API',
      payload: { username: payload.username, type: payload.type }
    });

    return await this.axiosService.handle(conf, payload, clientId, applicationNumber, requestId);
  }

  /**
   * Check status from Affinity API
   * @param {Object} payload - Request payload
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} requestId - Request identifier (optional)
   * @returns {Promise<Object>} Response from Affinity API
   */
  async checkStatus(payload, clientId = '', applicationNumber = '', requestId = '') {
    const { host, port, protocol, headers, endpoints } = this.affinityConfig;

    const conf = {
      host,
      port,
      protocol,
      headers,
      method: endpoints.check_status.method,
      url: endpoints.check_status.url
    };

    this.logger.info({ 
      ref: 'checkStatus', 
      message: 'Calling Affinity checkStatus API'
    });

    return await this.axiosService.handle(conf, payload, clientId, applicationNumber, requestId);
  }
}

module.exports = { AffinityRequest };
