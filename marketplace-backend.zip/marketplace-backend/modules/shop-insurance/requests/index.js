const { AffinityRequest } = require('./affinity.request');
const { PpiRequest } = require('./ppi.request');
const { AllianceStatusRequest } = require('./status.request')

module.exports = {
  AffinityRequest,
  PpiRequest,
  AllianceStatusRequest
};
