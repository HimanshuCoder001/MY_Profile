'use strict';

const config = require('config');
const { AxiosService } = require('@request');
const { LoggerFactory } = require('@logger');

class AllianceStatusRequest {
  constructor() {
    this.axiosService = AxiosService.getInstance();
    this.logger = LoggerFactory.getLogger(AllianceStatusRequest.name);
    this.affinityConfig = config.get('affinityAPI');
  }

  /**
   * Singleton instance getter
   * @return {AllianceStatusRequest} Singleton instance of AllianceStatusRequest
   */
  static getInstance() {
    return new AllianceStatusRequest();
  }

  /**
   * Generate auth token from Affinity API
   * @returns {Promise<string>} utoken
   */
  async generateToken() {
    const { host, port, protocol, headers, endpoints } = this.affinityConfig;

    // Build full URL using protocol, host, and port
    const url = `${protocol}://${host}:${port}${endpoints.generate_token.url}`;

    const config = {
      url,
      method: endpoints.generate_token.method,
      headers
    };
    this.logger.info({ ref: 'generateToken', message: 'Requesting auth token' });
    this.logger.info({ ref: 'generateToken', detail: 'Request config', data: config });

    const payload = {
      username: 'Kshitij',
      password: 123456,
      type: 1
    };
    this.logger.info({ ref: 'generateToken', detail: 'Payload', data: payload });

    const response = await this.axiosService.handle(config, payload);
    this.logger.info({ ref: 'generateToken', detail: 'Response', data: response });

    const data = typeof response === 'string' ? JSON.parse(response) : response;

    if (!data.utoken) {
      this.logger.error({ ref: 'generateToken', message: 'Token not found in response', response });
      throw new Error('Token generation failed');
    }

    return data.utoken;
  }

  /**
   * Get Alliance policy status for a unique_id
   * @param {string} uniqueId
   * @returns {Promise<Array>} List of successful policy details
   */
  async getStatus(uniqueId) {
    const utoken = await this.generateToken();
    this.logger.info({ ref: 'getStatus', message: 'Generated utoken', data: utoken });

    const { host, port, protocol, headers, endpoints } = this.affinityConfig;

    const url = `${protocol}://${host}:${port}${endpoints.check_status.url}`;

    const config = {
      url,
      method: endpoints.check_status.method,
      headers
    };

    const payload = {
      utoken,
      unique_id: uniqueId
    };

    this.logger.info({
      ref: 'getStatus',
      message: 'Checking policy status',
      payload: { uniqueId }
    });
    this.logger.info({ ref: 'getStatus', detail: 'Request config', data: config });

    const response = await this.axiosService.handle(config, payload);
    this.logger.info({ ref: 'getStatus', detail: 'Response', data: response });

    const data = typeof response === 'string' ? JSON.parse(response) : response;

    const result = [];

    for (const provider of ['care', 'icici']) {
      const item = data[provider];
      if (item && item.msg === 'Policy Issuance success.') {
        result.push({
          provider,
          coi_url: item.coi_url,
          policy_start_date: item.policy_start_date,
          policy_end_date: item.policy_end_date
        });
      }
    }

    return result;
  }
}

module.exports = { AllianceStatusRequest };
