'use strict';

const config = require('config');
const { AxiosService } = require('@request');
const { LoggerFactory } = require('@logger');

class PpiRequest {
  constructor() {
    this.axiosService = AxiosService.getInstance();
    this.logger = LoggerFactory.getLogger(PpiRequest.name);
    this.ppiConfig = config.get('ppiAPI');
  }

  /**
   * Singleton instance getter
   * @return {PpiRequest} Singleton instance of PpiRequest
   */
  static getInstance() {
    return new PpiRequest();
  }

  /**
   * Fetch client details from PPI API
   * @param {Object} payload - Request payload containing clientId
   * @param {string} clientId - Client identifier
   * @param {string} applicationNumber - Application number (optional)
   * @param {string} requestId - Request identifier (optional)
   * @returns {Promise<Object>} Response from PPI API
   */
  async fetchClientDetails(payload, clientId = '', applicationNumber = '', requestId = '') {
    const logger = this.logger;
    const { host, port, protocol, headers, endpoints } = this.ppiConfig;

    const conf = {
      host,
      port,
      protocol,
      headers,
      method: endpoints.fetch_client_details.method,
      url: endpoints.fetch_client_details.url
    };

    logger.info({ 
      ref: 'fetchClientDetails', 
      message: 'Calling PPI fetchClientDetails API',
      payload: { clientId: payload.clientId } // Log only clientId for security
    });

    return await this.axiosService.handle(conf, payload, clientId, applicationNumber, requestId);
  }
}

module.exports = { PpiRequest };
