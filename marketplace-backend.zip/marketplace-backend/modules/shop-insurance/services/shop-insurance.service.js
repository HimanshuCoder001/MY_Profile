'use strict';

const { v4: uuidv4 } = require('uuid');
const { LoggerFactory } = require('@logger');
const { ProductFormService } = require('@orm/services');
const { LeadService, FormSubmissionService } = require('@odm/services');
const { ValidationException, NotFoundException, DatabaseException } = require('@core/exceptions');
const { FormValidationService } = require('@helpers');
const { nameMatchScore } = require('@utils');
const { PpiRequest } = require('../requests');
const { AllianceStatusRequest } = require('../requests');
const config = require('config');

class ShopInsuranceService {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(ShopInsuranceService.name);
    this.leadService = LeadService.getInstance();
    this.formSubmissionService = FormSubmissionService.getInstance();
    this.productFormService = ProductFormService.getInstance();
    this.formValidationService = FormValidationService.getInstance();
    this.ppiRequest = PpiRequest.getInstance();
    this.statusRequest = AllianceStatusRequest.getInstance();
    this.affinityConfig = config.get('affinityAPI');
  }

  /**
   * Get instance of ShopInsuranceService
   * @returns {ShopInsuranceService} - Instance of ShopInsuranceService
   */
  static getInstance() {
    if (!ShopInsuranceService.instance) {
      ShopInsuranceService.instance = new ShopInsuranceService();
    }
    return ShopInsuranceService.instance;
  }

  /**
   * Generate application number with SPM prefix
   * @returns {string} - Generated application number
   */
  generateApplicationNumber() {
    const randomNumber = Math.floor(Math.random() * 1000000000).toString().padStart(9, '0');
    return `SPM${randomNumber}`;
  }

  /**
   * Generate redirection URL for shop insurance
   * @param {Object} shopInsuranceData - Shop insurance data
   * @returns {string} - Generated redirection URL
   */
  generateRedirectionUrl(shopInsuranceData) {
    const { applicationId, clientId } = shopInsuranceData;

    const { baseUrl, partnerParam } = this.affinityConfig;

    const utmSource = clientId;
    const utmUniqueId = applicationId;
    const utmMedium = 'spicemoney';

    const url = new URL(baseUrl);
    url.searchParams.set('partner', partnerParam);
    url.searchParams.set('utm_source', utmSource);
    url.searchParams.set('utm_uniqueid', utmUniqueId);
    url.searchParams.set('utm_medium', utmMedium);

    return url.toString();
  }

  /**
   * Create a new shop insurance with all related data
   * @param {Object} shopInsuranceData - Shop insurance data
   * @returns {Promise<Object>} - Created shop insurance with details
   */
  async createShopInsuranceWithDetails(shopInsuranceData) {
    try {
      const flowConfig = this.getFlowConfiguration();
      const redirectionUrl = this.generateRedirectionUrl(shopInsuranceData);

      const enrichedLeadData = {
        ...shopInsuranceData,
        applicationId: shopInsuranceData.applicationId || this.generateApplicationNumber(),
        leadCategory: 'INSURANCE',
        leadType: 'SHOP_INSURANCE',
        flowType: flowConfig.flowType,
        redirectionUrl: redirectionUrl || shopInsuranceData.redirectionUrl,
        isRedirection: shopInsuranceData.isRedirection || !!redirectionUrl,
        meta: shopInsuranceData.meta || {}
      };

      const result = await this.leadService.createLeadWithDetails(enrichedLeadData, flowConfig);

      this.logger.info({
        ref: 'createShopInsuranceWithDetails',
        message: 'Shop insurance created successfully',
        leadId: result.lead.leadId,
        applicationId: result.lead.applicationId,
        flowType: result.lead.flowType
      });

      return result;
    } catch (error) {
      this.logger.error({ ref: 'createShopInsuranceWithDetails error', error });
      throw error;
    }
  }

  /**
   * Create form submission
   * @param {Object} formData - Form submission data
   * @param {string} stepId - Step ID
   * @returns {Promise<Object>} - Created form submission
   */
  async createFormSubmission(formData, stepId) {
    try {
      this.logger.info({
        ref: 'createFormSubmission',
        message: 'Creating form submission',
        formType: formData.formType,
        leadId: formData.leadId
      });

      const formSubmission = await this.formSubmissionService.createFormSubmission(formData, stepId);

      this.logger.info({
        ref: 'createFormSubmission',
        message: 'Form submission created successfully',
        formSubmissionId: formSubmission.formSubmissionId
      });

      return formSubmission;
    } catch (error) {
      this.logger.error({ ref: 'createFormSubmission error', error });
      throw error;
    }
  }

  /**
   * Extract customer details from form data
   * @param {Object} formData - Form data object
   * @param {Object} existingCustomerDetails - Existing customer details (optional)
   * @returns {Object} - Extracted customer details
   */
  extractCustomerDetailsFromFormData(formData, existingCustomerDetails = {}) {
    if (!formData) return existingCustomerDetails;

    return {
      fullName: formData.fullName || formData.name || existingCustomerDetails.fullName,
      mobile: formData.mobile || formData.phone || existingCustomerDetails.mobile,
      email: formData.email || existingCustomerDetails.email,
      gender: formData.gender || existingCustomerDetails.gender,
      dateOfBirth: formData.dateOfBirth || formData.dob || existingCustomerDetails.dateOfBirth,
      pan: formData.pan || existingCustomerDetails.pan,
      aadhar: formData.aadhar || existingCustomerDetails.aadhar,
      address: {
        street: formData.street || formData.address?.street || existingCustomerDetails.address?.street,
        city: formData.city || formData.address?.city || existingCustomerDetails.address?.city,
        state: formData.state || formData.address?.state || existingCustomerDetails.address?.state,
        pincode: formData.pincode || formData.address?.pincode || existingCustomerDetails.address?.pincode
      }
    };
  }

  /**
   * Get flow configuration for lead type
   * @returns {Object} - Flow configuration
   */
  getFlowConfiguration() {
    return {
      flowType: 'SINGLE_FORM',
      flowName: 'Shop Insurance Flow',
      partner: 'Elephant Insurance',
      flowSteps: [
        { stepId: 'basic_details', stepName: 'Basic Details', stepType: 'FORM', stepOrder: 1, isRequired: true },
        { stepId: 'redirection', stepName: 'Redirect to Partner', stepType: 'REDIRECTION', stepOrder: 2, isRequired: true },
        { stepId: 'wallet_debit', stepName: 'Deduct Insurance Amount', stepType: 'DEBIT', stepOrder: 3, isRequired: true },
        { stepId: 'lender_status', stepName: 'Check Insurance Policy status', stepType: 'STATUS', stepOrder: 4, isRequired: true },
      ]
    }
  }

  /**
   * Enrich shop insurance data with default values
   * @param {Object} shopInsuranceData - Original shop insurance data
   * @returns {Object} - Enriched shop insurance data
   */
  enrichShopInsuranceData(shopInsuranceData) {
    return {
      ...shopInsuranceData,
      leadCategory: 'INSURANCE',
      flowType: shopInsuranceData.flowType || 'SINGLE_FORM',
      applicationId: shopInsuranceData.applicationId || this.generateApplicationNumber(),
      meta: shopInsuranceData.meta || {}
    };
  }

  async getFormByProductId(productId) {
    return await this.productFormService.getFormByProductId(productId, 'SHOP_INSURANCE_LEAD_FORM');
  }

  /**
   * Validate form data against form schema
   * @param {Object} formData - Form data to validate
   * @param {Object} formSchema - Form schema from formJson
   * @returns {Object} - Validation result
   */
  validateFormData(formData, formSchema) {
    return this.formValidationService.validateFormData(formData, formSchema);
  }

  async getLeadWithDetails(leadId) {
    return this.leadService.getLeadWithDetails(leadId);
  }

  /**
   * Validate name match between form data and PPI client details
   * @param {Object} formData - Form data containing name
   * @param {Object} ppiResponse - PPI API response containing clientDetails
   * @param {number} threshold - Similarity threshold (default: 0.8)
   * @returns {Object} - Validation result with match details
   */
  validateNameMatch(formData, ppiResponse, threshold = 0.8) {
    try {
      const formName = formData.fullName || formData.name;
      const formNameKey = formData.fullName ? 'fullName' : 'name';
  
      if (!formName) {
        return {
          isValid: false,
          error: 'Name not found in form data',
          details: {
            formName: null,
            ppiName: null,
            mismatch: 100,
            threshold: Math.round((1 - threshold) * 100),
            mismatchThreshold: Math.round((1 - threshold) * 100),
            formNameKey: null,
            ppiNameKey: null
          }
        };
      }
  
      const clientDetails = ppiResponse.clientDetails || [];
      const ppiNameEntry = clientDetails.find(
        detail => detail.key === 'agentName' || detail.key === 'shopName'
      );
  
      const ppiName = ppiNameEntry ? ppiNameEntry.value : null;
      const ppiNameKey = ppiNameEntry ? ppiNameEntry.key : null;
  
      if (!ppiName) {
        return {
          isValid: false,
          error: 'Name not found in PPI response',
          details: {
            formName,
            ppiName: null,
            mismatch: 100,
            threshold: Math.round((1 - threshold) * 100),
            mismatchThreshold: Math.round((1 - threshold) * 100),
            formNameKey,
            ppiNameKey: null
          }
        };
      }
  
      const similarity = nameMatchScore(formName, ppiName); // 0–1
      const mismatch = Math.round((1 - similarity) * 100);
      const thresholdPercent = Math.round((1 - threshold) * 100);
      const isValid = mismatch <= thresholdPercent;
  
      this.logger.info({
        ref: 'validateNameMatch',
        message: 'Name validation completed',
        formName,
        ppiName,
        mismatch,
        isValid,
        threshold: thresholdPercent
      });
  
      return {
        isValid,
        error: isValid ? null : `Name mismatch (${mismatch}%) is above threshold (${thresholdPercent}%)`,
        details: {
          formName,
          ppiName,
          mismatch,
          threshold: thresholdPercent,
          mismatchThreshold: thresholdPercent,
          formNameKey,
          ppiNameKey
        }
      };
    } catch (error) {
      this.logger.error({
        ref: 'validateNameMatch',
        message: 'Error during name validation',
        error
      });
  
      return {
        isValid: false,
        error: 'Error during name validation',
        details: {
          formName: formData.fullName || formData.name,
          ppiName: null,
          mismatch: 100,
          threshold: Math.round((1 - threshold) * 100),
          mismatchThreshold: Math.round((1 - threshold) * 100),
          formNameKey: formData.fullName ? 'fullName' : 'name',
          ppiNameKey: null
        }
      };
    }
  }
  

  /**
   * Fetch and validate client details from PPI API
   * @param {string} clientId - Client ID
   * @param {Object} formData - Form data for name validation
   * @param {number} threshold - Name similarity threshold (default: 0.8)
   * @returns {Promise<Object>} - PPI response with validation result
   */
  async fetchAndValidateClientDetails(clientId, formData, threshold = 0.8) {
    try {
      this.logger.info({
        ref: 'fetchAndValidateClientDetails',
        message: 'Fetching client details from PPI API',
        clientId
      });

      const payload = { clientId };
      const ppiResponse = await this.ppiRequest.fetchClientDetails(payload, clientId);
      const nameValidation = this.validateNameMatch(formData, ppiResponse, threshold);

      return {
        ppiResponse,
        nameValidation,
        isValid: nameValidation.isValid
      };
    } catch (error) {
      this.logger.error({
        ref: 'fetchAndValidateClientDetails',
        message: 'Error fetching or validating client details',
        error
      });
      
      throw error;
    }
  }

  /**
   * Fetch Alliance policy status for a given unique ID
   * @param {string} uniqueId - The application ID (e.g., SPMxxxxx)
   * @returns {Promise<Array>} - Array of successful policy status objects
   */
  async fetchAlliancePolicyStatus(uniqueId) {
    const ref = 'fetchAlliancePolicyStatus';
    try {
      const result = await this.statusRequest.getStatus(uniqueId);

      this.logger.info({
        ref,
        message: 'Fetched Alliance policy status successfully',
        uniqueId,
        policies: result.length
      });

      return result;
    } catch (error) {
      this.logger.error({ ref, message: 'Error fetching Alliance status', error });
      throw error;
    }
  }
}

module.exports = { ShopInsuranceService };
