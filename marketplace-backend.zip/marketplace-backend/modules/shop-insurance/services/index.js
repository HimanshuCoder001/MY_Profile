'use strict';
const { ShopInsuranceService } = require('./shop-insurance.service');

module.exports = {
  ShopInsuranceService
};
