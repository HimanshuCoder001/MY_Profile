'use strict';

const { ValidationUtil } = require('@utils');
const createShopInsuranceSchema = require('./schemas/create-shop-insurance.schema.json');

class ShopInsuranceValidation {
  /**
   * Validate create shop insurance schema using common validation utility
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   * @param {Function} next - Next middleware function
   * @returns {void}
   */
  static validateCreateShopInsurance(req, res, next) {
    return ValidationUtil.validateSchema(req, res, next, createShopInsuranceSchema, {
      errorFormat: 'structured',
      logScope: 'ShopInsuranceValidation'
    });
  }


}

module.exports = { ShopInsuranceValidation };
