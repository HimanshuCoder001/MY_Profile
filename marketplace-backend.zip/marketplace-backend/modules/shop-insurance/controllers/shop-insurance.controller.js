const { LoggerFactory } = require('@logger');
const { ShopInsuranceService } = require('../services');
const { WalletService } = require('../../wallet/services/wallet.service');
const { NotFoundException } = require('@exceptions');
const { v4: uuidv4 } = require('uuid');
const LeadModel = require('@odm/models/lead');
const StatusModel = require('@odm/models/status');
const Session = require('@odm/models/session');

class ShopInsuranceController {
    static instance = null;

    constructor() {
        this.shopInsuranceService = ShopInsuranceService.getInstance();
        this.logger = LoggerFactory.getLogger(ShopInsuranceController.name);
        this.walletService = new WalletService();
    }

    /**
     * Get instance of ShopInsuranceController
     * @returns {ShopInsuranceController} - Instance of ShopInsuranceController
     */
    static getInstance() {
        if (!ShopInsuranceController.instance) {
            ShopInsuranceController.instance = new ShopInsuranceController();
        }
        return ShopInsuranceController.instance;
    }

    /**
     * Create a new shop insurance with all details
     * @param {Object} req - The request object
     * @param {Object} res - The response object
     * @returns {Promise<Object>} - The response object
     */
    async createShopInsurance(req, res) {
        const ref = 'createShopInsurance';

        try {
            this.logger.info({ ref, message: 'Creating new shop insurance', data: req.body });

            const { clientId } = req.session;
            const { formData, ...shopInsuranceData } = req.body;

            const { formJson } = await this.shopInsuranceService.getFormByProductId(shopInsuranceData.productId);

            // Validate form data against schema
            if (formData && formJson) {
                const validationResult = this.shopInsuranceService.validateFormData(formData, formJson);

                if (!validationResult.isValid) {
                    this.logger.warn({
                        ref,
                        message: 'Form validation failed',
                        errors: validationResult.errors,
                        details: validationResult.details
                    });

                    return res.sendWrapped('Form validation failed', {
                        errors: validationResult.errors,
                        details: validationResult.details
                    }, 'Form validation failed', 400);
                }

                this.logger.info({
                    ref,
                    message: 'Form validation passed',
                    fieldCount: validationResult.fieldCount,
                    errorCount: validationResult.errorCount
                });
            }

            // Validate name match with PPI client details
            if (formData && clientId) {
                try {
                    const nameValidationResult = await this.shopInsuranceService.fetchAndValidateClientDetails(clientId, formData, 0.8);

                    if (!nameValidationResult.isValid) {
                        this.logger.warn({
                            ref,
                            message: 'Name validation failed',
                            details: nameValidationResult.nameValidation.details
                        });

                        // Log the detailed validation information
                        this.logger.warn({
                            ref,
                            message: 'Name validation failed - detailed information',
                            details: nameValidationResult.nameValidation.details
                        });

                        return res.sendWrapped('The insurer details not matching with the adhikari details in the system', {
                            title: 'Incorrect Details',
                            message: 'The insurer details not matching with the adhikari details in the system.',
                            note: 'This policy applies only to spice money adhikari shop.',
                            errorCode: 'NAME_MISMATCH',
                        });
                    }

                    this.logger.info({
                        ref,
                        message: 'Name validation passed',
                        mismatch: nameValidationResult.nameValidation.details.mismatch
                    });
                } catch (error) {
                    this.logger.error({
                        ref,
                        message: 'Error during name validation',
                        error
                    });

                    return res.sendWrapped('Name validation error', {
                        error: 'Failed to validate name with PPI system'
                    });
                }
            }

            const customerDetails = this.shopInsuranceService.extractCustomerDetailsFromFormData(formData, shopInsuranceData.customerDetails);
            const enrichedShopInsuranceData = {
                ...shopInsuranceData,
                clientId,
                applicationId: this.shopInsuranceService.generateApplicationNumber(),
                customerDetails
            };

            const result = await this.shopInsuranceService.createShopInsuranceWithDetails(enrichedShopInsuranceData);

            if (formData) {
                const formSubmissionData = {
                    applicationId: enrichedShopInsuranceData.applicationId,
                    clientId,
                    leadId: result.lead.leadId,
                    productId: shopInsuranceData.productId,
                    formId: uuidv4(),
                    formType: 'BASIC_DETAILS',
                    formKey: 'basic_details',
                    formVersion: 1,
                    formLocale: 'en',
                    data: formData,
                    redirectionUrl: result.lead.redirectionUrl,
                    metadata: {
                        source: 'shop_insurance_creation',
                        stepId: 'basic_details'
                    }
                };

                await this.shopInsuranceService.createFormSubmission(formSubmissionData, 'basic_details');
            }

            this.logger.info({ ref, message: 'Shop insurance created successfully', leadId: result.lead.leadId });

            // Check wallet balance
            this.logger.info({ ref, message: 'Initiating balance check' });
            let walletBalance;
            try {
                walletBalance = await this.walletService.checkWalletBalance(clientId, uuidv4());
                this.logger.info({ ref, message: 'Balance check successful', walletBalanceResponse: walletBalance });
            } catch (error) {
                this.logger.error({ ref, message: error.message, stack: error.stack });
                return res.sendWrapped('Insufficient Wallet Balance', {
                    title: 'Insufficient Wallet Balance',
                    message: 'Your wallet balance is insufficient to proceed with the policy purchase.',
                    note: 'Please recharge your wallet and try again.',
                    errorCode: 'WALLET_BALANCE_INSUFFICIENT',
                    walletBalance: walletBalance,
                    stack: error.stack
                });
            }

            return res.sendWrapped(null, {
                leadId: result.lead.leadId,
                applicationId: result.lead.applicationId,
                leadType: result.lead.leadType,
                leadStatus: result.lead.leadStatus,
                flowType: result.lead.flowType,
                redirectionUrl: result.lead.redirectionUrl,
                isRedirection: result.lead.isRedirection,
                walletBalance: walletBalance
            }, 'Shop insurance created successfully');
        } catch (error) {
            this.logger.error({ ref, message: 'Error creating shop insurance', error });
            return res.sendWrapped(error);
        }
    }

    /**
     * Get shop insurance with all details
     * @param {Object} req - The request object
     * @param {Object} res - The response object
     * @returns {Promise<Object>} - The response object
     */
    async getShopInsuranceWithDetails(req, res) {
        try {
            const { leadId } = req.params;
            const leadData = await this.shopInsuranceService.getLeadWithDetails(leadId);
            if (!leadData) throw new NotFoundException('Shop insurance not found', 'SHOP_INSURANCE_NOT_FOUND');

            return res.sendWrapped(null, leadData, 'Shop insurance details retrieved successfully');
        } catch (error) {
            this.logger.error({ ref: 'Error getting shop insurance details', error });
            return res.sendWrapped(error);
        }
    }

    /**
     * Fetch policy status from Alliance API
     * @param {Object} req - The request object
     * @param {Object} res - The response object
     * @returns {Promise<Object>} - The response with status details
     */
    async getAllianceStatus(req, res) {
        try {
            this.logger.info({ ref: 'get alliance status', data: req.session });
            const { clientId } = req.session;

            if (!clientId) {
                return res.sendWrapped('Client not found', null, 'Bad Request', 400);
            }

            // Get the latest lead for the client
            const leadDetails = await LeadModel.findOne({ clientId }, 'applicationId clientId customerDetails redirectionUrl')
                .sort({ createdAt: -1 }).lean();

            if (!leadDetails || !leadDetails.redirectionUrl) {
                return res.sendWrapped('Lead not found or missing redirection URL', null, 'Not Found', 404);
            }

            // Get the latest status for the client
            const statusResult = await StatusModel.findOne({ clientId, status: 'success' }, 'statusResponse').sort({ createdAt: -1 }).lean();
            if (statusResult?.statusResponse?.[0]?.coi_url) {
                return res.sendWrapped(null, statusResult?.statusResponse, 'Existing policy status fetched successfully');
            }

            // Parse uniqueId from redirectionUrl query param `utm_uniqueid`
            const url = new URL(leadDetails.redirectionUrl);
            const uniqueId = url.searchParams.get('utm_uniqueid');

            if (!uniqueId) {
                return res.sendWrapped('uniqueId not found in redirection URL', null, 'Bad Data', 400);
            }

            this.logger.info({ ref: 'get alliance status fetching policy status from Alliance', uniqueId });
            const result = await this.shopInsuranceService.fetchAlliancePolicyStatus(uniqueId);

            await StatusModel.create({
                clientId,
                statusResponse: result,
                status: 'success'
            });

            if (!result || result.length === 0) {
                return res.sendWrapped('No successful policy found', null, 'Policy status not successful', 404);
            }

            return res.sendWrapped(null, result, 'Policy status fetched successfully');
        } catch (error) {
            this.logger.error({ ref: 'get alliance status error fetching Alliance status', error });
            return res.sendWrapped(error, null, 'Failed to fetch policy status');
        }
    }

    /**
     * Fetch all policy status from Alliance API
     * @param {Object} req - The request object
     * @param {Object} res - The response object
     * @returns {Promise<Object>} - The response with status details
     */
    async updateAllAllianceStatusLogs() {
        const ref = 'updateAllAllianceStatusLogs';

        try {
            const sevenDaysAgo = new Date();
            sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);

            // Step 1: Fetch distinct clientIds from leads
            const allClientIds = await LeadModel.distinct('clientId', {
                leadCategory: 'INSURANCE',
                leadType: 'SHOP_INSURANCE',
                isRedirection: true,
                createdAt: { $gte: sevenDaysAgo }
            });

            this.logger.info({ ref, message: `Found ${allClientIds.length} clientIds from leads` });

            // Step 2: Check which clientIds already have successful status
            const successfulStatusDocs = await StatusModel.find({
                clientId: { $in: allClientIds },
                status: 'success'
            }).distinct('clientId');

            const clientIdsToProcess = allClientIds.filter(id => !successfulStatusDocs.includes(id));

            this.logger.info({
                ref,
                message: `Skipping ${successfulStatusDocs.length} clientIds with existing success status`,
                toProcess: clientIdsToProcess.length
            });

            // Step 3: Process remaining clientIds
            for (const clientId of clientIdsToProcess) {
                try {
                    const leadDetails = await LeadModel.findOne(
                        { clientId, isRedirection: true },
                        'redirectionUrl'
                    ).sort({ createdAt: -1 }).lean();

                    if (!leadDetails || !leadDetails.redirectionUrl) {
                        await StatusModel.create({
                            clientId,
                            statusResponse: 'Lead not found or missing redirection URL',
                            status: 'failed'
                        });
                        this.logger.warn({ ref, clientId, message: 'Lead missing or redirectionUrl missing' });
                        continue;
                    }

                    const url = new URL(leadDetails.redirectionUrl);
                    const uniqueId = url.searchParams.get('utm_uniqueid');

                    if (!uniqueId) {
                        await StatusModel.create({
                            clientId,
                            statusResponse: 'utm_uniqueid not found in redirection URL',
                            status: 'failed'
                        });
                        this.logger.warn({ ref, clientId, message: 'utm_uniqueid not found in redirection URL' });
                        continue;
                    }

                    this.logger.info({ ref, clientId, message: 'Fetching policy status from Alliance', uniqueId });

                    const result = await this.shopInsuranceService.fetchAlliancePolicyStatus(uniqueId);

                    await StatusModel.create({
                        clientId,
                        statusResponse: result,
                        status: 'success'
                    });

                    this.logger.info({ ref, clientId, message: 'Policy status fetched and stored successfully' });

                } catch (error) {
                    await StatusModel.create({
                        clientId,
                        statusResponse: error?.message || error,
                        status: 'error'
                    });
                    this.logger.error({ ref, clientId, message: 'Error while processing clientId', error });
                }
            }

            this.logger.info({ ref, message: 'Alliance policy status update job completed' });

        } catch (error) {
            this.logger.error({ ref, message: 'Failed to run Alliance status update job', error });
        }
    }
}

module.exports = { ShopInsuranceController };
