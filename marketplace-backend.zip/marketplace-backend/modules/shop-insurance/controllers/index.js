'use strict';
const { ShopInsuranceController } = require('./shop-insurance.controller');

module.exports = {
  ShopInsuranceController
};
