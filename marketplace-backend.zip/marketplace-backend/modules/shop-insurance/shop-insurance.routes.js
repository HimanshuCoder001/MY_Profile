'use strict';

const { ShopInsuranceController } = require('./controllers');
const { ShopInsuranceValidation } = require('./validation/shop-insurance.validation');

const shopInsuranceController = ShopInsuranceController.getInstance();

module.exports = (router) => {
    
    router.post('/create-lead', 
        ShopInsuranceValidation.validateCreateShopInsurance,
        shopInsuranceController.createShopInsurance.bind(shopInsuranceController)
    );

    router.get('/status',
        shopInsuranceController.getAllianceStatus.bind(shopInsuranceController)
    );

    // Route to trigger status log update (cron-safe)
    router.get('/cron/update-all-status-logs',
        async (req, res) => {
            try {
                // Fire and forget — no await, to prevent blocking
                shopInsuranceController.updateAllAllianceStatusLogs();
                res.sendWrapped(null, 'Triggered update of all alliance status logs', 'Job started');
            } catch (error) {
                res.sendWrapped(error, null, 'Failed to start alliance status update');
            }
        }
    );

    router.get('/:leadId',
        shopInsuranceController.getShopInsuranceWithDetails.bind(shopInsuranceController)
    );    
};
