'use strict';

const { ValidationUtil } = require('@utils');
const {
  getProductListSchema,
} = require('./schemas');

class BankSathiValidation {
  /**
   * Validate product list schema using common validation utility
   * @param {Object} req - Request object
   * @param {Object} res - Response object
   * @param {Function} next - Next middleware function
   * @returns {void}
   */
  static validateGetProductListSchema(req, res, next) {
    return ValidationUtil.validateSchema(req, res, next, getProductListSchema, {
      errorFormat: 'simple',
      logScope: 'BankSathiValidation'
    });
  }
}

module.exports = { BankSathiValidation };