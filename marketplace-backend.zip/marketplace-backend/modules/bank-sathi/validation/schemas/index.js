const getProductListSchema = require('./get-product-list.json');

module.exports = {
  getProductListSchema,
};