'use strict';

const { LoggerFactory } = require('@logger');
const { BankSathiRequest } = require('../request/bank-sathi.request');
const BankSathiModel = require('@odm/models/bankSathi');
const { ALLOWED_PRODUCT_IDS } = require('@utils');

class BankSathiController {
  static instance = null;

  constructor() {
    this.logger = LoggerFactory.getLogger(BankSathiController.name);
    this.bankSathiRequest = BankSathiRequest.make();
  }

  /**
   * Get the singleton instance of the BankSathiController
   * @returns {BankSathiController}
   */
  static getInstance() {
    if (!BankSathiController.instance) {
      BankSathiController.instance = new BankSathiController();
    }
    return BankSathiController.instance;
  }

  /**
   * Get all category products
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async getAllCategoryProducts(req, res) {
    try {
      const { category_id: categoryId } = req.body;

      const response = await this.bankSathiRequest.getBankSathiProducts(categoryId);
      this.logger.info({ ref: "get all category products response", data: response });

      return res.sendWrapped(null, response);
    } catch (error) {
      this.logger.error({ ref: "get all category products error", error });
      return res.sendWrapped(error);
    }
  };

  /**
   * Get product list
   * @param {Object} req - The request object
   * @param {Object} res - The response object
   * @returns {Promise<Object>} - The response object
   */
  async getProductList(req, res) {

    try {
      const { categoryId, pan, mobile, requiredLoanAmount } = req.body;

      /** Chekck if customer is exist or not in Bank sathi */
      const customerDetails = await this.bankSathiRequest.checkCustomerExist({
        isUserValidated: 1,
        mobileNo: mobile,
        categoryId: categoryId,
        pan: pan,
      });

      this.logger.info({ ref: "check customer exist response", data: customerDetails });
      if (!customerDetails?.status) {
        return res.sendWrapped(true, customerDetails);
      }

      /** Retrieve eligible product list from Bank sathi endpoint */
      const response = await this.bankSathiRequest.getBankSathiProducts({
        category_id: categoryId,
        customer_id: customerDetails?.data?.profile_details?.customer_id,
      });

      this.logger.info("getProductList response", JSON.stringify(response));
      if (!response.status) {
        return res.sendWrapped(true, response);
      }
      /** Retrieve static data like lender_description */
      const staticData = await BankSathiModel.find({ categoryId });

      /** Sync the response */
      let syncResponse = await Promise.all(response?.data?.eligible_product_list?.map(
        async (product) => {
          const productId = product.product_id || product.productId || product.id;

          /** Retrieve the static data by product id */
          const isProductExist = staticData.find(
            (d) => d.productId === productId,
          );

          /** Retrieve the redirection url per product id */
          const leadRequest = {
            category_id: categoryId,
            product_id: productId,
            customer_id: customerDetails?.data?.profile_details?.customer_id,
            required_amount: requiredLoanAmount,
          };

          const leadResponse = await this.bankSathiRequest.createLead(leadRequest);
          if (!leadResponse.status) {
            this.logger.info({ ref: 'create lead error', data: leadResponse });
          }

          /** Exclude the restricted products */
          if (ALLOWED_PRODUCT_IDS.includes(productId) && leadResponse?.data?.campaign_url && leadResponse?.data?.lead_code) {
            return {
              lender_id: `SMBS${categoryId}${productId}`,
              product_id: productId,
              category_id: Number(categoryId),
              customer_id: customerDetails?.data?.profile_details?.customer_id,
              redirection: {
                description: 'Apply Now',
                logo: isProductExist?.logo,
                lender_code: product.title || product.cardName,
                lender_lead_code: leadResponse?.data?.lead_code,
                redirection_link: leadResponse?.data?.campaign_url,
                annual_charges: product.annualCharges || 0,
                joining_fees: product.joiningFees || 0,
                main_benefits: product?.mainBenefits,
                benefits: product?.benefits,
                lender_description: isProductExist?.lender_description || [],
                lender_additional_details: isProductExist?.lender_additional_details || [],
              },
            };
          }
        },
      ));
      syncResponse = syncResponse.filter((item) => item);
      return res.sendWrapped(null, syncResponse);
    } catch (error) {
      this.logger.error({ ref: "get product list error", error });
      return res.sendWrapped(error);
    }
  };
}



module.exports = { BankSathiController };
