const { BankSathiController } = require('./bank-sathi.controller');

module.exports = {
    BankSathiController,
};