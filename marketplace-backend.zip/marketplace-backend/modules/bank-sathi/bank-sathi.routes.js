'use strict';

const { BankSathiController } = require('./controllers');
const { BankSathiValidation } = require('./validation/bank-sathi.validation');

const bankSathiController = BankSathiController.getInstance();

module.exports = (router) => {
    router.get('/get-all-category-products', (req, res) => bankSathiController.getAllCategoryProducts(req, res));
    router.post('/get-product-list', BankSathiValidation.validateGetProductListSchema, (req, res) => bankSathiController.getProductList(req, res));
}