'use strict';

const config = require('config');
const { BaseRequest } = require('@request');
const { LoggerFactory } = require('@logger');

class BankSathiRequest {

    constructor() {
        this.baseRequest = BaseRequest.make();
        this.bankSathiConfig = config.get('bankSathi');
        this.logger = LoggerFactory.getLogger(BankSathiRequest.name);
    }

    /**
     * Make a new instance of BankSathiRequest
     * @returns {BankSathiRequest}
     */
    static make() {
        return new BankSathiRequest();
    }

    /**
     * Get Bank Sathi products
     * @param {Object} payload - The payload for the request
     * @returns {Promise<Object>} - The response from the request
     */
    async getBankSathiProducts(categoryId) {
        try {
            const { host, port, protocol, endpoints, headers } = this.bankSathiConfig;

            const config = {
                host,
                port,
                protocol,
                headers,
                method: endpoints.get_product_by_category.method || 'POST',
                url: endpoints.get_product_by_category.url,
            };

            return await this.baseRequest.handle(config, {}, undefined, undefined, undefined, { query: { category_id: categoryId } });
        } catch (error) {
            this.logger.error({ ref: 'get Bank Sathi products request error', error });
            throw error;
        }
    }

    /**
     * Check if customer exists
     * @param {Object} payload - The payload for the request
     * @returns {Promise<Object>} - The response from the request
     */
    async checkCustomerExist(payload) {
        try {
            const { host, port, protocol, endpoints, headers } = this.bankSathiConfig;

            const config = {
                host,
                port,
                protocol,
                headers,
                method: endpoints.check_customer_exist.method || 'GET',
                url: endpoints.check_customer_exist.url,
            };

            return await this.baseRequest.handle(config, {}, undefined, undefined, undefined, { query: payload });
        } catch (error) {
            this.logger.error({ ref: 'check customer exist request error', error });
            throw error;
        }
    }

    /**
     * Validate OTP
     * @param {Object} payload - The payload for the request
     * @returns {Promise<Object>} - The response from the request
     */
    async validateOtp(payload) {
        try {
            const { host, port, protocol, endpoints, headers } = this.bankSathiConfig;

            const config = {
                host,
                port,
                protocol,
                headers,
                method: endpoints.validate_otp.method || 'POST',
                url: endpoints.validate_otp.url,
            };

            return await this.baseRequest.handle(config, payload);
        } catch (error) {
            this.logger.error({ ref: 'validate OTP request error', error });
            throw error;
        }
    }

    /**
     * Create a lead
     * @param {Object} payload - The payload for the request
     * @returns {Promise<Object>} - The response from the request
     */
    async createLead(payload) {
        try {
            const { host, port, protocol, endpoints, headers } = this.bankSathiConfig;

            const config = {
                host,
                port,
                protocol,
                headers,
                method: endpoints.create_lead.method || 'POST',
                url: endpoints.create_lead.url,
            };

            return await this.baseRequest.handle(config, payload);
        } catch (error) {
            this.logger.error({ ref: 'create lead request error', error });
            throw error;
        }
    }

    /**
     * Get lead status
     * @param {Object} payload - The payload for the request
     * @returns {Promise<Object>} - The response from the request
     */
    async getLeadStatus(payload) {
        try {
            const { host, port, protocol, endpoints, headers } = this.bankSathiConfig;

            const config = {
                host,
                port,
                protocol,
                headers,
                method: endpoints.get_lead_status.method || 'GET',
                url: endpoints.get_lead_status.url,
            };

            return await this.baseRequest.handle(config, payload);
        } catch (error) {
            this.logger.error({ ref: 'get lead status request error', error });
            throw error;
        }
    }
}

module.exports = { BankSathiRequest };