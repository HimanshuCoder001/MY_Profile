const bankSRoutes = require('./bank-sathi/bank-sathi.routes');
const dmsRoutes = require('./dms/dms.routes');
const grahakLoanRoutes = require('./grahak-loan/grahak-loan.routes');
const productTileRoutes = require('./product-tile/product-tile.routes');
const walletRoutes = require('./wallet/wallet.routes');
const sessionRoutes = require('./session/session.route');
const shopInsuranceRoutes = require('./shop-insurance/shop-insurance.routes');

module.exports = {
    bankSRoutes,
    dmsRoutes,
    grahakLoanRoutes,
    productTileRoutes,
    walletRoutes,
    sessionRoutes,
    shopInsuranceRoutes
}