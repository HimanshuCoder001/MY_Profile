#!/bin/bash
. ~/.bash_profile

# Get Node.js version
NODE_VERSION=$(node -v)

echo "Your Node.js version is: $NODE_VERSION"

# Ensure script is always executed with bash
if [ -z "$BASH_VERSION" ]; then
  exec /bin/bash "$0" "$@"
fi

#
# Alliance Report Generator – Production Script
#
# This script:
#   1. Connects to MongoDB
#   2. Extracts "debit" and "status" data from the last 30 days
#   3. Flattens the documents and exports them to CSV
#   4. Emails the CSV files to recipients
#
# Requirements:
#   npm install mongoose nodemailer json2csv flat
#
# Usage:
#   ./alliance-emails.sh
#

# Step into script directory to resolve relative paths correctly
cd "$(dirname "$0")"

# Run inline Node.js script
node <<'EOF'
const mongoose = require('mongoose');
const nodemailer = require('nodemailer');
const { Parser } = require('json2csv');
const fs = require('fs');
const path = require('path');

(async () => {
  // Import ESM-only library "flat" dynamically
  const { flatten } = await import('flat'); 

  // MongoDB connection string
  // NOTE: replace with secured credentials or environment variables in production
  // const mongoUri = 'mongodb://app_marketplace:BrQkdq5DjS4Q5mfR@127.0.0.1:50003/?authSource=marketplace';
  const mongoUri = 'mongodb://app_marketplace:Pidb398gfdbv02%236gfb2iBX@192.168.145.207:27017/?authMechanism=DEFAULT&authSource=db_marketplace';

  // Extract DB name from authSource param
  const parsed = new URL(mongoUri);
  const authSource = parsed.searchParams.get('authSource') || 'admin';

  // Establish MongoDB connection
  await mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true });
  const marketplace = mongoose.connection.useDb(authSource);

  // -----------------------
  // Define MongoDB Schemas
  // -----------------------

  const debitSchema = new mongoose.Schema({
    clientId: { type: String, required: true },
    sessionId: String,
    requestType: String,
    requestPayload: mongoose.Schema.Types.Mixed,
    debitResponse: mongoose.Schema.Types.Mixed,
    updateResponse: mongoose.Schema.Types.Mixed,
    requestId: String,
    walletRequestId: String,
    status: String,
  }, { timestamps: true });

  const statusSchema = new mongoose.Schema({
    clientId: { type: String, required: true },
    statusResponse: mongoose.Schema.Types.Mixed,
    status: String,
  }, { timestamps: true });

  const debitModel = marketplace.model('debit', debitSchema);
  const statusModel = marketplace.model('status', statusSchema);

  // -----------------------
  // Query data (last 30 days)
  // -----------------------
  const date30daysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
  const debitData = await debitModel.find({ createdAt: { $gte: date30daysAgo } }).lean();
  const statusData = await statusModel.find({ createdAt: { $gte: date30daysAgo } }).lean();

  // -----------------------
  // Email setup
  // -----------------------
  const emailRecipients = ['diksha.kewat@spicemoney.com', 'nitin.jha@spicemoney.com', 'vishal.sajwan@spicemoney.com', 'kshitij.sharma@spicemoney.com','susheel.kumar@spicemoney.com', 'kamal.saini@spicemoney.com'];

  const sendEmail = async (subject, csvPath, filename) => {
    const transporter = nodemailer.createTransport({
      host: "smtp.gmail.com",
      port: 587,
      secure: false,
      auth: {
        user: "no-reply@spicemoney.com",
        pass: "altdplonkayhhlxr" // ⚠️ Store in env var in prod
      }
    });

    console.log(subject);
    const info = await transporter.sendMail({
      from: '"SpiceMoney" <no-reply@spicemoney.com>',
      to: emailRecipients.join(','),
      subject,
      text: "Please find the attached CSV report for the last 30 days.",
      attachments: [{ filename, path: csvPath }]
    });

    console.log(`Email sent: ${info.messageId}`);
  };

  // -----------------------
  // Data processing helper
  // -----------------------
  const processAndSend = async (data, label) => {
    if (data.length === 0) {
      console.log(`No ${label} data found in last 30 days.`);
      return;
    }

    // Flatten nested objects
    const flattened = data.map(d => flatten(d, { safe: true }));

    // Convert to CSV
    const parser = new Parser();
    const csv = parser.parse(flattened);

    // Save CSV file locally
    const filename = `${label}_${Date.now()}.csv`;
    const filePath = path.join(__dirname, filename);
    fs.writeFileSync(filePath, csv);

    // Send via email
    await sendEmail(`[Shopkeeper Insurance Report - Alliance] ${label} data - Last 30 Days`, filePath, filename);

    // Clean up file
    fs.unlinkSync(filePath);
  };

  // Process both debit & status collections
  await processAndSend(debitData, 'debit');
  await processAndSend(statusData, 'status');

  // Close DB connection
  mongoose.connection.close();
})();
EOF
