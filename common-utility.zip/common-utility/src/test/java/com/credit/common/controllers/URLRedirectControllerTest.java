package com.credit.common.controllers;


import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Profile;
import org.springframework.test.web.reactive.server.WebTestClient;

import com.credit.common.entities.UrlCache;
import com.credit.common.service.URLShorteningService;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@Profile("uat")
class URLRedirectControllerTest {

    @Autowired
    private WebTestClient client;

    @MockBean
    private URLShorteningService service;

    URLRedirectControllerTest() {

    }

    @Test
    public void redirect_ShortUrlFound_ShouldReturn302Found() {
        UrlCache url = new UrlCache();
        url.setUrl("https://example.com");
        Optional<UrlCache> optional = Optional.of(url);
        when(service.findByShortUrl("abc123")).thenReturn(optional);

        client.get().uri("/r/abc123")
                .exchange()
                .expectStatus().isFound()
                .expectHeader().valueEquals("Location", "https://example.com");
    }

    @Test
    public void redirect_ShortUrlNotFound_ShouldReturn404NotFound() {
        when(service.findByShortUrl("abc123")).thenReturn(Optional.empty());

        client.get().uri("/r/abc123")
                .exchange()
                .expectStatus().isNotFound();
    }
}
