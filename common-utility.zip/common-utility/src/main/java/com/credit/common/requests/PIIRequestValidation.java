package com.credit.common.requests;

import lombok.Getter;
import lombok.Setter;

import jakarta.validation.constraints.NotBlank;

@Getter
@Setter
public class PIIRequestValidation {


    @NotBlank
    private String pan;

    @NotBlank
    private String mobile;

    private String email;


}
