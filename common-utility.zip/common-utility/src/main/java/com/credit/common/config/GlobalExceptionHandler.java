package com.credit.common.config;

import java.util.HashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.servlet.NoHandlerFoundException;

import com.credit.common.entities.URLNotFoundException;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.ConstraintViolation;
import jakarta.validation.ConstraintViolationException;

/**
 * Global Exception Handler for REST API error handling.
 * Provides centralized exception handling with consistent error response format.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    /**
     * Handle validation errors from @Valid annotations.
     */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidationExceptions(
            MethodArgumentNotValidException ex, HttpServletRequest request) {
        
        Map<String, Object> errorResponse = createBaseErrorResponse(request, "VALIDATION_ERROR", 
                "Validation failed", HttpStatus.BAD_REQUEST);
        
        Map<String, String> fieldErrors = new HashMap<>();
        ex.getBindingResult().getAllErrors().forEach((error) -> {
            String fieldName = ((FieldError) error).getField();
            String errorMessage = error.getDefaultMessage();
            fieldErrors.put(fieldName, errorMessage);
        });
        
        errorResponse.put("fieldErrors", fieldErrors);
        return ResponseEntity.badRequest().body(errorResponse);
    }

    /**
     * Handle constraint violation exceptions.
     */
    @ExceptionHandler(ConstraintViolationException.class)
    public ResponseEntity<Map<String, Object>> handleConstraintViolation(
            ConstraintViolationException ex, HttpServletRequest request) {
        
        Map<String, Object> errorResponse = createBaseErrorResponse(request, "VALIDATION_ERROR", 
                "Constraint violation", HttpStatus.BAD_REQUEST);
        
        Map<String, String> violations = new HashMap<>();
        for (ConstraintViolation<?> violation : ex.getConstraintViolations()) {
            violations.put(violation.getPropertyPath().toString(), violation.getMessage());
        }
        
        errorResponse.put("violations", violations);
        return ResponseEntity.badRequest().body(errorResponse);
    }

    /**
     * Handle URL not found exceptions.
     */
    @ExceptionHandler(URLNotFoundException.class)
    public ResponseEntity<Map<String, Object>> handleURLNotFoundException(
            URLNotFoundException ex, HttpServletRequest request) {
        
        Map<String, Object> errorResponse = createBaseErrorResponse(request, "NOT_FOUND", 
                ex.getMessage(), HttpStatus.NOT_FOUND);
        
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
    }

    /**
     * Handle method argument type mismatch exceptions.
     */
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<Map<String, Object>> handleMethodArgumentTypeMismatch(
            MethodArgumentTypeMismatchException ex, HttpServletRequest request) {
        
        String message = String.format("Parameter '%s' should be of type %s", 
                ex.getName(), ex.getRequiredType().getSimpleName());
        
        Map<String, Object> errorResponse = createBaseErrorResponse(request, "INVALID_PARAMETER", 
                message, HttpStatus.BAD_REQUEST);
        
        return ResponseEntity.badRequest().body(errorResponse);
    }

    /**
     * Handle HTTP message not readable exceptions.
     */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> handleHttpMessageNotReadable(
            HttpMessageNotReadableException ex, HttpServletRequest request) {
        
        Map<String, Object> errorResponse = createBaseErrorResponse(request, "INVALID_REQUEST_BODY", 
                "Invalid request body format", HttpStatus.BAD_REQUEST);
        
        return ResponseEntity.badRequest().body(errorResponse);
    }

    /**
     * Handle no handler found exceptions (404).
     */
    @ExceptionHandler(NoHandlerFoundException.class)
    public ResponseEntity<Map<String, Object>> handleNoHandlerFound(
            NoHandlerFoundException ex, HttpServletRequest request) {
        
        String message = String.format("No handler found for %s %s", 
                ex.getHttpMethod(), ex.getRequestURL());
        
        Map<String, Object> errorResponse = createBaseErrorResponse(request, "NOT_FOUND", 
                message, HttpStatus.NOT_FOUND);
        
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
    }

    /**
     * Handle all other exceptions (500).
     */
    @ExceptionHandler(Exception.class)
    public ResponseEntity<Map<String, Object>> handleGenericException(
            Exception ex, HttpServletRequest request) {
        
        Map<String, Object> errorResponse = createBaseErrorResponse(request, "INTERNAL_ERROR", 
                "An unexpected error occurred", HttpStatus.INTERNAL_SERVER_ERROR);
        
        // Include stack trace only in development
        if (isDevelopmentProfile()) {
            errorResponse.put("stackTrace", ex.getStackTrace());
        }
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
    }

    /**
     * Create a base error response with consistent format.
     */
    private Map<String, Object> createBaseErrorResponse(HttpServletRequest request, 
            String errorType, String message, HttpStatus status) {
        
        Map<String, Object> errorResponse = new HashMap<>();
        errorResponse.put("success", false);
        errorResponse.put("error", errorType);
        errorResponse.put("message", message);
        errorResponse.put("status", status.value());
        errorResponse.put("path", request.getRequestURI());
        errorResponse.put("method", request.getMethod());
        errorResponse.put("timestamp", System.currentTimeMillis());
        errorResponse.put("application", "Common Utility API");
        
        return errorResponse;
    }

    /**
     * Check if the application is running in development profile.
     */
    private boolean isDevelopmentProfile() {
        String activeProfile = System.getProperty("spring.profiles.active", "");
        return activeProfile.contains("dev") || activeProfile.contains("development") || activeProfile.contains("uat");
    }
} 