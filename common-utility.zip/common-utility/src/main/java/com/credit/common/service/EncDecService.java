package com.credit.common.service;

import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.credit.common.util.KeyDerivationUtil;
import com.google.gson.Gson;

@Component
public class EncDecService {

    @Autowired
    Gson gson;

    @Value("${enc.salt}")
    String salt;

    @Value("${enc.password}")
    String password;

    int iterationCount = 100; // Should be higher in production systems
    int keyLength = 256;

    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/CFB/PKCS5Padding";

    public String encryption(final String dataForEncryption) {
        try {
            if (dataForEncryption == null || dataForEncryption.isEmpty()) return "";
            SecretKey secretKey = KeyDerivationUtil.deriveAESKey(password, salt, iterationCount, keyLength);
            
            // Use a fixed IV for consistency
            byte[] fixedIV = new byte[16];
            Arrays.fill(fixedIV, (byte) 0); // You can choose a different strategy for creating a fixed IV
            
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, secretKey, new IvParameterSpec(fixedIV));
            
            byte[] encryptedBytes = cipher.doFinal(dataForEncryption.getBytes(StandardCharsets.UTF_8));

            return Base64.getEncoder().encodeToString(encryptedBytes);
        } catch (Exception ex) {
            ex.printStackTrace();
            return "";
        }
    }

    public String decryption(final String dataForDecryption) {
        try {
            if (dataForDecryption == null || dataForDecryption.isEmpty()) return "";
            SecretKey secretKey = KeyDerivationUtil.deriveAESKey(password, salt, iterationCount, keyLength);

            // Use the same fixed IV for consistency
            byte[] fixedIV = new byte[16];
            Arrays.fill(fixedIV, (byte) 0); // Use the same strategy as in the encryption method

            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, secretKey, new IvParameterSpec(fixedIV));

            byte[] encryptedBytes = Base64.getDecoder().decode(dataForDecryption);
            byte[] decryptedBytes = cipher.doFinal(encryptedBytes);

            return new String(decryptedBytes, StandardCharsets.UTF_8);
        } catch (Exception ex) {
            ex.printStackTrace();
            return "";
        }
    }

}
