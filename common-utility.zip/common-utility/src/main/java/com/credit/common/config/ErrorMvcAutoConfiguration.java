package com.credit.common.config;

import java.util.Map;

import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.condition.SearchStrategy;
import org.springframework.boot.web.servlet.error.DefaultErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorAttributes;
import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.boot.web.error.ErrorAttributeOptions;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

import jakarta.servlet.http.HttpServletRequest;

/**
 * Custom Error MVC Auto Configuration for REST API error handling.
 * This configuration provides custom error responses for REST APIs only.
 */
@Configuration
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnProperty(prefix = "server.error", name = "enabled", matchIfMissing = true)
public class ErrorMvcAutoConfiguration {

    /**
     * Custom Error Attributes that provide detailed error information for REST APIs.
     */
    @Bean
    @Primary
    @ConditionalOnMissingBean(value = ErrorAttributes.class, search = SearchStrategy.CURRENT)
    public ErrorAttributes errorAttributes() {
        return new CustomErrorAttributes();
    }

    /**
     * Custom Error Controller that handles REST API error responses.
     */
    @Bean
    @ConditionalOnMissingBean(value = ErrorController.class, search = SearchStrategy.CURRENT)
    public CustomErrorController customErrorController(ErrorAttributes errorAttributes) {
        return new CustomErrorController(errorAttributes);
    }

    /**
     * Custom Error Attributes implementation for REST APIs.
     */
    public static class CustomErrorAttributes extends DefaultErrorAttributes {

        @Override
        public Map<String, Object> getErrorAttributes(WebRequest webRequest, ErrorAttributeOptions options) {
            Map<String, Object> errorAttributes = super.getErrorAttributes(webRequest, options);
            
            // Add custom error information for REST API
            errorAttributes.put("application", "Common Utility API");
            errorAttributes.put("timestamp", System.currentTimeMillis());
            errorAttributes.put("success", false);
            
            // Customize error messages based on status code
            Integer status = (Integer) errorAttributes.get("status");
            if (status != null) {
                switch (status) {
                    case 400:
                        errorAttributes.put("message", "Bad Request - Invalid input parameters");
                        errorAttributes.put("error", "VALIDATION_ERROR");
                        break;
                    case 401:
                        errorAttributes.put("message", "Unauthorized - Authentication required");
                        errorAttributes.put("error", "AUTHENTICATION_ERROR");
                        break;
                    case 403:
                        errorAttributes.put("message", "Forbidden - Access denied");
                        errorAttributes.put("error", "AUTHORIZATION_ERROR");
                        break;
                    case 404:
                        errorAttributes.put("message", "Resource not found");
                        errorAttributes.put("error", "NOT_FOUND");
                        break;
                    case 405:
                        errorAttributes.put("message", "Method not allowed");
                        errorAttributes.put("error", "METHOD_NOT_ALLOWED");
                        break;
                    case 409:
                        errorAttributes.put("message", "Conflict - Resource already exists");
                        errorAttributes.put("error", "CONFLICT");
                        break;
                    case 422:
                        errorAttributes.put("message", "Unprocessable Entity - Invalid request data");
                        errorAttributes.put("error", "VALIDATION_ERROR");
                        break;
                    case 500:
                        errorAttributes.put("message", "Internal server error");
                        errorAttributes.put("error", "INTERNAL_ERROR");
                        break;
                    case 503:
                        errorAttributes.put("message", "Service unavailable");
                        errorAttributes.put("error", "SERVICE_UNAVAILABLE");
                        break;
                    default:
                        errorAttributes.put("message", "An error occurred");
                        errorAttributes.put("error", "GENERAL_ERROR");
                        break;
                }
            }
            
            // Remove sensitive information in production
            if (!options.isIncluded(ErrorAttributeOptions.Include.STACK_TRACE)) {
                errorAttributes.remove("trace");
            }
            
            return errorAttributes;
        }

        @Override
        public Throwable getError(WebRequest webRequest) {
            Throwable error = super.getError(webRequest);
            
            // Log error details for debugging (consider using proper logging framework)
            if (error != null) {
                System.err.println("REST API Error occurred: " + error.getMessage());
                // In production, use proper logging instead of printStackTrace
                if (System.getProperty("spring.profiles.active", "").contains("dev")) {
                    error.printStackTrace();
                }
            }
            
            return error;
        }
    }

    /**
     * Custom Error Controller implementation for REST APIs.
     */
    @Controller
    @RequestMapping("${server.error.path:${error.path:/error}}")
    public static class CustomErrorController implements ErrorController {

        private final ErrorAttributes errorAttributes;

        public CustomErrorController(ErrorAttributes errorAttributes) {
            this.errorAttributes = errorAttributes;
        }

        @RequestMapping
        @ResponseBody
        public ResponseEntity<Map<String, Object>> error(HttpServletRequest request) {
            Map<String, Object> body = getErrorAttributes(request, false);
            HttpStatus status = getStatus(request);
            
            // Ensure consistent error response format
            body.put("path", request.getRequestURI());
            body.put("method", request.getMethod());
            
            return new ResponseEntity<>(body, status);
        }

        private HttpStatus getStatus(HttpServletRequest request) {
            Integer statusCode = (Integer) request.getAttribute("jakarta.servlet.error.status_code");
            if (statusCode == null) {
                return HttpStatus.INTERNAL_SERVER_ERROR;
            }
            try {
                return HttpStatus.valueOf(statusCode);
            } catch (Exception ex) {
                return HttpStatus.INTERNAL_SERVER_ERROR;
            }
        }

        private Map<String, Object> getErrorAttributes(HttpServletRequest request, boolean includeStackTrace) {
            WebRequest webRequest = new ServletWebRequest(request);
            ErrorAttributeOptions options = includeStackTrace ? 
                ErrorAttributeOptions.defaults().including(ErrorAttributeOptions.Include.STACK_TRACE) :
                ErrorAttributeOptions.defaults();
            return this.errorAttributes.getErrorAttributes(webRequest, options);
        }
    }
} 