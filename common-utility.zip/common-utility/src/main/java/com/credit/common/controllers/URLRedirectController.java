package com.credit.common.controllers;

import java.net.URI;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import com.credit.common.entities.URLNotFoundException;
import com.credit.common.entities.UrlCache;
import com.credit.common.service.URLShorteningService;

@Controller
public class URLRedirectController {
    private final Logger log = LoggerFactory.getLogger(URLRedirectController.class);

    private final URLShorteningService service;

    public URLRedirectController(URLShorteningService service) {
        this.service = service;
    }

    @GetMapping("/SPICEM/cr/{shortUrl}")
    public ResponseEntity<Void> redirect(@PathVariable String shortUrl) {
        log.info("Processing SPICEM redirect request for short URL: {}", shortUrl);
        
        Optional<UrlCache> optional = service.findByShortUrl(shortUrl);
        log.debug("SPICEM URL cache lookup result: {}", optional.isPresent() ? "found" : "not found");
        
        if (optional.isPresent()) {
            UrlCache urlCache = optional.get();
            String targetUrl = urlCache.getUrl();
            log.info("SPICEM redirect successful - short URL '{}' redirecting to: {}", shortUrl, targetUrl);
            
            URI redirectUri = URI.create(targetUrl);
            return ResponseEntity.status(HttpStatus.FOUND)
                    .location(redirectUri)
                    .build();
        } else {
            log.warn("SPICEM short URL not found in cache: {}", shortUrl);
            throw new URLNotFoundException(shortUrl);
        }
    }

    @GetMapping("/r/{shortUrl}")
    public ResponseEntity<Void> redirectR(@PathVariable String shortUrl) {
        log.info("Processing standard redirect request for short URL: {}", shortUrl);
        
        Optional<UrlCache> optional = service.findByShortUrl(shortUrl);
        log.debug("Standard URL cache lookup result: {}", optional.isPresent() ? "found" : "not found");
        
        if (optional.isPresent()) {
            UrlCache urlCache = optional.get();
            String targetUrl = urlCache.getUrl();
            log.info("Standard redirect successful - short URL '{}' redirecting to: {}", shortUrl, targetUrl);
            
            URI redirectUri = URI.create(targetUrl);
            return ResponseEntity.status(HttpStatus.FOUND)
                    .location(redirectUri)
                    .build();
        } else {
            log.warn("Standard short URL not found in cache: {}", shortUrl);
            throw new URLNotFoundException(shortUrl);
        }
    }
}
