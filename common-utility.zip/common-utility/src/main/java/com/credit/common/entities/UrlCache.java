package com.credit.common.entities;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

import lombok.Data;

@Data
@Entity
@Table(name = "t_url_cache")
public class UrlCache {
    @Id
    String shortUrl;

    String url;
}