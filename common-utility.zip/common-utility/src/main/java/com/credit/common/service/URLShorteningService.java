package com.credit.common.service;

import com.credit.common.entities.URL;
import com.credit.common.entities.UrlCache;
import com.credit.common.repositories.URLCacheRepository;
import com.credit.common.repositories.URLRepository;
import com.credit.common.util.UrlShortener;
import com.credit.common.util.UrlShortener.ShortenerConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.transaction.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;


@Service
@Transactional
public class URLShorteningService {

	private final URLRepository dao;

	private final URLCacheRepository cache;

	// Configure the shortening process
	ShortenerConfig config = new ShortenerConfig("SHA-256", 4);

	public void initializeDatabase() {

	}

	@Autowired
	public URLShorteningService(URLRepository dao, URLCacheRepository cache) {
		this.dao = dao;
		this.cache = cache;
	}

	public List<URL> getAllUrls() {
		return dao.findAll();
	}

	public Optional<UrlCache> findByShortUrl(String shortUrl) {
		Optional<UrlCache> urlCache = cache.findById(shortUrl);
		if (urlCache.isPresent()) {
			return urlCache;
		}

		Optional<URL> url = dao.findURLByShortUrl(shortUrl);
        return url.map(this::saveURLToCache);
    }

	public Optional<URL> findById(int id) {
		return dao.findById(id);
	}

	public URL saveURL(URL url) {
		return dao.save(url);
	}

	public UrlCache saveURLToCache(URL url) {
		UrlCache urlCache = new UrlCache();
		urlCache.setShortUrl(url.getShortUrl());
		urlCache.setUrl(url.getUrl());
		return cache.save(urlCache);
	}

	public URL generateShortURLAndSave(URL url) {
		if (url.getUrl() != null && !url.getUrl().startsWith("http")) {
			url.getUrl().replaceFirst("https://", "");
			url.getUrl().replaceFirst("http://", "");
		}
		if (url.getShortUrl() == null) {
			url.setShortUrl(UrlShortener.generateShortCode(url.getUrl(), config));
		}
		if (url.getCreatedDate() == null) {
			url.setCreatedDate(LocalDateTime.now());
		}
		Optional<URL> urlDB = dao.findURLByShortUrl(url.getShortUrl());
        return urlDB.orElseGet(() -> dao.save(url));
    }

	String randomCode() {
		UUID uuid = UUID.randomUUID();
		long lo = uuid.getLeastSignificantBits();
		long hi = uuid.getMostSignificantBits();
		lo = (lo >> (64 - 31)) ^ lo;
		hi = (hi >> (64 - 31)) ^ hi;
		String s = String.format("%010d", Math.abs(hi) + Math.abs(lo));
		return s.substring(s.length() - 10);
	}
}
