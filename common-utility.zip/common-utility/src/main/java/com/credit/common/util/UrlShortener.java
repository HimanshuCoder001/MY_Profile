package com.credit.common.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class UrlShortener {

    // In-memory storage for demonstration purposes (replace with a database in
    // production)
    private static final Map<String, String> urlToShortCodeMap = new HashMap<>();

    public static class ShortenerConfig {
        private String hashAlgorithm;
        private int hashLength;

        public ShortenerConfig(String hashAlgorithm, int hashLength) {
            this.hashAlgorithm = hashAlgorithm;
            this.hashLength = hashLength;
        }

        public String getHashAlgorithm() {
            return hashAlgorithm;
        }

        public int getHashLength() {
            return hashLength;
        }
    }

    public static String generateShortCode(String originalUrl, ShortenerConfig config) {
        try {
            // Check if the short code already exists in the map
            if (urlToShortCodeMap.containsKey(originalUrl)) {
                return urlToShortCodeMap.get(originalUrl);
            }

            // Create a hash of the original URL using the specified algorithm
            MessageDigest digest = MessageDigest.getInstance(config.getHashAlgorithm());
            byte[] hashBytes = digest.digest(originalUrl.getBytes());

            // Convert the hash to base64 to get a shorter representation
            String base64Hash = Base64.getUrlEncoder().withoutPadding().encodeToString(hashBytes);

            // Take the desired length as the short code
            String shortCode = base64Hash.substring(0, config.getHashLength());

            // Store the mapping in the map (replace with storage in a database)
            urlToShortCodeMap.put(originalUrl, shortCode);

            return shortCode;
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[] args) {
        // Configure the shortening process
        ShortenerConfig config = new ShortenerConfig("SHA-256", 4);

        // Example usage
        String originalUrl = "https://www.example.com";
        String shortCode = generateShortCode(originalUrl, config);
        System.out.println("Short Code: " + shortCode);
    }
}
