package com.credit.common.service;

import java.time.LocalDateTime;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.credit.common.entities.PIIData;
import com.credit.common.repositories.PIIDataRepository;

import reactor.core.publisher.Mono;

@Service
public class PIIDataService {

	private final PIIDataRepository piiDataRepository;
	private final EncDecService encDecService;

	@Autowired
	public PIIDataService(PIIDataRepository piiDataRepository, EncDecService encDecService) {
		this.piiDataRepository = piiDataRepository;
		this.encDecService = encDecService;
	}

	public Mono<PIIData> savePIIData(PIIData piiData) {
		piiData.setCreatedDate(LocalDateTime.now());

        // Encrypt each property before saving
        piiData.setMobile(encDecService.encryption(piiData.getMobile()));
        piiData.setPan(encDecService.encryption(piiData.getPan()));
        piiData.setEmail(encDecService.encryption(piiData.getEmail()));

        return Mono.just(piiDataRepository.findOrCreateBy(piiData));
	}

	public Mono<PIIData> getPIIDataById(String id,String docType) {
		PIIData piiData = getRecord(id, docType.toUpperCase());

		if (piiData == null) {
			return Mono.empty();
		}

		return Mono.justOrEmpty(piiData);
	}


	public Mono<PIIData> getPIIDataByType(String id, String docType) {
		id = encDecService.encryption(id);
		PIIData piiData = getRecord(id, docType.toUpperCase());

		if (piiData == null) {
			return Mono.empty();
		}

		return Mono.justOrEmpty(piiData);
	}

	public Mono<PIIData> getOriginalValuePIIDataByTypeFromActualValue(String value, String docType){
		value = encDecService.encryption(value);

		PIIData piiData = getRecord(value, docType.toUpperCase());
		if (piiData == null) {
			return Mono.empty();
		}

		piiData.setPan(encDecService.decryption(piiData.getPan()));
		piiData.setMobile(encDecService.decryption(piiData.getMobile()));
		piiData.setEmail(encDecService.decryption(piiData.getEmail()));

		return Mono.justOrEmpty(piiData);
	}

	public Mono<PIIData> getOriginalPIIDataByTypeFromEncrypted(String value, String docType){

		PIIData piiData = getRecord(value, docType.toUpperCase());
		if (piiData == null) {
			return Mono.empty();
		}

		piiData.setPan(encDecService.decryption(piiData.getPan()));
		piiData.setMobile(encDecService.decryption(piiData.getMobile()));
		piiData.setEmail(encDecService.decryption(piiData.getEmail()));

		return Mono.justOrEmpty(piiData);
	}

	public Mono<PIIData> getOriginalPIIDataFromEncrypted(String pan, String mobile, String email){

		PIIData piiData = new PIIData();

		piiData.setPan(encDecService.decryption(pan));
		piiData.setMobile(encDecService.decryption(mobile));
		piiData.setEmail(encDecService.decryption(email));

		return Mono.justOrEmpty(piiData);
	}


	private PIIData getRecord(String value, String docType) {
		Optional<PIIData> piiData = Optional.empty();
		switch (docType) {
			case "PAN":
				piiData = piiDataRepository.findByPan(value);
				break;
			case "EMAIL":
				piiData = piiDataRepository.findByEmail(value);
				break;
			case "MOBILE":
				piiData = piiDataRepository.findByMobile(value);
				break;
		}
		return piiData.orElse(null);
	}

}
