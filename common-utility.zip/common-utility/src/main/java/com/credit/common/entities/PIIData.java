package com.credit.common.entities;


import java.time.LocalDateTime;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

/**
 * Only Mobile is unique where as pan and email should also be unique.
 *
 * @author niitn
 */
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Table(name = "t_pii", uniqueConstraints = {
    @UniqueConstraint(columnNames = {"pan", "mobile"})
}, indexes = {
    @Index(name = "idx_pan", columnList = "pan"),
    @Index(name = "idx_mobile", columnList = "mobile"),
    @Index(name = "idx_pan_mobile", columnList = "pan,mobile")
})
public class PIIData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @NotBlank
    @Column
    private String pan;

    @NotBlank
    @Column
    private String mobile;

    @JsonFormat(pattern = ("yyyy/MM/dd HH:mm:ss"))
    private LocalDateTime createdDate;

    @Column(name = "email")
    private String email;

    @Column(name = "user_id")
    private String userId;

}