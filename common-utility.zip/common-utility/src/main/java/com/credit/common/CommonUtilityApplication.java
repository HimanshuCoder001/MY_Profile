package com.credit.common;

import java.util.Arrays;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.credit.common.service.URLShorteningService;


@SpringBootApplication
public class CommonUtilityApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonUtilityApplication.class, args);
	}

	@Bean
	public CommandLineRunner initialize(@Autowired URLShorteningService service) {
		return (String... args) -> service.initializeDatabase();
	}
	
	@Bean
	public CommandLineRunner commandLineRunner(ApplicationContext ctx) {
		return args -> {

			System.out.println("Let's inspect the beans provided by Spring Boot:");

			String[] beanNames = ctx.getBeanDefinitionNames();
			Arrays.sort(beanNames);
			for (String beanName : beanNames) {
				System.out.println(beanName);
			}

		};
	}
}
