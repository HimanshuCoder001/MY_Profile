package com.credit.common.repositories;

import org.springframework.data.repository.CrudRepository;

import com.credit.common.entities.URL;
import com.credit.common.entities.UrlCache;

public interface  URLCacheRepository extends CrudRepository<UrlCache, String> {

}


