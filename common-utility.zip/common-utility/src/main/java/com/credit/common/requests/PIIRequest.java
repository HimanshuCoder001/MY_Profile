package com.credit.common.requests;

import lombok.Getter;
import lombok.Setter;

import jakarta.validation.constraints.NotBlank;

@Getter
@Setter
public class PIIRequest {

    @NotBlank
    private String value;

    @NotBlank
    private String type;
}
