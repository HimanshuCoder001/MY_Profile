package com.credit.common.controllers;

import com.credit.common.requests.PIIRequest;
import com.credit.common.requests.PIIRequestValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.credit.common.entities.PIIData;
import com.credit.common.service.PIIDataService;

import reactor.core.publisher.Mono;

import jakarta.validation.Valid;

@RestController
@Validated
@RequestMapping("/api-common/pii")
public class PIIDataController {

    private final PIIDataService piiDataService;

    @Autowired
    public PIIDataController(PIIDataService piiDataService) {
        this.piiDataService = piiDataService;
    }

    @PostMapping("/save")
    public Mono<ResponseEntity<PIIData>> savePIIData(@RequestBody(required = false) PIIData piiData) {
        return piiDataService.savePIIData(piiData)
                .flatMap(savedData -> Mono.just(ResponseEntity.ok(savedData))
                .defaultIfEmpty(ResponseEntity.badRequest().body(piiData)));
    }

    @GetMapping("/encr")
    public Mono<ResponseEntity<PIIData>> retrievePIIDataFromEnc(@RequestParam String id,@RequestParam String type) {
        return piiDataService.getPIIDataById(id,type)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }
    
    @GetMapping("/actual")
    public Mono<ResponseEntity<PIIData>> retrievePIIDataFromOriginal(@RequestParam String id,@RequestParam String type) {
        return piiDataService.getPIIDataByType(id,type)
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PostMapping("original/encr")
    public Mono<ResponseEntity<PIIData>> retrievePIIDataFromEncryptData(@Valid @RequestBody PIIRequest piiRequest) {
        return piiDataService.getOriginalPIIDataByTypeFromEncrypted(piiRequest.getValue(), piiRequest.getType())
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PostMapping("actual/data/v2")
    public Mono<ResponseEntity<PIIData>> retrievePIIDataFromEncryptData(@Valid @RequestBody PIIRequestValidation piiRequestValidation) {
        return piiDataService.getOriginalPIIDataFromEncrypted(piiRequestValidation.getPan(), piiRequestValidation.getMobile(), piiRequestValidation.getEmail())
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }

    @PostMapping("original/actual")
    public Mono<ResponseEntity<PIIData>> retrievePIIDataFromOriginalFromActualData(@Valid @RequestBody PIIRequest piiRequest) {
        return piiDataService.getOriginalValuePIIDataByTypeFromActualValue(piiRequest.getValue(), piiRequest.getType())
                .map(ResponseEntity::ok)
                .defaultIfEmpty(ResponseEntity.notFound().build());
    }
}
