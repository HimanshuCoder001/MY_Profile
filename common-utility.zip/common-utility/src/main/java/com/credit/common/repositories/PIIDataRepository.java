package com.credit.common.repositories;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.credit.common.entities.PIIData;

import java.util.Optional;

@Repository
public interface PIIDataRepository extends CrudRepository<PIIData, String> {

	@Query("SELECT p FROM PIIData p WHERE " + "(:mobile IS NULL OR p.mobile = :mobile) AND "
			+ "(:pan IS NULL OR p.pan = :pan) AND " + "(:email IS NULL OR p.email = :email)")
	PIIData findRecord(@Param(value = "mobile") String mobile, @Param(value = "pan")String pan, @Param(value = "email")String email);

	Optional<PIIData> findByPan(String pan);

	Optional<PIIData> findByMobile(String mobile);

	Optional<PIIData> findByEmail(String email);

	Optional<PIIData> findByMobileAndPan(String mobile, String pan);

	default PIIData findOrCreateBy(PIIData piiData) {
		Optional<PIIData> existingRecord = findByMobileAndPan(piiData.getMobile(), piiData.getPan());
        return existingRecord.orElseGet(() -> save(piiData));
    }
}
