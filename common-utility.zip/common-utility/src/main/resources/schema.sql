-- Switch to the 'url_shortening_new' schema
SET search_path TO url_shortening_new;

-- Drop the 'URL' table if it exists
DROP TABLE IF EXISTS t_url;

-- Create the 'URL' table
CREATE TABLE t_url
(
    id            SERIAL PRIMARY KEY,
    url           VARCHAR(50) NOT NULL,
    created_date  DATE,
    short_url     VARCHAR(10) NOT NULL
);

