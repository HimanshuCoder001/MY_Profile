

insert into t_url(id, url, created_date, short_url) values (1, 'https://www.nitin.com',CURRENT_TIMESTAMP(),'HDVTN4');
insert into t_url(id, url, created_date, short_url) values (2, 'https://www.diksha.com',CURRENT_TIMESTAMP(),'ZNDFEF');
