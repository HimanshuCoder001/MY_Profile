# Common Utility Service

A Spring Boot application that provides URL shortening and PII (Personally Identifiable Information) data management services.

## Features

- **URL Shortening**: Create short URLs and redirect functionality
- **PII Data Management**: Encrypt, decrypt, and manage sensitive personal data
- **RESTful APIs**: Complete REST API endpoints for all operations

## Getting Started

### Prerequisites

- Java 17 or higher
- Maven 3.6+
- Database (H2/MySQL/PostgreSQL)

### Running the Application

1. Clone the repository
2. Navigate to the project directory
3. Run the application:
   ```bash
   mvn spring-boot:run
   ```

The application will start on port **9999**.

### Authentication

The application uses basic authentication:
- Username: `spice-money`
- Password: `spice123`

## API Endpoints

### URL Shortening Service

#### 1. Create Short URL
```bash
curl -X POST http://localhost:9999/shorten/url \
  -H "Content-Type: application/json" \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM=" \
  -d '{
    "url": "https://www.example.com/very-long-url-that-needs-to-be-shortened"
  }'
```

#### 2. Get URL by ID
```bash
curl -X GET http://localhost:9999/shorten/url/{id} \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM="
```

#### 3. Get All URLs
```bash
curl -X GET http://localhost:9999/shorten/url/all \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM="
```

### URL Redirect Service

#### 4. SPICEM Redirect
```bash
curl -X GET http://localhost:9999/SPICEM/cr/{shortUrl} \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM=" \
  -L
```

#### 5. Standard Redirect
```bash
curl -X GET http://localhost:9999/r/{shortUrl} \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM=" \
  -L
```

### PII Data Management Service

#### 6. Save PII Data
```bash
curl -X POST http://localhost:9999/api-common/pii/save \
  -H "Content-Type: application/json" \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM=" \
  -d '{
    "pan": "1234567890123456",
    "mobile": "9876543210",
    "email": "user@example.com"
  }'
```

#### 7. Retrieve PII Data from Encrypted (by ID and Type)
```bash
curl -X GET "http://localhost:9999/api-common/pii/encr?id={encryptedId}&type={type}" \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM="
```

#### 8. Retrieve PII Data from Original (by ID and Type)
```bash
curl -X GET "http://localhost:9999/api-common/pii/actual?id={originalId}&type={type}" \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM="
```

#### 9. Retrieve PII Data from Encrypted Data
```bash
curl -X POST http://localhost:9999/api-common/pii/original/encr \
  -H "Content-Type: application/json" \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM=" \
  -d '{
    "value": "encryptedValue",
    "type": "pan"
  }'
```

#### 10. Retrieve PII Data from Encrypted Data (v2)
```bash
curl -X POST http://localhost:9999/api-common/pii/actual/data/v2 \
  -H "Content-Type: application/json" \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM=" \
  -d '{
    "pan": "encryptedPanValue",
    "mobile": "encryptedMobileValue",
    "email": "encryptedEmailValue"
  }'
```

#### 11. Retrieve PII Data from Original from Actual Data
```bash
curl -X POST http://localhost:9999/api-common/pii/original/actual \
  -H "Content-Type: application/json" \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM=" \
  -d '{
    "value": "actualValue",
    "type": "pan"
  }'
```

### Web Interface

#### 12. View URLs Page
```bash
curl -X GET http://localhost:9999/urls \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM="
```

#### 13. View Specific URL
```bash
curl -X GET http://localhost:9999/urls/{id} \
  -H "Authorization: Basic c3BpY2UtbW9uZXk6c3BpY2UxMjM="
```

## Request/Response Examples

### URL Shortening Response
```json
{
  "id": 1,
  "url": "https://www.example.com/very-long-url-that-needs-to-be-shortened",
  "shortUrl": "abc123"
}
```

### PII Data Response
```json
{
  "id": "encryptedId",
  "pan": "encryptedPanValue",
  "mobile": "encryptedMobileValue",
  "email": "encryptedEmailValue",
  "createdAt": "2024-01-01T00:00:00Z"
}
```

## Error Handling

The application includes comprehensive error handling:
- `404 Not Found`: When URL or PII data is not found
- `400 Bad Request`: When request validation fails
- `401 Unauthorized`: When authentication fails
- `500 Internal Server Error`: For server-side errors

## Configuration

The application supports multiple profiles:
- `dev`: Development environment
- `uat`: User Acceptance Testing environment  
- `prod`: Production environment

Configuration files are located in `src/main/resources/application-{profile}.yml`

## Security

- Basic authentication is enabled for all endpoints
- PII data is encrypted using AES encryption
- Salt and password are configurable in application properties

## Testing

Run the test suite:
```bash
mvn test
```

## Docker Support

### Option 1: Build and run with Docker Compose (Recommended)
```bash
# Build and start all services (app, database, redis)
docker-compose up --build

# Run in background
docker-compose up -d --build

# Stop all services
docker-compose down
```

### Option 2: Build and run with Docker only
```bash
# Build the image
docker build -t common-utility .

# Run the container
docker run -p 9999:9999 common-utility
```

### Docker Services
- **App**: Spring Boot application on port 9999
- **Database**: PostgreSQL database on port 5432

### Environment Variables for Docker
The application uses the `docker` profile when running in Docker containers, which includes:
- PostgreSQL database connection
- Proper networking between services
